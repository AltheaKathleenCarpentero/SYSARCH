<?php require_once 'login.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CCS Sit-in Monitoring System</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/login.css">
</head>
<body>

    <!-- NAV -->
    <nav>
        <span class="nav-brand">College of Computer Studies Sit-in Monitoring System</span>
        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="#">Community</a>
            <a href="#">About</a>
            <a href="index.php">Login</a>
            <a href="register.php">Register</a>
        </div>
    </nav>

    <!-- MAIN -->
    <main>
        <div class="login-container">

            <!-- Logo -->
            <div class="logo-side">
                <img src="assets/ccs_logo.png" alt="CCS Logo" id="ccs-logo">
                <svg style="display:none" id="logo-fallback" width="180" height="180" viewBox="0 0 180 180" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M90 10 L160 40 L160 100 Q160 150 90 170 Q20 150 20 100 L20 40 Z" fill="#6b3fa0"/>
                    <path d="M90 10 L90 170 Q20 150 20 100 L20 40 Z" fill="#c9940a"/>
                    <text x="90" y="105" font-family="Arial Black" font-size="52" fill="white" text-anchor="middle" font-weight="900">CCS</text>
                </svg>
                <div class="logo-tagline">Sit-in Monitoring System</div>
            </div>

            <!-- Card -->
            <div class="login-card">
                <div class="card-title">Welcome Back</div>
                <div class="card-subtitle">Sign in to your student account</div>

                <?php if ($error): ?>
                    <div class="error-msg">⚠ <?= htmlspecialchars($error) ?></div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="form-group">
                        <label for="id_number">ID Number</label>
                        <input type="text" id="id_number" name="id_number"
                               placeholder="Enter your ID number"
                               value="<?= htmlspecialchars($_POST['id_number'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password"
                               placeholder="Enter your password" required>
                    </div>
                    <div class="form-row">
                        <label class="remember-label">
                            <input type="checkbox" name="remember"> Remember me
                        </label>
                        <a href="#" class="forgot-link">Forgot password?</a>
                    </div>
                    <button type="submit" class="btn-login">Login</button>
                </form>

                <div class="register-link">
                    Don't have an account? <a href="register.php">Register</a>
                </div>
            </div>

        </div>
    </main>

    <!-- FOOTER -->
    <footer>&copy; 2026 College of Computer Studies</footer>

    <script>
        document.getElementById('ccs-logo').addEventListener('error', function () {
            this.style.display = 'none';
            document.getElementById('logo-fallback').style.display = 'block';
        });
    </script>

</body>
</html>