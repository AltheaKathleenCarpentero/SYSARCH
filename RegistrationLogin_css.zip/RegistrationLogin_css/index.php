<?php
session_start();
require_once 'config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_number = trim($_POST['id_number']);
    $password = $_POST['password'];

    if (empty($id_number) || empty($password)) {
        $error = 'Please fill in all fields.';
    } else {
        $stmt = $conn->prepare("SELECT * FROM students WHERE id_number = ?");
        $stmt->bind_param("s", $id_number);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $student = $result->fetch_assoc();
            if (password_verify($password, $student['password'])) {
                $_SESSION['student_id'] = $student['id'];
                $_SESSION['student_name'] = $student['first_name'] . ' ' . $student['last_name'];
                $_SESSION['id_number'] = $student['id_number'];
                header("Location: dashboard.php");
                exit();
            } else {
                $error = 'Invalid ID number or password.';
            }
        } else {
            $error = 'Invalid ID number or password.';
        }
        $stmt->close();
    }
}

if (isset($_SESSION['student_id'])) {
    header("Location: dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CCS Sit-in Monitoring System</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --sky: #e0f4ff;
            --sky-mid: #bde5f8;
            --sky-deep: #93cfe8;
            --accent: #4aaed9;
            --accent-dark: #2e8ab8;
            --purple: #6b3fa0;
            --gold: #c9940a;
            --text: #1a2a3a;
            --text-muted: #5a7a8a;
            --white: #ffffff;
            --card-bg: rgba(255,255,255,0.72);
            --shadow: 0 8px 32px rgba(74,174,217,0.18);
        }

        body {
            font-family: 'Nunito', sans-serif;
            min-height: 100vh;
            background: linear-gradient(135deg, #e8f7ff 0%, #d0effc 35%, #c2e8f8 60%, #daf0ff 100%);
            display: flex;
            flex-direction: column;
            color: var(--text);
            overflow-x: hidden;
        }

        /* Decorative blobs */
        body::before {
            content: '';
            position: fixed;
            top: -120px; right: -120px;
            width: 420px; height: 420px;
            background: radial-gradient(circle, rgba(107,63,160,0.10) 0%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
        }
        body::after {
            content: '';
            position: fixed;
            bottom: -100px; left: -100px;
            width: 380px; height: 380px;
            background: radial-gradient(circle, rgba(74,174,217,0.13) 0%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
        }

        /* NAV */
        nav {
            background: linear-gradient(90deg, var(--purple) 0%, #4a2678 100%);
            padding: 0 2.5rem;
            height: 56px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 16px rgba(107,63,160,0.25);
            position: relative;
            z-index: 10;
        }
        .nav-brand {
            color: #fff;
            font-size: 0.95rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }
        .nav-links a {
            color: rgba(255,255,255,0.85);
            text-decoration: none;
            font-size: 0.88rem;
            font-weight: 600;
            margin-left: 1.6rem;
            transition: color 0.2s;
        }
        .nav-links a:hover { color: #fff; }

        /* MAIN */
        main {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 3rem 1.5rem;
        }

        .login-container {
            display: flex;
            align-items: center;
            gap: 5rem;
            max-width: 900px;
            width: 100%;
        }

        .logo-side {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 1.2rem;
            animation: fadeInLeft 0.7s ease both;
        }
        .logo-side img {
            width: 220px;
            height: 220px;
            object-fit: contain;
            filter: drop-shadow(0 8px 24px rgba(107,63,160,0.22));
        }
        .logo-tagline {
            font-size: 0.82rem;
            font-weight: 700;
            letter-spacing: 0.14em;
            text-transform: uppercase;
            color: var(--text-muted);
            text-align: center;
        }

        /* CARD */
        .login-card {
            flex: 1;
            background: var(--card-bg);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1.5px solid rgba(255,255,255,0.7);
            border-radius: 24px;
            padding: 2.8rem 2.4rem;
            box-shadow: var(--shadow), 0 1px 0 rgba(255,255,255,0.9) inset;
            animation: fadeInRight 0.7s ease both;
        }

        .card-title {
            font-family: 'Playfair Display', serif;
            font-size: 1.75rem;
            color: var(--purple);
            margin-bottom: 0.3rem;
        }
        .card-subtitle {
            font-size: 0.85rem;
            color: var(--text-muted);
            margin-bottom: 1.8rem;
        }

        .error-msg {
            background: #ffe4e4;
            border: 1px solid #f5a0a0;
            color: #c0392b;
            border-radius: 10px;
            padding: 0.65rem 1rem;
            font-size: 0.85rem;
            margin-bottom: 1.2rem;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 1.2rem;
        }
        .form-group label {
            display: block;
            font-size: 0.8rem;
            font-weight: 700;
            color: var(--text-muted);
            letter-spacing: 0.07em;
            text-transform: uppercase;
            margin-bottom: 0.45rem;
        }
        .form-group input {
            width: 100%;
            padding: 0.75rem 1.1rem;
            border: 1.5px solid var(--sky-mid);
            border-radius: 12px;
            font-size: 0.95rem;
            font-family: 'Nunito', sans-serif;
            background: rgba(255,255,255,0.85);
            color: var(--text);
            transition: border-color 0.2s, box-shadow 0.2s;
            outline: none;
        }
        .form-group input:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(74,174,217,0.18);
            background: #fff;
        }
        .form-group input::placeholder { color: #b0c8d4; }

        .form-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1.5rem;
        }
        .remember-label {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.85rem;
            color: var(--text-muted);
            cursor: pointer;
            font-weight: 600;
        }
        .remember-label input[type="checkbox"] {
            accent-color: var(--accent);
            width: 16px; height: 16px;
        }
        .forgot-link {
            font-size: 0.83rem;
            color: var(--accent-dark);
            text-decoration: none;
            font-weight: 700;
            transition: color 0.2s;
        }
        .forgot-link:hover { color: var(--purple); }

        .btn-login {
            width: 100%;
            padding: 0.85rem;
            background: linear-gradient(135deg, var(--accent) 0%, var(--accent-dark) 100%);
            color: #fff;
            border: none;
            border-radius: 12px;
            font-size: 1rem;
            font-family: 'Nunito', sans-serif;
            font-weight: 800;
            letter-spacing: 0.06em;
            cursor: pointer;
            box-shadow: 0 4px 16px rgba(74,174,217,0.35);
            transition: transform 0.15s, box-shadow 0.15s;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(74,174,217,0.45);
        }
        .btn-login:active { transform: translateY(0); }

        .register-link {
            text-align: center;
            margin-top: 1.3rem;
            font-size: 0.87rem;
            color: var(--text-muted);
        }
        .register-link a {
            color: var(--purple);
            font-weight: 800;
            text-decoration: none;
            transition: color 0.2s;
        }
        .register-link a:hover { color: var(--accent-dark); }

        /* FOOTER */
        footer {
            text-align: center;
            padding: 1rem;
            font-size: 0.8rem;
            color: var(--text-muted);
            font-weight: 600;
        }

        @keyframes fadeInLeft {
            from { opacity: 0; transform: translateX(-30px); }
            to   { opacity: 1; transform: translateX(0); }
        }
        @keyframes fadeInRight {
            from { opacity: 0; transform: translateX(30px); }
            to   { opacity: 1; transform: translateX(0); }
        }

        @media (max-width: 680px) {
            .login-container { flex-direction: column; gap: 2rem; }
            .logo-side img { width: 150px; height: 150px; }
        }
    </style>
</head>
<body>
    <nav>
        <span class="nav-brand">College of Computer Studies Sit-in Monitoring System</span>
        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="#">Community</a>
            <a href="#">About</a>
            <a href="index.php">Login</a>
            <a href="register.php">Register</a>
        </div>
    </nav>

    <main>
        <div class="login-container">
            <div class="logo-side">
                <img src="assets/ccs_logo.png" alt="CCS Logo" onerror="this.style.display='none'">
                <!-- Fallback SVG shield if image missing -->
                <svg style="display:none" id="logo-fallback" width="180" height="180" viewBox="0 0 180 180" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M90 10 L160 40 L160 100 Q160 150 90 170 Q20 150 20 100 L20 40 Z" fill="#6b3fa0"/>
                    <path d="M90 10 L90 170 Q20 150 20 100 L20 40 Z" fill="#c9940a"/>
                    <text x="90" y="105" font-family="Arial Black" font-size="52" fill="white" text-anchor="middle" font-weight="900">CCS</text>
                </svg>
                <div class="logo-tagline">Sit-in Monitoring System</div>
            </div>

            <div class="login-card">
                <div class="card-title">Welcome Back</div>
                <div class="card-subtitle">Sign in to your student account</div>

                <?php if ($error): ?>
                    <div class="error-msg">⚠ <?= htmlspecialchars($error) ?></div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="form-group">
                        <label for="id_number">ID Number</label>
                        <input type="text" id="id_number" name="id_number" placeholder="Enter your ID number"
                               value="<?= htmlspecialchars($_POST['id_number'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" placeholder="Enter your password" required>
                    </div>
                    <div class="form-row">
                        <label class="remember-label">
                            <input type="checkbox" name="remember"> Remember me
                        </label>
                        <a href="#" class="forgot-link">Forgot password?</a>
                    </div>
                    <button type="submit" class="btn-login">Login</button>
                </form>

                <div class="register-link">
                    Don't have an account? <a href="register.php">Register</a>
                </div>
            </div>
        </div>
    </main>

    <footer>
        &copy; 2026 College of Computer Studies
    </footer>

    <script>
        // Show fallback SVG if image fails
        document.querySelector('.logo-side img').addEventListener('error', function() {
            this.style.display = 'none';
            document.getElementById('logo-fallback').style.display = 'block';
        });
    </script>
</body>
</html>
