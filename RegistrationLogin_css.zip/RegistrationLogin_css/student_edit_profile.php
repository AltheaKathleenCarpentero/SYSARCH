<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php");
    exit();
}
require_once 'config.php';

$student_id = $_SESSION['student_id'];
$error = '';
$success = '';

// Fetch student data
$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $last_name = trim($_POST['last_name']);
    $first_name = trim($_POST['first_name']);
    $middle_name = trim($_POST['middle_name']);
    $course_level = intval($_POST['course_level']);
    $email = trim($_POST['email']);
    $course = trim($_POST['course']);
    $address = trim($_POST['address']);
    
    $update_stmt = $conn->prepare("
        UPDATE students SET 
            last_name = ?, first_name = ?, middle_name = ?, 
            course_level = ?, email = ?, course = ?, address = ? 
        WHERE id = ?
    ");
    $update_stmt->bind_param("sssisssi", $last_name, $first_name, $middle_name, $course_level, $email, $course, $address, $student_id);
    
    if ($update_stmt->execute()) {
        $success = "Profile updated successfully!";
        // Refresh student data
        $stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
        $stmt->bind_param("i", $student_id);
        $stmt->execute();
        $student = $stmt->get_result()->fetch_assoc();
        $stmt->close();
    } else {
        $error = "Failed to update profile.";
    }
    $update_stmt->close();
}

// Handle photo upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_photo'])) {
    $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $file = $_FILES['profile_photo'];
    
    if ($file['error'] === 0 && in_array($file['type'], $allowed)) {
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'student_' . $student_id . '_' . time() . '.' . $ext;
        $upload_path = 'assets/uploads/' . $filename;
        
        if (!is_dir('assets/uploads')) {
            mkdir('assets/uploads', 0755, true);
        }
        
        // Delete old photo if exists
        if (!empty($student['photo']) && file_exists('assets/uploads/' . $student['photo'])) {
            unlink('assets/uploads/' . $student['photo']);
        }
        
        if (move_uploaded_file($file['tmp_name'], $upload_path)) {
            $photo_stmt = $conn->prepare("UPDATE students SET photo = ? WHERE id = ?");
            $photo_stmt->bind_param("si", $filename, $student_id);
            $photo_stmt->execute();
            $photo_stmt->close();
            $student['photo'] = $filename;
            $success = "Profile photo updated!";
        } else {
            $error = "Failed to upload photo.";
        }
    } else {
        $error = "Invalid file type. Please upload JPEG, PNG, GIF, or WEBP.";
    }
    header("Location: student_edit_profile.php");
    exit();
}

$photo_path = (!empty($student['photo']) && file_exists('assets/uploads/' . $student['photo']))
    ? 'assets/uploads/' . $student['photo'] : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile - CCS Sit-in Monitoring</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/dashboard.css">
    <style>
        .profile-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 2rem;
        }
        .profile-card {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1.5px solid var(--border);
            border-radius: 24px;
            padding: 2rem;
        }
        .profile-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        .profile-photo-large {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--gold);
            margin-bottom: 1rem;
        }
        .photo-placeholder-large {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--violet-light), var(--violet-mid));
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            border: 3px solid var(--gold);
            margin: 0 auto 1rem;
        }
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        .form-group {
            display: flex;
            flex-direction: column;
        }
        .form-group.full {
            grid-column: 1 / -1;
        }
        .form-group label {
            font-size: 0.75rem;
            font-weight: 800;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.06em;
            margin-bottom: 0.35rem;
        }
        .form-group input, .form-group select {
            padding: 0.75rem 1rem;
            border: 1.5px solid rgba(212,160,23,0.2);
            border-radius: 12px;
            font-size: 0.9rem;
            font-family: 'Nunito', sans-serif;
            background: rgba(255,255,255,0.05);
            color: var(--text);
            transition: all 0.2s;
            outline: none;
        }
        .form-group input:focus, .form-group select:focus {
            border-color: var(--gold);
            box-shadow: 0 0 0 3px rgba(212,160,23,0.15);
        }
        .btn-save {
            width: 100%;
            padding: 0.85rem;
            background: linear-gradient(135deg, var(--gold) 0%, var(--gold-dim) 100%);
            color: #0d0018;
            border: none;
            border-radius: 12px;
            font-size: 1rem;
            font-weight: 900;
            text-transform: uppercase;
            cursor: pointer;
            margin-top: 1rem;
        }
        .upload-label {
            display: inline-block;
            background: rgba(212,160,23,0.15);
            color: var(--gold-light);
            padding: 0.4rem 1rem;
            border-radius: 20px;
            cursor: pointer;
            font-size: 0.8rem;
            margin-top: 0.5rem;
        }
        .alert {
            padding: 0.75rem;
            border-radius: 10px;
            margin-bottom: 1rem;
        }
        .alert-success {
            background: rgba(46,213,115,0.1);
            border: 1px solid rgba(46,213,115,0.3);
            color: #5de898;
        }
        .alert-error {
            background: rgba(255,60,60,0.1);
            border: 1px solid rgba(255,60,60,0.3);
            color: #ff9090;
        }
        @media (max-width: 640px) {
            .form-grid { grid-template-columns: 1fr; }
            .profile-container { padding: 1rem; }
        }
        .profile-container {
            max-width: 860px;
        }
        .profile-card {
            background: #fff;
            border: 1px solid var(--line);
            border-radius: 8px;
            box-shadow: var(--shadow);
            backdrop-filter: none;
            padding: 2.25rem;
        }
        .profile-card::before {
            content: '';
            display: block;
            height: 4px;
            margin: -2.25rem -2.25rem 2rem;
            background: linear-gradient(90deg, var(--brand-strong), var(--accent));
            border-radius: 8px 8px 0 0;
        }
        .profile-header h2 {
            color: var(--brand-strong) !important;
            font-family: 'Nunito', sans-serif;
            font-weight: 900;
        }
        .profile-photo-large,
        .photo-placeholder-large {
            border: 4px solid #fff;
            outline: 2px solid var(--brand-line);
            box-shadow: 0 10px 26px rgba(61, 31, 111, 0.14);
        }
        .photo-placeholder-large {
            background: var(--brand-soft);
            color: var(--brand);
        }
        .form-group label {
            color: var(--ink-muted);
        }
        .form-group input, .form-group select {
            background: #fff;
            color: var(--ink);
            border: 1px solid var(--line-strong);
            border-radius: 8px;
        }
        .form-group input:focus, .form-group select:focus {
            border-color: var(--brand);
            box-shadow: 0 0 0 3px rgba(109, 75, 179, 0.14);
        }
        .form-group select option {
            background: #fff;
            color: var(--ink);
        }
        .btn-save {
            background: linear-gradient(180deg, #8d6bd1 0%, #6542aa 100%);
            color: #fff;
            border: 1px solid rgba(73, 43, 130, 0.28);
            border-radius: 8px;
            box-shadow: 0 8px 18px rgba(101, 66, 170, 0.22);
            letter-spacing: 0.04em;
        }
        .upload-label {
            background: var(--brand-soft);
            color: var(--brand-strong);
            border: 1px solid var(--brand-line);
            border-radius: 8px;
        }
        .alert {
            border-radius: 8px;
        }
        .alert-success {
            background: #ecfdf3;
            border-color: #abefc6;
            color: var(--success);
        }
        .alert-error {
            background: #fff1f0;
            border-color: #fecdca;
            color: var(--danger);
        }
    </style>
    <link rel="stylesheet" href="assets/schema.css">
</head>
<body>
    <nav>
        <span class="nav-brand">🎓 CCS Sit-in Monitoring System</span>
        <div class="nav-links">
            <div class="nav-dropdown">
                <div class="nav-drop-toggle">Notifications</div>
                <div class="nav-drop-menu">
                    <a href="student_notifications.php">Announcements</a>
                    <a href="student_alerts.php">Alerts</a>
                    <a href="student_messages.php">Messages</a>
                </div>
            </div>
            <a href="dashboard.php">Home</a>
            <a href="student_edit_profile.php" class="active">Edit Profile</a>
            <a href="student_history.php">History</a>
            <a href="student_leaderboard.php">🏆 Leaderboard</a>
            <a href="student_reservation.php">Reservation</a>
            <a href="?logout=1" class="logout-btn">Logout</a>
        </div>
    </nav>

    <main>
        <div class="profile-container">
            <div class="profile-card">
                <div class="profile-header">
                    <h2 style="color: var(--gold-light);">Edit Profile</h2>
                </div>

                <?php if ($success): ?>
                    <div class="alert alert-success">✓ <?= htmlspecialchars($success) ?></div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert alert-error">⚠ <?= htmlspecialchars($error) ?></div>
                <?php endif; ?>

                <!-- Photo Upload -->
                <form method="POST" enctype="multipart/form-data" style="text-align: center; margin-bottom: 2rem;">
                    <?php if ($photo_path): ?>
                        <img src="<?= htmlspecialchars($photo_path) ?>?v=<?= time() ?>" class="profile-photo-large" alt="Profile Photo">
                    <?php else: ?>
                        <div class="photo-placeholder-large">👤</div>
                    <?php endif; ?>
                    <div>
                        <label class="upload-label" for="photo-input">📷 Change Photo</label>
                        <input type="file" id="photo-input" name="profile_photo" accept="image/*" style="display: none;" onchange="this.form.submit()">
                    </div>
                </form>

                <!-- Edit Form -->
                <form method="POST">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>ID Number</label>
                            <input type="text" value="<?= htmlspecialchars($student['id_number']) ?>" readonly disabled>
                        </div>
                        <div class="form-group">
                            <label>Course Level</label>
                            <select name="course_level">
                                <option value="1" <?= ($student['course_level'] ?? '') == 1 ? 'selected' : '' ?>>1st Year</option>
                                <option value="2" <?= ($student['course_level'] ?? '') == 2 ? 'selected' : '' ?>>2nd Year</option>
                                <option value="3" <?= ($student['course_level'] ?? '') == 3 ? 'selected' : '' ?>>3rd Year</option>
                                <option value="4" <?= ($student['course_level'] ?? '') == 4 ? 'selected' : '' ?>>4th Year</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" name="last_name" value="<?= htmlspecialchars($student['last_name'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" name="first_name" value="<?= htmlspecialchars($student['first_name'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Middle Name</label>
                            <input type="text" name="middle_name" value="<?= htmlspecialchars($student['middle_name'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" value="<?= htmlspecialchars($student['email'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label>Course</label>
                            <select name="course">
                                <option value="BSCS" <?= ($student['course'] ?? '') == 'BSCS' ? 'selected' : '' ?>>BSCS</option>
                                <option value="BSIT" <?= ($student['course'] ?? '') == 'BSIT' ? 'selected' : '' ?>>BSIT</option>
                            </select>
                        </div>
                        <div class="form-group full">
                            <label>Address</label>
                            <input type="text" name="address" value="<?= htmlspecialchars($student['address'] ?? '') ?>">
                        </div>
                    </div>
                    <button type="submit" name="update_profile" class="btn-save">Save Changes</button>
                </form>
            </div>
        </div>
    </main>

    <footer>&copy; 2026 College of Computer Studies</footer>
</body>
</html>
