<?php
session_start();
require_once 'config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_number  = trim($_POST['id_number']);
    $last_name  = trim($_POST['last_name']);
    $first_name = trim($_POST['first_name']);
    $middle_name = trim($_POST['middle_name']);
    $course_level = intval($_POST['course_level']);
    $password   = $_POST['password'];
    $repeat_pw  = $_POST['repeat_password'];
    $email      = trim($_POST['email']);
    $course     = trim($_POST['course']);
    $address    = trim($_POST['address']);

    if (empty($id_number) || empty($last_name) || empty($first_name) || empty($password)) {
        $error = 'Please fill in all required fields.';
    } elseif ($password !== $repeat_pw) {
        $error = 'Passwords do not match.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        // Check if ID already exists
        $check = $conn->prepare("SELECT id FROM students WHERE id_number = ?");
        $check->bind_param("s", $id_number);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $error = 'That ID number is already registered.';
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO students (id_number, last_name, first_name, middle_name, course_level, password, email, course, address) VALUES (?,?,?,?,?,?,?,?,?)");
            $stmt->bind_param("ssssissss", $id_number, $last_name, $first_name, $middle_name, $course_level, $hashed, $email, $course, $address);

            if ($stmt->execute()) {
                $success = 'Registration successful! You can now <a href="index.php">login</a>.';
            } else {
                $error = 'Registration failed. Please try again.';
            }
            $stmt->close();
        }
        $check->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register – CCS Sit-in Monitoring</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/register.css">
    <style>
        select.form-select {
            padding: 0.68rem 1rem;
            border: 1.5px solid rgba(212,160,23,0.18);
            border-radius: 10px;
            font-size: 0.92rem;
            font-family: 'Nunito', sans-serif;
            background: rgba(255,255,255,0.05);
            color: var(--text);
            transition: border-color 0.2s, box-shadow 0.2s;
            outline: none;
            width: 100%;
            cursor: pointer;
        }
        select.form-select:focus {
            border-color: var(--gold);
            box-shadow: 0 0 0 3px rgba(212,160,23,0.14);
            background: rgba(255,255,255,0.08);
        }
        select.form-select option {
            background: #1a0035;
            color: #f0e6ff;
        }
    </style>
</head>
<body>
    <nav>
        <span class="nav-brand">College of Computer Studies Sit-in Monitoring System</span>
        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="#">Community</a>
            <a href="#">About</a>
            <a href="index.php">Login</a>
            <a href="register.php">Register</a>
        </div>
    </nav>

    <main>
        <div class="reg-wrapper">
            <div class="reg-card">
                <a href="index.php" class="back-btn">← Back</a>
                <div class="card-title">SIGN UP</div>

                <?php if ($error): ?>
                    <div class="alert alert-error">⚠ <?= htmlspecialchars($error) ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="alert alert-success">✓ <?= $success ?></div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>ID Number <span class="required-star">*</span></label>
                            <input type="text" name="id_number" placeholder="e.g. 2024-00001"
                                   value="<?= htmlspecialchars($_POST['id_number'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Course Level <span class="required-star">*</span></label>
                            <select name="course_level" class="form-select" required>
                                <option value="">Select Year Level</option>
                                <option value="1" <?= (($_POST['course_level'] ?? '') == '1') ? 'selected' : '' ?>>1st Year</option>
                                <option value="2" <?= (($_POST['course_level'] ?? '') == '2') ? 'selected' : '' ?>>2nd Year</option>
                                <option value="3" <?= (($_POST['course_level'] ?? '') == '3') ? 'selected' : '' ?>>3rd Year</option>
                                <option value="4" <?= (($_POST['course_level'] ?? '') == '4') ? 'selected' : '' ?>>4th Year</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Last Name <span class="required-star">*</span></label>
                            <input type="text" name="last_name" placeholder="Dela Cruz"
                                   value="<?= htmlspecialchars($_POST['last_name'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label>First Name <span class="required-star">*</span></label>
                            <input type="text" name="first_name" placeholder="Juan"
                                   value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>" required>
                        </div>
                        <div class="form-group full">
                            <label>Middle Name</label>
                            <input type="text" name="middle_name" placeholder="Santos"
                                   value="<?= htmlspecialchars($_POST['middle_name'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label>Course <span class="required-star">*</span></label>
                            <select name="course" class="form-select" required>
                                <option value="">Select Course</option>
                                <option value="BSCS" <?= (($_POST['course'] ?? '') == 'BSCS') ? 'selected' : '' ?>>BSCS - Bachelor of Science in Computer Science</option>
                                <option value="BSIT" <?= (($_POST['course'] ?? '') == 'BSIT') ? 'selected' : '' ?>>BSIT - Bachelor of Science in Information Technology</option>
                            
                        </div>
                        <div class="form-group">
                            <label>Password <span class="required-star">*</span></label>
                            <input type="password" name="password" placeholder="Min. 6 characters" required>
                        </div>
                        <div class="form-group">
                            <label>Repeat Password <span class="required-star">*</span></label>
                            <input type="password" name="repeat_password" placeholder="Confirm password" required>
                        </div>
                        <div class="form-group full">
                            <label>Email</label>
                            <input type="email" name="email" placeholder="you@email.com"
                                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                        </div>
                        <div class="form-group full">
                            <label>Address</label>
                            <input type="text" name="address" placeholder="City, Province"
                                   value="<?= htmlspecialchars($_POST['address'] ?? '') ?>">
                        </div>
                    </div>

                    <button type="submit" class="btn-register">Create Account</button>
                </form>

                <div class="login-link">
                    Already have an account? <a href="index.php">Login</a>
                </div>
            </div>

            </div>
        </div>
    </main>

    <footer>&copy; 2026 College of Computer Studies</footer>
</body>
</html>