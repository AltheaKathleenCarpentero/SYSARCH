<?php
session_start();
require_once 'config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_number  = trim($_POST['id_number']);
    $last_name  = trim($_POST['last_name']);
    $first_name = trim($_POST['first_name']);
    $middle_name = trim($_POST['middle_name']);
    $course_level = intval($_POST['course_level']);
    $password   = $_POST['password'];
    $repeat_pw  = $_POST['repeat_password'];
    $email      = trim($_POST['email']);
    $course     = trim($_POST['course']);
    $address    = trim($_POST['address']);

    if (empty($id_number) || empty($last_name) || empty($first_name) || empty($password)) {
        $error = 'Please fill in all required fields.';
    } elseif ($password !== $repeat_pw) {
        $error = 'Passwords do not match.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        // Check if ID already exists
        $check = $conn->prepare("SELECT id FROM students WHERE id_number = ?");
        $check->bind_param("s", $id_number);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $error = 'That ID number is already registered.';
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO students (id_number, last_name, first_name, middle_name, course_level, password, email, course, address) VALUES (?,?,?,?,?,?,?,?,?)");
            $stmt->bind_param("ssssissss", $id_number, $last_name, $first_name, $middle_name, $course_level, $hashed, $email, $course, $address);

            if ($stmt->execute()) {
                $success = 'Registration successful! You can now <a href="index.php">login</a>.';
            } else {
                $error = 'Registration failed. Please try again.';
            }
            $stmt->close();
        }
        $check->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register – CCS Sit-in Monitoring</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --sky: #e0f4ff;
            --sky-mid: #bde5f8;
            --accent: #4aaed9;
            --accent-dark: #2e8ab8;
            --purple: #6b3fa0;
            --gold: #c9940a;
            --text: #1a2a3a;
            --text-muted: #5a7a8a;
            --white: #ffffff;
            --card-bg: rgba(255,255,255,0.75);
            --shadow: 0 8px 36px rgba(74,174,217,0.15);
        }

        body {
            font-family: 'Nunito', sans-serif;
            min-height: 100vh;
            background: linear-gradient(135deg, #e8f7ff 0%, #d0effc 40%, #daf0ff 100%);
            display: flex;
            flex-direction: column;
            color: var(--text);
        }
        body::before {
            content: '';
            position: fixed;
            top: -100px; right: -100px;
            width: 400px; height: 400px;
            background: radial-gradient(circle, rgba(107,63,160,0.09) 0%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
        }

        /* NAV */
        nav {
            background: linear-gradient(90deg, var(--purple) 0%, #4a2678 100%);
            padding: 0 2.5rem;
            height: 56px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 16px rgba(107,63,160,0.25);
        }
        .nav-brand { color: #fff; font-size: 0.95rem; font-weight: 700; }
        .nav-links a {
            color: rgba(255,255,255,0.85);
            text-decoration: none;
            font-size: 0.88rem;
            font-weight: 600;
            margin-left: 1.6rem;
            transition: color 0.2s;
        }
        .nav-links a:hover { color: #fff; }

        main {
            flex: 1;
            display: flex;
            align-items: flex-start;
            justify-content: center;
            padding: 2.5rem 1.5rem;
        }

        .reg-wrapper {
            display: flex;
            gap: 4rem;
            max-width: 960px;
            width: 100%;
            align-items: flex-start;
        }

        .reg-card {
            flex: 1.2;
            background: var(--card-bg);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1.5px solid rgba(255,255,255,0.7);
            border-radius: 24px;
            padding: 2.4rem 2.2rem;
            box-shadow: var(--shadow);
            animation: fadeIn 0.6s ease both;
        }

        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            background: var(--purple);
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 0.4rem 1rem;
            font-size: 0.82rem;
            font-family: 'Nunito', sans-serif;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            margin-bottom: 1.4rem;
            transition: background 0.2s;
        }
        .back-btn:hover { background: #4a2678; }

        .page-label {
            font-size: 0.72rem;
            font-weight: 800;
            letter-spacing: 0.18em;
            text-transform: uppercase;
            color: var(--text-muted);
            margin-bottom: 0.3rem;
        }
        .card-title {
            font-family: 'Playfair Display', serif;
            font-size: 1.7rem;
            color: var(--purple);
            margin-bottom: 1.6rem;
        }

        .alert {
            border-radius: 10px;
            padding: 0.7rem 1rem;
            font-size: 0.85rem;
            font-weight: 600;
            margin-bottom: 1.2rem;
        }
        .alert-error { background: #ffe4e4; border: 1px solid #f5a0a0; color: #c0392b; }
        .alert-success { background: #e2fbe8; border: 1px solid #86dda0; color: #1a7a40; }
        .alert-success a { color: var(--accent-dark); font-weight: 800; }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem 1.4rem;
        }
        .form-group { display: flex; flex-direction: column; }
        .form-group.full { grid-column: 1 / -1; }

        label {
            font-size: 0.78rem;
            font-weight: 700;
            color: var(--text-muted);
            letter-spacing: 0.06em;
            text-transform: uppercase;
            margin-bottom: 0.35rem;
        }
        input, select {
            padding: 0.68rem 1rem;
            border: 1.5px solid var(--sky-mid);
            border-radius: 10px;
            font-size: 0.92rem;
            font-family: 'Nunito', sans-serif;
            background: rgba(255,255,255,0.85);
            color: var(--text);
            transition: border-color 0.2s, box-shadow 0.2s;
            outline: none;
        }
        input:focus, select:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(74,174,217,0.16);
            background: #fff;
        }
        input::placeholder { color: #b0c8d4; }

        .required-star { color: #e05252; margin-left: 2px; }

        .btn-register {
            margin-top: 1.6rem;
            width: 100%;
            padding: 0.88rem;
            background: linear-gradient(135deg, var(--accent) 0%, var(--accent-dark) 100%);
            color: #fff;
            border: none;
            border-radius: 12px;
            font-size: 1rem;
            font-family: 'Nunito', sans-serif;
            font-weight: 800;
            letter-spacing: 0.06em;
            cursor: pointer;
            box-shadow: 0 4px 16px rgba(74,174,217,0.35);
            transition: transform 0.15s, box-shadow 0.15s;
        }
        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(74,174,217,0.45);
        }

        .login-link {
            text-align: center;
            margin-top: 1.2rem;
            font-size: 0.87rem;
            color: var(--text-muted);
        }
        .login-link a { color: var(--purple); font-weight: 800; text-decoration: none; }
        .login-link a:hover { color: var(--accent-dark); }

        /* Side illustration */
        .reg-side {
            flex: 0.7;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding-top: 3.5rem;
            gap: 1.5rem;
            animation: fadeIn 0.8s 0.2s ease both;
            opacity: 0;
        }
        .reg-side svg { width: 100%; max-width: 280px; }
        .reg-side-text {
            text-align: center;
            font-size: 0.83rem;
            color: var(--text-muted);
            font-weight: 600;
            line-height: 1.5;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        footer {
            text-align: center;
            padding: 1rem;
            font-size: 0.8rem;
            color: var(--text-muted);
            font-weight: 600;
        }

        @media (max-width: 768px) {
            .reg-wrapper { flex-direction: column; }
            .reg-side { padding-top: 0; }
            .form-grid { grid-template-columns: 1fr; }
            .form-group.full { grid-column: 1; }
        }
    </style>
</head>
<body>
    <nav>
        <span class="nav-brand">College of Computer Studies Sit-in Monitoring System</span>
        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="#">Community</a>
            <a href="#">About</a>
            <a href="index.php">Login</a>
            <a href="register.php">Register</a>
        </div>
    </nav>

    <main>
        <div class="reg-wrapper">
            <div class="reg-card">
                <a href="index.php" class="back-btn">← Back</a>
                <div class="card-title">SIGN UP</div>

                <?php if ($error): ?>
                    <div class="alert alert-error">⚠ <?= htmlspecialchars($error) ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="alert alert-success">✓ <?= $success ?></div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>ID Number <span class="required-star">*</span></label>
                            <input type="text" name="id_number" placeholder="e.g. 2024-00001"
                                   value="<?= htmlspecialchars($_POST['id_number'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Course Level</label>
                            <input type="number" name="course_level" min="1" max="5"
                                   value="<?= htmlspecialchars($_POST['course_level'] ?? '1') ?>">
                        </div>
                        <div class="form-group">
                            <label>Last Name <span class="required-star">*</span></label>
                            <input type="text" name="last_name" placeholder="Dela Cruz"
                                   value="<?= htmlspecialchars($_POST['last_name'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label>First Name <span class="required-star">*</span></label>
                            <input type="text" name="first_name" placeholder="Juan"
                                   value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>" required>
                        </div>
                        <div class="form-group full">
                            <label>Middle Name</label>
                            <input type="text" name="middle_name" placeholder="Santos"
                                   value="<?= htmlspecialchars($_POST['middle_name'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label>Password <span class="required-star">*</span></label>
                            <input type="password" name="password" placeholder="Min. 6 characters" required>
                        </div>
                        <div class="form-group">
                            <label>Repeat Password <span class="required-star">*</span></label>
                            <input type="password" name="repeat_password" placeholder="Confirm password" required>
                        </div>
                        <div class="form-group full">
                            <label>Email</label>
                            <input type="email" name="email" placeholder="you@email.com"
                                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label>Course</label>
                            <input type="text" name="course" placeholder="BSIT"
                                   value="<?= htmlspecialchars($_POST['course'] ?? 'BSIT') ?>">
                        </div>
                        <div class="form-group">
                            <label>Address</label>
                            <input type="text" name="address" placeholder="City, Province"
                                   value="<?= htmlspecialchars($_POST['address'] ?? '') ?>">
                        </div>
                    </div>

                    <button type="submit" class="btn-register">Create Account</button>
                </form>

                <div class="login-link">
                    Already have an account? <a href="index.php">Login</a>
                </div>
            </div>

            <div class="reg-side">
                <!-- Illustration SVG -->
                <svg viewBox="0 0 300 280" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <!-- Background shapes -->
                    <circle cx="150" cy="130" r="100" fill="#e0f4ff" opacity="0.6"/>
                    <!-- Monitor/Card -->
                    <rect x="130" y="60" width="130" height="110" rx="14" fill="white" stroke="#bde5f8" stroke-width="2"/>
                    <rect x="138" y="70" width="114" height="75" rx="8" fill="#f0faff"/>
                    <!-- Person icon on card -->
                    <circle cx="195" cy="95" r="18" fill="#bde5f8"/>
                    <circle cx="195" cy="89" r="9" fill="#4aaed9"/>
                    <path d="M178 112 Q195 104 212 112" stroke="#4aaed9" stroke-width="3" stroke-linecap="round"/>
                    <!-- Lines -->
                    <rect x="148" y="155" width="60" height="5" rx="3" fill="#bde5f8"/>
                    <rect x="148" y="165" width="45" height="5" rx="3" fill="#d0effc"/>
                    <!-- Person standing -->
                    <circle cx="90" cy="100" r="22" fill="#fde8c8"/>
                    <path d="M68 160 Q68 135 90 130 Q112 135 112 160 L115 220 Q90 225 65 220 Z" fill="#6b3fa0"/>
                    <!-- Arms -->
                    <path d="M112 145 Q135 135 148 120" stroke="#fde8c8" stroke-width="8" stroke-linecap="round"/>
                    <!-- Laptop -->
                    <rect x="72" y="215" width="60" height="8" rx="4" fill="#4aaed9" opacity="0.5"/>
                    <!-- Hair -->
                    <ellipse cx="90" cy="86" rx="18" ry="8" fill="#c9940a"/>
                    <!-- Face -->
                    <circle cx="84" cy="101" r="2" fill="#5a7a8a"/>
                    <circle cx="96" cy="101" r="2" fill="#5a7a8a"/>
                    <path d="M86 108 Q90 112 94 108" stroke="#5a7a8a" stroke-width="1.5" stroke-linecap="round" fill="none"/>
                </svg>

                <div class="reg-side-text">
                    Create your account to access the<br>
                    <strong style="color:var(--purple)">CCS Sit-in Monitoring</strong><br>
                    system and manage your sessions.
                </div>
            </div>
        </div>
    </main>

    <footer>&copy; 2026 College of Computer Studies</footer>
</body>
</html>
