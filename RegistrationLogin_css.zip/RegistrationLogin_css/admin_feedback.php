<?php
session_start();
if (!isset($_SESSION['admin_id'])) { header("Location: index.php"); exit(); }
require_once 'config.php';

// Handle admin reply
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_reply'])) {
    $to_sid = (int)$_POST['to_student_id'];
    $reply_body = trim($_POST['reply_body']);
    $parent_id = (int)$_POST['parent_msg_id'];
    if ($reply_body) {
        $ins = $conn->prepare("INSERT INTO messages (student_id, sender, subject, body, parent_id) VALUES (?, 'admin', 'Message from Admin', ?, ?)");
        $ins->bind_param("isi", $to_sid, $reply_body, $parent_id);
        $ins->execute(); $ins->close();
    }
    header("Location: admin_feedback.php"); exit();
}

// Fetch all feedback with student info
$feedbacks = $conn->query("
    SELECT sf.*, s.first_name, s.last_name, s.id_number, s.course,
           ss.lab, ss.purpose, ss.login_time, ss.logout_time
    FROM session_feedback sf
    JOIN students s ON s.id = sf.student_id
    JOIN sit_in_sessions ss ON ss.id = sf.session_id
    ORDER BY sf.created_at DESC
")->fetch_all(MYSQLI_ASSOC);

// Fetch all students who have messages
$students_msgs = $conn->query("
    SELECT DISTINCT s.id, s.first_name, s.last_name, s.id_number,
           (SELECT COUNT(*) FROM messages m WHERE m.student_id=s.id AND m.sender='student' AND m.is_read=0) as unread
    FROM messages m
    JOIN students s ON s.id = m.student_id
    ORDER BY unread DESC, s.last_name
")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Feedback & Messages – Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/admin.css">
    <style>
        .feedback-tabs { display:flex; gap:0.5rem; margin-bottom:1.5rem; }
        .tab-btn { padding:0.6rem 1.4rem; border-radius:8px; border:none; font-family:inherit; font-weight:700; font-size:0.88rem; cursor:pointer; background:rgba(255,255,255,0.07); color:#ccc; transition:all 0.2s; }
        .tab-btn.active { background:var(--gold,#d4a017); color:#1a0a2e; }
        .tab-panel { display:none; } .tab-panel.active { display:block; }
        .stars { color:#f0c040; font-size:1.1rem; letter-spacing:1px; }
        .reply-box { background:rgba(255,255,255,0.04); border-radius:10px; padding:1rem; margin-top:0.75rem; border:1px solid rgba(255,255,255,0.08); }
        .reply-textarea { width:100%; background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.15); border-radius:8px; color:#fff; padding:0.6rem; font-size:0.84rem; font-family:inherit; resize:vertical; min-height:70px; }
        .btn-reply { background:var(--gold,#d4a017); color:#1a0a2e; border:none; padding:0.5rem 1.2rem; border-radius:7px; font-weight:800; font-size:0.84rem; cursor:pointer; margin-top:0.5rem; }
        .msg-thread { max-height:200px; overflow-y:auto; margin-bottom:0.5rem; }
        .msg-bubble { padding:0.5rem 0.75rem; border-radius:8px; margin-bottom:0.4rem; font-size:0.83rem; line-height:1.5; }
        .msg-admin { background:rgba(212,160,23,0.12); border-left:3px solid #d4a017; }
        .msg-student { background:rgba(255,255,255,0.05); border-left:3px solid #7b5ea7; }
        .badge-unread { background:#e74c3c; color:#fff; font-size:0.65rem; padding:2px 7px; border-radius:20px; font-weight:800; margin-left:6px; }
    </style>
    <link rel="stylesheet" href="assets/schema.css">
</head>
<body>
<!-- include your admin nav here -->

<main style="padding:2rem; max-width:1100px; margin:0 auto;">
    <h2 style="color:var(--gold,#d4a017); margin-bottom:1.5rem;">📝 Feedback & Messages</h2>

    <div class="feedback-tabs">
        <button class="tab-btn active" onclick="switchTab('feedbackTab', this)">⭐ Session Feedback</button>
        <button class="tab-btn" onclick="switchTab('messagesTab', this)">✉️ Student Messages</button>
    </div>

    <!-- FEEDBACK TAB -->
    <div id="feedbackTab" class="tab-panel active">
        <?php if (empty($feedbacks)): ?>
            <div style="color:var(--text-muted,#888); text-align:center; padding:2rem;">No feedback submitted yet.</div>
        <?php else: ?>
        <table style="width:100%; border-collapse:collapse; font-size:0.87rem;">
            <thead>
                <tr style="background:rgba(255,255,255,0.05); color:var(--gold,#d4a017); text-transform:uppercase; font-size:0.75rem;">
                    <th style="padding:0.75rem; text-align:left;">Student</th>
                    <th style="padding:0.75rem; text-align:left;">Session</th>
                    <th style="padding:0.75rem; text-align:center;">Rating</th>
                    <th style="padding:0.75rem; text-align:left;">Feedback</th>
                    <th style="padding:0.75rem; text-align:left;">Date</th>
                    <th style="padding:0.75rem; text-align:center;">Action</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($feedbacks as $f): ?>
                <tr style="border-bottom:1px solid rgba(255,255,255,0.06);">
                    <td style="padding:0.75rem;">
                        <div style="font-weight:700;"><?= htmlspecialchars($f['first_name'].' '.$f['last_name']) ?></div>
                        <div style="font-size:0.75rem; color:#aaa;"><?= htmlspecialchars($f['id_number']) ?> · <?= htmlspecialchars($f['course']) ?></div>
                    </td>
                    <td style="padding:0.75rem;">
                        <div><?= htmlspecialchars($f['lab']) ?></div>
                        <div style="font-size:0.75rem; color:#aaa;"><?= htmlspecialchars($f['purpose']) ?></div>
                    </td>
                    <td style="padding:0.75rem; text-align:center;">
                        <div class="stars"><?= str_repeat('★', $f['rating']) . str_repeat('☆', 5 - $f['rating']) ?></div>
                        <div style="font-size:0.75rem; color:#aaa;"><?= $f['rating'] ?>/5</div>
                    </td>
                    <td style="padding:0.75rem; max-width:220px;">
                        <?= $f['feedback'] ? nl2br(htmlspecialchars($f['feedback'])) : '<span style="color:#666;">No comment</span>' ?>
                    </td>
                    <td style="padding:0.75rem; font-size:0.78rem; color:#aaa;"><?= date('M d, Y h:i A', strtotime($f['created_at'])) ?></td>
                    <td style="padding:0.75rem; text-align:center;">
                        <button class="btn-reply" onclick="openReplyModal(<?= $f['student_id'] ?>, '<?= htmlspecialchars($f['first_name'].' '.$f['last_name']) ?>', 0)">
                            💬 Reply
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>

    <!-- MESSAGES TAB -->
    <div id="messagesTab" class="tab-panel">
        <?php if (empty($students_msgs)): ?>
            <div style="color:#888; text-align:center; padding:2rem;">No message threads yet.</div>
        <?php else: foreach ($students_msgs as $st): ?>
            <?php
            $thread = $conn->query("SELECT * FROM messages WHERE student_id={$st['id']} ORDER BY created_at ASC")->fetch_all(MYSQLI_ASSOC);
            ?>
            <div style="background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); border-radius:12px; padding:1rem; margin-bottom:1rem;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.75rem;">
                    <div>
                        <span style="font-weight:800; color:#fff;"><?= htmlspecialchars($st['first_name'].' '.$st['last_name']) ?></span>
                        <span style="font-size:0.78rem; color:#aaa; margin-left:0.5rem;"><?= htmlspecialchars($st['id_number']) ?></span>
                        <?php if ($st['unread'] > 0): ?>
                            <span class="badge-unread"><?= $st['unread'] ?> new</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="msg-thread">
                    <?php foreach ($thread as $tm): ?>
                        <div class="msg-bubble <?= $tm['sender'] === 'admin' ? 'msg-admin' : 'msg-student' ?>">
                            <span style="font-weight:700; font-size:0.75rem; color:<?= $tm['sender']==='admin' ? '#d4a017' : '#b39ddb' ?>;">
                                <?= $tm['sender'] === 'admin' ? '🛡 Admin' : '🎓 Student' ?>
                            </span>
                            <span style="font-size:0.72rem; color:#888; margin-left:0.5rem;"><?= date('M d, h:i A', strtotime($tm['created_at'])) ?></span>
                            <div style="margin-top:0.25rem; color:#ddd;"><?= nl2br(htmlspecialchars($tm['body'])) ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <form method="POST" style="margin-top:0.5rem;">
                    <input type="hidden" name="to_student_id" value="<?= $st['id'] ?>">
                    <input type="hidden" name="parent_msg_id" value="<?= end($thread)['id'] ?? 0 ?>">
                    <textarea name="reply_body" class="reply-textarea" placeholder="Write a reply to <?= htmlspecialchars($st['first_name']) ?>..."></textarea>
                    <button type="submit" name="send_reply" class="btn-reply">Send Reply ➤</button>
                </form>
            </div>
        <?php endforeach; endif; ?>
    </div>
</main>

<!-- Quick Reply Modal (from Feedback tab) -->
<div id="replyModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.6); z-index:9999; align-items:center; justify-content:center;">
    <div style="background:#1e0d3e; border-radius:14px; padding:1.5rem; max-width:420px; width:90%; border:1px solid rgba(255,255,255,0.12);">
        <div style="font-weight:800; color:var(--gold,#d4a017); font-size:1.1rem; margin-bottom:1rem;">💬 Reply to <span id="replyStudentName"></span></div>
        <form method="POST">
            <input type="hidden" name="to_student_id" id="replyStudentId">
            <input type="hidden" name="parent_msg_id" value="0">
            <textarea name="reply_body" class="reply-textarea" placeholder="Write your message..." style="min-height:100px;"></textarea>
            <div style="display:flex; gap:0.5rem; margin-top:0.75rem;">
                <button type="button" onclick="document.getElementById('replyModal').style.display='none'" style="flex:1; padding:0.6rem; background:rgba(255,255,255,0.07); border:none; border-radius:8px; color:#ccc; cursor:pointer; font-family:inherit;">Cancel</button>
                <button type="submit" name="send_reply" class="btn-reply" style="flex:2; padding:0.6rem;">Send ➤</button>
            </div>
        </form>
    </div>
</div>

<script>
function switchTab(tabId, btn) {
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.getElementById(tabId).classList.add('active');
    btn.classList.add('active');
}
function openReplyModal(studentId, studentName, msgId) {
    document.getElementById('replyStudentId').value = studentId;
    document.getElementById('replyStudentName').textContent = studentName;
    document.getElementById('replyModal').style.display = 'flex';
}
</script>
</body>
</html>