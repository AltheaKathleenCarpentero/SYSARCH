<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php"); exit();
}
require_once 'config.php';

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM students WHERE id = ?");
    $stmt->bind_param("i", $id); $stmt->execute(); $stmt->close();
    header("Location: admin_students.php"); exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_id'])) {
    $stmt = $conn->prepare("UPDATE students SET first_name=?, last_name=?, middle_name=?, course=?, course_level=?, email=?, address=?, sessions=? WHERE id=?");
    $stmt->bind_param("ssssissii",
        $_POST['first_name'], $_POST['last_name'], $_POST['middle_name'],
        $_POST['course'], $_POST['course_level'], $_POST['email'],
        $_POST['address'], $_POST['sessions'], $_POST['edit_id']
    );
    $stmt->execute(); $stmt->close();
    header("Location: admin_students.php"); exit();
}

if (isset($_POST['reset_sessions'])) {
    $conn->query("UPDATE students SET sessions = 30");
    header("Location: admin_students.php"); exit();
}

$students = $conn->query("SELECT * FROM students ORDER BY last_name ASC")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Students – CCS Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/admin.css">
    <link rel="stylesheet" href="assets/schema.css">
</head>
<body>
<nav>
    <span class="nav-brand">🖥️ CCS Admin Panel</span>
    <div class="nav-links">
        <a href="admin.php" class="active">Dashboard</a>
        <a href="#" onclick="openModal('searchModal')">Search</a>
        <a href="admin_students.php">Students</a>
        
        <!-- Sit-in Dropdown -->
        <div class="nav-dropdown">
            <div class="nav-drop-toggle">Sit-in</div>
            <div class="nav-drop-menu">
                <a href="admin_sitin.php">📋 Sit-in</a>
                <a href="admin_sitin_records.php">📊 View Sit-in Records</a>
                <a href="admin_generate_reports.php">📥 Generate Reports</a>
            </div>
        </div>
        
        <a href="admin_leaderboard.php">🏆 Leaderboard</a>
        <a href="admin_feedback.php">Feedback Reports</a>
        <a href="admin_reservation.php">Reservation</a>
        <a href="?logout=1" class="logout-btn">Log out</a>
    </div>
</nav>

<div class="modal-overlay" id="searchModal" style="display:none">
    <div class="modal-box">
        <div class="modal-header"><span>🔍 Search Student</span><button class="modal-close" onclick="closeModal('searchModal')">✕</button></div>
        <div class="modal-body">
            <input type="text" id="searchInput" class="modal-input" placeholder="Name or ID number...">
            <div id="searchResults" class="search-results"></div>
        </div>
        <div class="modal-footer"><button class="btn-primary" onclick="searchStudent()">Search</button></div>
    </div>
</div>

<div class="modal-overlay" id="editModal" style="display:none">
    <div class="modal-box" style="max-width:500px">
        <div class="modal-header"><span>✏️ Edit Student</span><button class="modal-close" onclick="closeModal('editModal')">✕</button></div>
        <form method="POST">
            <div class="modal-body" style="display:grid; grid-template-columns:1fr 1fr; gap:0.75rem">
                <input type="hidden" name="edit_id" id="edit_id">
                <div class="form-group" style="grid-column:1/-1"><label>First Name</label><input type="text" name="first_name" id="edit_first_name" class="modal-input" required></div>
                <div class="form-group"><label>Last Name</label><input type="text" name="last_name" id="edit_last_name" class="modal-input" required></div>
                <div class="form-group"><label>Middle Name</label><input type="text" name="middle_name" id="edit_middle_name" class="modal-input"></div>
                <div class="form-group"><label>Course</label><input type="text" name="course" id="edit_course" class="modal-input"></div>
                <div class="form-group"><label>Year Level</label><input type="number" name="course_level" id="edit_course_level" class="modal-input" min="1" max="5"></div>
                <div class="form-group"><label>Sessions Remaining</label><input type="number" name="sessions" id="edit_sessions" class="modal-input" min="0" max="30"></div>
                <div class="form-group" style="grid-column:1/-1"><label>Email</label><input type="email" name="email" id="edit_email" class="modal-input"></div>
                <div class="form-group" style="grid-column:1/-1"><label>Address</label><input type="text" name="address" id="edit_address" class="modal-input"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeModal('editModal')">Cancel</button>
                <button type="submit" class="btn-primary">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<div class="modal-overlay" id="viewModal" style="display:none">
    <div class="modal-box" style="max-width:420px; text-align:left">
        <div class="modal-header"><span>👤 Student Profile</span><button class="modal-close" onclick="closeModal('viewModal')">✕</button></div>
        <div class="modal-body" id="viewBody"></div>
        <div class="modal-footer"><button class="btn-secondary" onclick="closeModal('viewModal')">Close</button></div>
    </div>
</div>

<main>
    <div class="page-title">Student Information</div>
    <div class="table-toolbar">
        <div style="display:flex; gap:0.75rem">
            <form method="POST" style="display:inline">
                <button type="submit" name="reset_sessions" class="btn-danger" onclick="return confirm('Reset ALL sessions to 30?')">🔄 Reset All Sessions</button>
            </form>
        </div>
        <input type="text" id="tableSearch" class="table-search" placeholder="Filter students..." oninput="filterTable()">
    </div>
    <div class="card">
        <div class="table-wrap">
            <table id="studentsTable">
                <thead>
                    <tr><th>ID Number</th><th>Name</th><th>Course</th><th>Year</th><th>Email</th><th>Sessions</th><th>Actions</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $s): ?>
                    <tr>
                        <td><?= htmlspecialchars($s['id_number']) ?></td>
                        <td><?= htmlspecialchars($s['first_name'].' '.$s['last_name']) ?></td>
                        <td><?= htmlspecialchars($s['course']) ?></td>
                        <td><?= $s['course_level'] ?></td>
                        <td><?= htmlspecialchars($s['email'] ?? '—') ?></td>
                        <td><span class="session-pill <?= ($s['sessions'] ?? 30) <= 5 ? 'session-low' : '' ?>"><?= $s['sessions'] ?? 30 ?></span></td>
                        <td>
                            <button class="btn-edit" onclick="openView(<?= htmlspecialchars(json_encode($s)) ?>)">View</button>
                            <button class="btn-edit" onclick="openEdit(<?= htmlspecialchars(json_encode($s)) ?>)">Edit</button>
                            <a href="?delete=<?= $s['id'] ?>" class="btn-del" onclick="return confirm('Delete this student permanently?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
<footer>&copy; 2026 College of Computer Studies</footer>
<script>
function openEdit(s) {
    document.getElementById('edit_id').value = s.id;
    document.getElementById('edit_first_name').value = s.first_name;
    document.getElementById('edit_last_name').value = s.last_name;
    document.getElementById('edit_middle_name').value = s.middle_name || '';
    document.getElementById('edit_course').value = s.course;
    document.getElementById('edit_course_level').value = s.course_level;
    document.getElementById('edit_email').value = s.email || '';
    document.getElementById('edit_address').value = s.address || '';
    document.getElementById('edit_sessions').value = s.sessions ?? 30;
    document.getElementById('editModal').style.display = 'flex';
}
function openView(s) {
    document.getElementById('viewBody').innerHTML = `
        <div style="display:flex;flex-direction:column;gap:0.6rem;font-size:0.9rem">
            <div><strong>ID Number:</strong> ${s.id_number}</div>
            <div><strong>Full Name:</strong> ${s.first_name} ${s.middle_name||''} ${s.last_name}</div>
            <div><strong>Course:</strong> ${s.course} — Year ${s.course_level}</div>
            <div><strong>Email:</strong> ${s.email||'—'}</div>
            <div><strong>Address:</strong> ${s.address||'—'}</div>
            <div><strong>Sessions Remaining:</strong> <span class="session-pill ${(s.sessions??30)<=5?'session-low':''}">${s.sessions??30}</span></div>
            <div><strong>Registered:</strong> ${s.created_at}</div>
        </div>`;
    openModal('viewModal');
}
function openModal(id)  { document.getElementById(id).style.display = 'flex'; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }
function filterTable() {
    const q = document.getElementById('tableSearch').value.toLowerCase();
    document.querySelectorAll('#studentsTable tbody tr').forEach(row => {
        row.style.display = row.innerText.toLowerCase().includes(q) ? '' : 'none';
    });
}
function searchStudent() {
    const q = document.getElementById('searchInput').value.trim(); if (!q) return;
    fetch('admin_search.php?q=' + encodeURIComponent(q)).then(r => r.text()).then(html => { document.getElementById('searchResults').innerHTML = html; });
}
document.getElementById('searchInput')?.addEventListener('keydown', e => { if (e.key === 'Enter') searchStudent(); });
</script>
</body>
</html>