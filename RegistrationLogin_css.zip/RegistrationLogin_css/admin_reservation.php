<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php"); exit();
}
require_once 'config.php';

// Handle approve / reject
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['res_id'])) {
    $res_id = intval($_POST['res_id']);
    $action = $_POST['action']; // 'Approved' or 'Rejected'

    // Fetch reservation + student details
    $res = $conn->query("
        SELECT r.*, CONCAT(s.first_name,' ',s.last_name) AS student_name, s.id AS sid,
               s.id_number, s.course, s.course_level
        FROM reservations r JOIN students s ON s.id = r.student_id
        WHERE r.id = $res_id
    ")->fetch_assoc();

    if ($res) {
        if ($action === 'Approved') {
            $conn->query("UPDATE reservations SET status='Approved' WHERE id=$res_id");

            $subject = "Reservation Approved – Lab {$res['lab']}, PC {$res['pc_number']}";
            $body  = "Dear {$res['student_name']},\n\n";
            $body .= "We are pleased to inform you that your laboratory reservation has been APPROVED.\n\n";
            $body .= "─────────────────────────────\n";
            $body .= "RESERVATION DETAILS\n";
            $body .= "─────────────────────────────\n";
            $body .= "Student ID   : {$res['id_number']}\n";
            $body .= "Laboratory   : Lab {$res['lab']}\n";
            $body .= "PC Assigned  : PC {$res['pc_number']}\n";
            $body .= "Purpose      : {$res['purpose']}\n";
            $body .= "Date         : ".date('F d, Y', strtotime($res['reservation_date']))."\n";
            $body .= "Time         : ".substr($res['reservation_time'], 0, 5)."\n";
            $body .= "─────────────────────────────\n\n";
            $body .= "Please arrive on time and ensure that your workstation is clean before leaving.\n";
            $body .= "Failure to appear without prior notice may result in a session penalty.\n\n";
            $body .= "Should you have any concerns, feel free to message the administrator.\n\n";
            $body .= "Regards,\nCCS Laboratory Administrator\nCollege of Computer Studies";

        } else {
            $conn->query("UPDATE reservations SET status='Cancelled' WHERE id=$res_id");

            $subject = "Reservation Not Approved – Lab {$res['lab']}";
            $body  = "Dear {$res['student_name']},\n\n";
            $body .= "We regret to inform you that your laboratory reservation request has been DECLINED.\n\n";
            $body .= "─────────────────────────────\n";
            $body .= "RESERVATION DETAILS\n";
            $body .= "─────────────────────────────\n";
            $body .= "Laboratory   : Lab {$res['lab']}\n";
            $body .= "PC Requested : PC {$res['pc_number']}\n";
            $body .= "Purpose      : {$res['purpose']}\n";
            $body .= "Date         : ".date('F d, Y', strtotime($res['reservation_date']))."\n";
            $body .= "Time         : ".substr($res['reservation_time'], 0, 5)."\n";
            $body .= "─────────────────────────────\n\n";
            $body .= "This may be due to a scheduling conflict, lab unavailability, or policy reasons.\n";
            $body .= "You are welcome to submit a new reservation for a different date or time slot.\n\n";
            $body .= "If you believe this was an error, please contact the administrator directly.\n\n";
            $body .= "Regards,\nCCS Laboratory Administrator\nCollege of Computer Studies";
        }

        // Insert message to student
        $sid = intval($res['sid']);
        $mstmt = $conn->prepare("INSERT INTO messages (student_id, sender, subject, body, is_read, created_at) VALUES (?, 'admin', ?, ?, 0, NOW())");
        $mstmt->bind_param("iss", $sid, $subject, $body);
        $mstmt->execute();
        $mstmt->close();
    }

    header("Location: admin_reservation.php"); exit();
}

$reservations = $conn->query("
    SELECT r.*, CONCAT(s.first_name,' ',s.last_name) AS student_name, s.id_number, s.course, s.course_level
    FROM reservations r
    JOIN students s ON s.id = r.student_id
    ORDER BY FIELD(r.status,'Pending','Approved','Cancelled','Completed'), r.reservation_date ASC, r.reservation_time ASC
")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reservations – CCS Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/admin.css">
    <style>
        .filter-tabs { display:flex; gap:0.5rem; margin-bottom:1.5rem; flex-wrap:wrap; }
        .ftab { padding:0.5rem 1.2rem; border-radius:8px; font-size:0.82rem; font-weight:800; cursor:pointer; border:1.5px solid rgba(212,160,23,0.25); color:var(--text-muted); background:transparent; transition:all 0.2s; }
        .ftab.active { background:var(--gold); color:#1a0a2e; border-color:var(--gold); }
        .res-table { width:100%; border-collapse:collapse; font-size:0.86rem; }
        .res-table th { padding:0.65rem 1rem; text-align:left; font-size:0.7rem; font-weight:800; text-transform:uppercase; letter-spacing:0.07em; color:var(--text-muted); border-bottom:1px solid var(--border); }
        .res-table td { padding:0.75rem 1rem; border-bottom:1px solid rgba(212,160,23,0.07); color:var(--text); vertical-align:middle; }
        .res-table tbody tr:hover { background:rgba(212,160,23,0.04); }
        .status-pending   { background:rgba(212,160,23,0.15); color:var(--gold); padding:2px 10px; border-radius:12px; font-weight:800; font-size:0.78rem; }
        .status-approved  { background:rgba(46,213,115,0.15); color:#5de898; padding:2px 10px; border-radius:12px; font-weight:800; font-size:0.78rem; }
        .status-cancelled { background:rgba(255,80,80,0.12); color:#ff9090; padding:2px 10px; border-radius:12px; font-weight:800; font-size:0.78rem; }
        .status-completed { background:rgba(100,100,255,0.12); color:#a0a0ff; padding:2px 10px; border-radius:12px; font-weight:800; font-size:0.78rem; }
        .btn-approve { padding:4px 12px; font-size:0.75rem; border-radius:6px; background:rgba(46,213,115,0.12); border:1px solid rgba(46,213,115,0.3); color:#5de898; cursor:pointer; font-weight:800; margin-right:4px; transition:all 0.2s; }
        .btn-approve:hover { background:rgba(46,213,115,0.25); }
        .btn-reject  { padding:4px 12px; font-size:0.75rem; border-radius:6px; background:rgba(255,80,80,0.1); border:1px solid rgba(255,80,80,0.3); color:#ff9090; cursor:pointer; font-weight:800; transition:all 0.2s; }
        .btn-reject:hover  { background:rgba(255,80,80,0.22); }
        .empty-note { text-align:center; color:var(--text-muted); padding:2rem; font-size:0.9rem; }
    </style>
    <link rel="stylesheet" href="assets/schema.css">
</head>
<body>
<nav>
    <span class="nav-brand">🖥️ CCS Admin Panel</span>
    <div class="nav-links">
        <a href="admin.php">Dashboard</a>
        <a href="#" onclick="openModal('searchModal')">Search</a>
        <a href="admin_students.php">Students</a>
        <div class="nav-dropdown">
            <div class="nav-drop-toggle">Sit-in</div>
            <div class="nav-drop-menu">
                <a href="admin_sitin.php">📋 Sit-in</a>
                <a href="admin_sitin_records.php">📊 View Sit-in Records</a>
                <a href="admin_generate_reports.php">📥 Generate Reports</a>
            </div>
        </div>
        <a href="admin_leaderboard.php">🏆 Leaderboard</a>
        <a href="admin_feedback.php">Feedback Reports</a>
        <a href="admin_reservation.php" class="active">Reservation</a>
        <a href="admin.php?logout=1" class="logout-btn">Log out</a>
    </div>
</nav>

<!-- Search Modal -->
<div class="modal-overlay" id="searchModal" style="display:none">
    <div class="modal-box">
        <div class="modal-header"><span>🔍 Search Student</span><button class="modal-close" onclick="closeModal('searchModal')">✕</button></div>
        <div class="modal-body">
            <input type="text" id="searchInput" class="modal-input" placeholder="Name or ID number...">
            <div id="searchResults" class="search-results"></div>
        </div>
        <div class="modal-footer"><button class="btn-primary" onclick="searchStudent()">Search</button></div>
    </div>
</div>

<main>
    <div class="page-title">🖥️ Reservation Management</div>

    <div class="filter-tabs">
        <button class="ftab active" onclick="filterTable('all', this)">All</button>
        <button class="ftab" onclick="filterTable('Pending', this)">⏳ Pending</button>
        <button class="ftab" onclick="filterTable('Approved', this)">✅ Approved</button>
        <button class="ftab" onclick="filterTable('Cancelled', this)">❌ Cancelled</button>
        <button class="ftab" onclick="filterTable('Completed', this)">🏁 Completed</button>
    </div>

    <div class="card">
        <div class="table-wrap">
            <table class="res-table" id="resTable">
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>ID No.</th>
                        <th>Lab</th>
                        <th>PC</th>
                        <th>Purpose</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($reservations)): ?>
                    <tr><td colspan="9" class="empty-note">No reservations found.</td></tr>
                <?php else: foreach ($reservations as $r): ?>
                <tr data-status="<?= $r['status'] ?>">
                    <td><strong><?= htmlspecialchars($r['student_name']) ?></strong><br><span style="font-size:0.72rem;color:var(--text-muted)"><?= htmlspecialchars($r['course']) ?> Y<?= $r['course_level'] ?></span></td>
                    <td><?= htmlspecialchars($r['id_number']) ?></td>
                    <td>Lab <?= htmlspecialchars($r['lab']) ?></td>
                    <td><?= $r['pc_number'] ? 'PC '.$r['pc_number'] : '—' ?></td>
                    <td><?= htmlspecialchars($r['purpose']) ?></td>
                    <td><?= date('M d, Y', strtotime($r['reservation_date'])) ?></td>
                    <td><?= substr($r['reservation_time'], 0, 5) ?></td>
                    <td><span class="status-<?= strtolower($r['status']) ?>"><?= $r['status'] ?></span></td>
                    <td>
                        <?php if ($r['status'] === 'Pending'): ?>
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="res_id" value="<?= $r['id'] ?>">
                            <button type="submit" name="action" value="Approved" class="btn-approve" onclick="return confirm('Approve this reservation?')">✓ Approve</button>
                            <button type="submit" name="action" value="Rejected" class="btn-reject"  onclick="return confirm('Reject this reservation?')">✕ Reject</button>
                        </form>
                        <?php else: ?>—<?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<footer>&copy; 2026 College of Computer Studies</footer>
<script>
function filterTable(status, btn) {
    document.querySelectorAll('.ftab').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('#resTable tbody tr').forEach(row => {
        row.style.display = (status === 'all' || row.dataset.status === status) ? '' : 'none';
    });
}
function openModal(id)  { document.getElementById(id).style.display = 'flex'; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }
function searchStudent() {
    const q = document.getElementById('searchInput').value.trim(); if (!q) return;
    fetch('admin_search.php?q=' + encodeURIComponent(q)).then(r => r.text()).then(html => { document.getElementById('searchResults').innerHTML = html; });
}
document.getElementById('searchInput')?.addEventListener('keydown', e => { if (e.key==='Enter') searchStudent(); });
</script>
</body>
</html>