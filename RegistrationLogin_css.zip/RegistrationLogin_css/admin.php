<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php"); exit();
}
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php"); exit();
}

require_once 'config.php';

if (isset($_GET['del_ann'])) {
    $id = intval($_GET['del_ann']);
    $conn->query("DELETE FROM announcements WHERE id = $id");
    header("Location: admin.php"); exit();
}
// Post announcement
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['announcement'])) {
    $msg = trim($_POST['announcement']);
    if (!empty($msg)) {
        $stmt = $conn->prepare("INSERT INTO announcements (message) VALUES (?)");
        $stmt->bind_param("s", $msg);
        $stmt->execute();
        $stmt->close();
    }
}

// Stats
$total_students  = $conn->query("SELECT COUNT(*) FROM students")->fetch_row()[0];
$currently_sitin = $conn->query("SELECT COUNT(*) FROM sit_in_sessions WHERE logout_time IS NULL")->fetch_row()[0];
$total_sitin     = $conn->query("SELECT COUNT(*) FROM sit_in_sessions")->fetch_row()[0];

// Course distribution
$course_data = [];
$language_data = $conn->query("SELECT purpose, COUNT(*) as cnt FROM sit_in_sessions WHERE purpose IN ('Java','C','C++','C#','Python','JavaScript','HTML/CSS','SQL','PHP','Others') GROUP BY purpose ORDER BY cnt DESC")->fetch_all(MYSQLI_ASSOC);
$res = $conn->query("SELECT st.course, COUNT(*) as cnt FROM sit_in_sessions s JOIN students st ON s.student_id = st.id GROUP BY st.course");
while ($row = $res->fetch_assoc()) $course_data[] = $row;

// Announcements
$announcements = [];
$res = $conn->query("SELECT * FROM announcements ORDER BY created_at DESC");
while ($row = $res->fetch_assoc()) $announcements[] = $row;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin – CCS Sit-in Monitoring</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/admin.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
</head>
<body>

    <!-- NAV -->
    <nav>
        <span class="nav-brand">College of Computer Studies Admin</span>
        <div class="nav-links">
            <a href="admin.php" class="active">Home</a>
            <a href="#" onclick="openModal('searchModal')">Search</a>
            <a href="admin_students.php">Students</a>
            <a href="admin_sitin.php">Sit-in</a>
            <a href="admin_sitin_records.php">View Sit-in Records</a>
        </div>
        <a href="?logout=1" class="logout-btn">Log out</a>
    </nav>  

<!-- SEARCH MODAL -->
<div class="modal-overlay" id="searchModal" style="display:none">
    <div class="modal-box">
        <div class="modal-header">
            <span>🔍 Search Student by ID</span>
            <button class="modal-close" onclick="closeModal('searchModal')">✕</button>
        </div>
        <div class="modal-body">
            <div class="sitin-id-row">
                <input type="text" id="searchInput" class="modal-input" placeholder="Enter student ID number...">
                <button class="btn-find" onclick="searchStudent()">🔍 Find</button>
            </div>
            <div id="searchResults" style="margin-top:1rem"></div>
        </div>
    </div>
</div>

<div class="modal-overlay" id="annModal" style="display:none">
    <div class="modal-box">
        <div class="modal-header">
            <span>📢 Post Announcement</span>
            <button class="modal-close" onclick="closeModal('annModal')">✕</button>
        </div>
        <form method="POST">
            <div class="modal-body">
                <textarea name="announcement" class="modal-input" rows="4" placeholder="Type your announcement..." required style="resize:vertical"></textarea>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeModal('annModal')">Cancel</button>
                <button type="submit" class="btn-primary">Post</button>
            </div>
        </form>
    </div>
</div>


    <!-- MAIN -->
<main>
    <div class="page-title">Admin Dashboard</div>

    <div class="stats-row">
        <div class="stat-card">
            <div class="stat-icon">👥</div>
            <div class="stat-num"><?= $total_students ?></div>
            <div class="stat-label">Total Students</div>
        </div>
        <div class="stat-card stat-active">
            <div class="stat-icon">🟢</div>
            <div class="stat-num"><?= $currently_sitin ?></div>
            <div class="stat-label">Currently Sitting In</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">📋</div>
            <div class="stat-num"><?= $total_sitin ?></div>
            <div class="stat-label">Total Sit-in Sessions</div>
        </div>
    </div>

    <div class="dashboard-grid">

        <div class="card">
            <div class="card-header">📊 Sit-ins by Course</div>
            <div class="card-body" style="display:flex; align-items:center; justify-content:center; min-height:220px">
                <canvas id="courseChart" style="max-height:200px"></canvas>
            </div>
        </div>

        <div class="card">
            <div class="card-header">💻 Sit-ins by Programming Language</div>
            <div class="card-body" style="display:flex; align-items:center; justify-content:center; min-height:220px">
                <canvas id="langChart" style="max-height:200px"></canvas>
            </div>
        </div>

        <div class="card" style="grid-column: 1 / -1">
            <div class="card-header" style="display:flex; justify-content:space-between; align-items:center">
                <span>📢 Announcements</span>
                <button class="btn-sm" onclick="openModal('annModal')">+ Post New</button>
            </div>
            <div class="card-body">
                <?php if (empty($announcements)): ?>
                    <p style="color:var(--text-muted); font-size:0.88rem; font-weight:600">No announcements yet.</p>
                <?php else: foreach ($announcements as $a): ?>
                <div class="ann-item">
                    <div class="ann-meta"><?= date('M d, Y H:i', strtotime($a['created_at'])) ?></div>
                    <div class="ann-text"><?= nl2br(htmlspecialchars($a['message'])) ?></div>
                    <a href="?del_ann=<?= $a['id'] ?>" class="btn-del-sm" onclick="return confirm('Delete this announcement?')">✕ Delete</a>
                </div>
                <?php endforeach; endif; ?>
            </div>
        </div>

    </div>
</main>

    <footer>&copy; 2026 College of Computer Studies</footer>

<script>
    const courseData = <?= json_encode($course_data) ?>;
    const labels = courseData.length ? courseData.map(d => d.course) : ['No Data'];
    const data   = courseData.length ? courseData.map(d => parseInt(d.cnt)) : [1];
    new Chart(document.getElementById('courseChart'), {
        type: 'pie',
        data: { labels, datasets: [{ data, backgroundColor: ['#4aaed9','#e05252','#f0a500','#6b3fa0','#2e8ab8','#27ae60','#e67e22'] }] },
        options: { plugins: { legend: { position: 'top', labels: { font: { family: 'Nunito', size: 11 } } } } }
    });

    const langRaw = <?= json_encode($language_data) ?>;
    const langColors = {
        'Java':'#f89820','C':'#555599','C++':'#004482','C#':'#9b4f96',
        'Python':'#3776ab','JavaScript':'#f7df1e','HTML/CSS':'#e34c26',
        'SQL':'#336791','PHP':'#8892bf','Others':'#95a5a6'
    };
    const langLabels = langRaw.length ? langRaw.map(d => d.purpose) : ['No Data'];
    const langData   = langRaw.length ? langRaw.map(d => parseInt(d.cnt)) : [1];
    const langBg     = langLabels.map(l => langColors[l] || '#95a5a6');
    new Chart(document.getElementById('langChart'), {
        type: 'pie',
        data: { labels: langLabels, datasets: [{ data: langData, backgroundColor: langBg, borderWidth: 2, borderColor: '#fff' }] },
        options: {
            plugins: {
                legend: { position: 'top', labels: { font: { family: 'Nunito', size: 11 }, padding: 10 } },
                tooltip: {
                    callbacks: {
                        label: ctx => {
                            const total = ctx.dataset.data.reduce((a,b) => a+b, 0);
                            const pct = total ? Math.round(ctx.parsed / total * 100) : 0;
                            return ` ${ctx.label}: ${ctx.parsed} (${pct}%)`;
                        }
                    }
                }
            }
        }
    });

    function openModal(id)  { document.getElementById(id).style.display = 'flex'; }
    function closeModal(id) { document.getElementById(id).style.display = 'none'; }

<script>

function searchStudent() {
    const searchInput = document.getElementById('searchInput');
    const box = document.getElementById('searchResults');
    
    const q = searchInput.value.trim();
    if (!q) return;

    box.innerHTML = `<div class="search-loading">Searching database...</div>`;

    fetch('admin_search.php?q=' + encodeURIComponent(q))
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(s => {
            box.innerHTML = "";

            if (!s) { 
                box.innerHTML = `<div class="search-error">❌ No student found with ID: ${q}</div>`; 
                return; 
            }
            
            const cardHTML = `
                <div class="student-result-card">
                    <div class="result-header">
                        <div class="result-avatar">${s.first_name[0]}${s.last_name[0]}</div>
                        <div class="result-title">
                            <h3>${s.first_name} ${s.last_name}</h3>
                            <span>ID: ${s.id_number}</span>
                        </div>
                    </div>
                    
                    <div class="result-grid">
                        <div class="grid-item"><strong>Course:</strong> ${s.course}</div>
                        <div class="grid-item"><strong>Year Level:</strong> ${s.course_level}</div>
                        <div class="grid-item"><strong>Sessions:</strong> <span class="session-badge">${s.sessions} left</span></div>
                        <div class="grid-item"><strong>Email:</strong> ${s.email || 'N/A'}</div>
                    </div>

                    <div class="result-footer">
                        <strong>Address:</strong> ${s.address || 'No address provided'}
                    </div>
                </div>`;
            
            box.innerHTML = cardHTML;
        })
        .catch(err => { 
            console.error('Search error:', err);
            box.innerHTML = `<div class="search-error">⚠️ Connection error. Please try again.</div>`; 
        });
}

// Ensure the Enter key trigger is correctly bound
document.getElementById('searchInput')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
        e.preventDefault(); 
        searchStudent();
    }
});

// Helper functions for the modals
function openModal(id) { document.getElementById(id).style.display = 'flex'; }
function closeModal(id) { 
    document.getElementById(id).style.display = 'none'; 
    if(id === 'searchModal') document.getElementById('searchResults').innerHTML = '';
}
</script>