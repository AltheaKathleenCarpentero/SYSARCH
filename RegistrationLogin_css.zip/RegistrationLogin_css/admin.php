<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php"); exit();
}
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php"); exit();
}

require_once 'config.php';

// Post announcement
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['announcement'])) {
    $msg = trim($_POST['announcement']);
    if (!empty($msg)) {
        $stmt = $conn->prepare("INSERT INTO announcements (message) VALUES (?)");
        $stmt->bind_param("s", $msg);
        $stmt->execute();
        $stmt->close();
    }
}

// Stats
$total_students  = $conn->query("SELECT COUNT(*) FROM students")->fetch_row()[0];
$currently_sitin = $conn->query("SELECT COUNT(*) FROM sit_in_sessions WHERE logout_time IS NULL")->fetch_row()[0];
$total_sitin     = $conn->query("SELECT COUNT(*) FROM sit_in_sessions")->fetch_row()[0];

// Course distribution
$course_data = [];
$res = $conn->query("SELECT st.course, COUNT(*) as cnt FROM sit_in_sessions s JOIN students st ON s.student_id = st.id GROUP BY st.course");
while ($row = $res->fetch_assoc()) $course_data[] = $row;

// Announcements
$announcements = [];
$res = $conn->query("SELECT * FROM announcements ORDER BY created_at DESC");
while ($row = $res->fetch_assoc()) $announcements[] = $row;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin – CCS Sit-in Monitoring</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/admin.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
</head>
<body>

    <!-- NAV -->
    <nav>
        <span class="nav-brand">College of Computer Studies Admin</span>
        <div class="nav-links">
            <a href="admin.php" class="active">Home</a>
            <a href="#" onclick="openModal('searchModal')">Search</a>
            <a href="admin_students.php">Students</a>
            <a href="admin_sitin.php">Sit-in</a>
            <a href="admin_sitin_records.php">View Sit-in Records</a>
        </div>
        <a href="?logout=1" class="logout-btn">Log out</a>
    </nav>

    <!-- SEARCH MODAL -->
    <div class="modal-overlay" id="searchModal" style="display:none">
        <div class="modal-box">
            <div class="modal-header">
                <span>Search Student</span>
                <button class="modal-close" onclick="closeModal('searchModal')">✕</button>
            </div>
            <div class="modal-body">
                <input type="text" id="searchInput" class="modal-input" placeholder="Search...">
                <div id="searchResults" class="search-results"></div>
            </div>
            <div class="modal-footer">
                <button class="btn-primary" onclick="searchStudent()">Search</button>
            </div>
        </div>
    </div>

    <!-- MAIN -->
    <main>
        <div class="dashboard-grid">

    </main>

    <footer>&copy; 2026 College of Computer Studies</footer>

    <script>
        const courseData = <?= json_encode($course_data) ?>;
        const labels = courseData.length ? courseData.map(d => d.course) : ['C#', 'C', 'Java', 'ASP.Net', 'PHP'];
        const data   = courseData.length ? courseData.map(d => parseInt(d.cnt)) : [20, 15, 25, 10, 30];
        new Chart(document.getElementById('courseChart'), {
            type: 'pie',
            data: {
                labels,
                datasets: [{ data, backgroundColor: ['#4aaed9','#e05252','#f0a500','#6b3fa0','#2e8ab8'] }]
            },
            options: { plugins: { legend: { position: 'top', labels: { font: { family: 'Nunito', size: 11 } } } } }
        });

        function openModal(id)  { document.getElementById(id).style.display = 'flex'; }
        function closeModal(id) { document.getElementById(id).style.display = 'none'; }

        function searchStudent() {
            const q = document.getElementById('searchInput').value.trim();
            if (!q) return;
            fetch('admin_search.php?q=' + encodeURIComponent(q))
                .then(r => r.text())
                .then(html => { document.getElementById('searchResults').innerHTML = html; });
        }
        document.getElementById('searchInput').addEventListener('keydown', e => {
            if (e.key === 'Enter') searchStudent();
        });
    </script>

</body>
</html>