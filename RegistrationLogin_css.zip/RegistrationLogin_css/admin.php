<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php"); exit();
}
if (isset($_GET['logout'])) { session_destroy(); header("Location: index.php"); exit(); }

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['announcement'])) {
    $msg = trim($_POST['announcement']);
    if (!empty($msg)) {
        $stmt = $conn->prepare("INSERT INTO announcements (message) VALUES (?)");
        $stmt->bind_param("s", $msg); $stmt->execute(); $stmt->close();
    }
    header("Location: admin.php"); exit();
}

if (isset($_GET['del_ann'])) {
    $aid = intval($_GET['del_ann']);
    $conn->query("DELETE FROM announcements WHERE id = $aid");
    header("Location: admin.php"); exit();
}

$total_students  = $conn->query("SELECT COUNT(*) FROM students")->fetch_row()[0];
$currently_sitin = $conn->query("SELECT COUNT(*) FROM sit_in_sessions WHERE status = 'Active'")->fetch_row()[0];
$total_sitin     = $conn->query("SELECT COUNT(*) FROM sit_in_sessions")->fetch_row()[0];
$course_data     = $conn->query("SELECT st.course, COUNT(*) as cnt FROM sit_in_sessions s JOIN students st ON s.student_id = st.id GROUP BY st.course")->fetch_all(MYSQLI_ASSOC);
$announcements   = $conn->query("SELECT * FROM announcements ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
$recent_sitin    = $conn->query("SELECT s.*, CONCAT(st.first_name,' ',st.last_name) as name, st.id_number FROM sit_in_sessions s JOIN students st ON s.student_id = st.id WHERE s.status = 'Active' ORDER BY s.login_time DESC LIMIT 10")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin – CCS Sit-in Monitoring</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/admin.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
</head>
<body>
<nav>
    <span class="nav-brand">🖥️ CCS Admin Panel</span>
    <div class="nav-links">
        <a href="admin.php" class="active">Dashboard</a>
        <a href="#" onclick="openModal('searchModal')">Search</a>
        <a href="admin_students.php">Students</a>
        
        <!-- Sit-in Dropdown -->
        <div class="nav-dropdown">
            <div class="nav-drop-toggle">Sit-in</div>
            <div class="nav-drop-menu">
                <a href="admin_sitin.php">📋 Sit-in</a>
                <a href="admin_sitin_records.php">📊 View Sit-in Records</a>
                <a href="admin_generate_reports.php">📥 Generate Reports</a>
            </div>
        </div>
        
        <a href="admin_leaderboard.php">🏆 Leaderboard</a>
        <a href="admin_feedback.php">Feedback</a>
        <a href="admin_reservation.php">Reservation</a>
        <a href="?logout=1" class="logout-btn">Log out</a>
    </div>
</nav>

<div class="modal-overlay" id="searchModal" style="display:none">
    <div class="modal-box">
        <div class="modal-header"><span>🔍 Search Student</span><button class="modal-close" onclick="closeModal('searchModal')">✕</button></div>
        <div class="modal-body">
            <input type="text" id="searchInput" class="modal-input" placeholder="Name or ID number...">
            <div id="searchResults" class="search-results"></div>
        </div>
        <div class="modal-footer"><button class="btn-primary" onclick="searchStudent()">Search</button></div>
    </div>
</div>

<div class="modal-overlay" id="annModal" style="display:none">
    <div class="modal-box">
        <div class="modal-header"><span>📢 Post Announcement</span><button class="modal-close" onclick="closeModal('annModal')">✕</button></div>
        <form method="POST">
            <div class="modal-body">
                <textarea name="announcement" class="modal-input" rows="4" placeholder="Type your announcement..." required style="resize:vertical"></textarea>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeModal('annModal')">Cancel</button>
                <button type="submit" class="btn-primary">Post</button>
            </div>
        </form>
    </div>
</div>

<main>
    <div class="page-title">Admin Dashboard</div>

    <div class="stats-row">
        <div class="stat-card">
            <div class="stat-icon">👥</div>
            <div class="stat-num"><?= $total_students ?></div>
            <div class="stat-label">Total Students</div>
        </div>
        <div class="stat-card stat-active">
            <div class="stat-icon">🟢</div>
            <div class="stat-num"><?= $currently_sitin ?></div>
            <div class="stat-label">Currently Sitting-in</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">📊</div>
            <div class="stat-num"><?= $total_sitin ?></div>
            <div class="stat-label">Total Sit-in Sessions</div>
        </div>
    </div>

<div class="dashboard-grid">

        <!-- Statistics Card with Active Sit-ins + Pie Chart merged in -->
        <div class="card" style="grid-column: 1 / -1">
            <div class="card-header">📊 Statistics</div>
            <div class="card-body">
                <div style="display: flex; gap: 2rem; flex-wrap: wrap;">

                    <!-- Left: Stats + Active Sit-ins Table -->
                    <div style="flex: 1; min-width: 300px;">
                        <!-- Statistics Numbers -->
                        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; text-align: center; margin-bottom: 1.5rem; padding-bottom: 1.5rem; border-bottom: 1px solid rgba(212,160,23,0.1);">
                            <div>
                                <div style="font-size: 2rem; font-weight: 900; color: var(--gold-light);"><?= $total_students ?></div>
                                <div style="color: var(--text-muted); font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.05em;">Students Registered</div>
                            </div>
                            <div>
                                <div style="font-size: 2rem; font-weight: 900; color: var(--gold-light);"><?= $currently_sitin ?></div>
                                <div style="color: var(--text-muted); font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.05em;">Currently Sit-in</div>
                            </div>
                            <div>
                                <div style="font-size: 2rem; font-weight: 900; color: var(--gold-light);"><?= $total_sitin ?></div>
                                <div style="color: var(--text-muted); font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.05em;">Total Sit-in</div>
                            </div>
                        </div>

                        <!-- Currently Active Sit-ins Table -->
                        <div style="font-weight: 800; color: var(--gold); margin-bottom: 0.75rem; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 0.08em;">🟢 Currently Active Sit-ins</div>
                        <?php if (empty($recent_sitin)): ?>
                            <div style="text-align:center; color:var(--text-muted); font-size:0.88rem; font-weight:600; padding: 1rem 0;">No active sit-in sessions.</div>
                        <?php else: ?>
                        <div class="table-wrap">
                            <table>
                                <thead>
                                    <tr><th>ID</th><th>Name</th><th>Lab</th><th>Purpose</th><th>Started</th><th>Action</th></tr>
                                </thead>
                                <tbody>
                                <?php foreach ($recent_sitin as $r): ?>
                                <tr>
                                    <td><?= htmlspecialchars($r['id_number']) ?></td>
                                    <td><?= htmlspecialchars($r['name']) ?></td>
                                    <td><?= htmlspecialchars($r['lab']) ?></td>
                                    <td><?= htmlspecialchars($r['purpose']) ?></td>
                                    <td><?= date('h:i A', strtotime($r['login_time'])) ?></td>
                                    <td><a href="admin_sitin.php?timeout=<?= $r['id'] ?>" class="btn-del" onclick="return confirm('Force logout this student?')">Force Out</a></td>
                                </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Right: Pie Chart -->
                    <div style="flex: 0 0 320px; display: flex; flex-direction: column; align-items: center;">
                        <div style="font-weight: 800; color: var(--gold); margin-bottom: 0.75rem; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 0.08em; align-self: flex-start;">Popular Programming Languages</div>
                        <div style="position: relative; width: 100%; max-width: 300px;">
                            <canvas id="langPieChart" width="300" height="300"></canvas>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!-- Announcements Card (full width) -->
        <div class="card" style="grid-column: 1 / -1">
            <div class="card-header" style="display:flex; justify-content:space-between; align-items:center">
                <span>📢 Announcements</span>
                <button class="btn-sm" onclick="openModal('annModal')">+ Post New</button>
            </div>
            <div class="card-body">
                <?php if (empty($announcements)): ?>
                    <p style="color:var(--text-muted); font-size:0.88rem; font-weight:600">No announcements yet.</p>
                <?php else: foreach ($announcements as $a): ?>
                <div class="ann-item">
                    <div class="ann-meta"><?= date('M d, Y H:i', strtotime($a['created_at'])) ?></div>
                    <div class="ann-text"><?= nl2br(htmlspecialchars($a['message'])) ?></div>
                    <a href="?del_ann=<?= $a['id'] ?>" class="btn-del-sm" onclick="return confirm('Delete this announcement?')">✕ Delete</a>
                </div>
                <?php endforeach; endif; ?>
            </div>
        </div>

    </div>

</main>
<footer>&copy; 2026 College of Computer Studies</footer>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
<script>

<?php
$lang_data = $conn->query("
    SELECT purpose, COUNT(*) as count 
    FROM sit_in_sessions 
    WHERE purpose IS NOT NULL AND purpose != ''
    GROUP BY purpose 
    ORDER BY count DESC 
    LIMIT 10
")->fetch_all(MYSQLI_ASSOC);
?>
const langData = <?= json_encode($lang_data) ?>;
const langLabels = langData.length ? langData.map(d => d.purpose) : ['C#', 'C', 'Java', 'ASP.Net', 'PHP'];
const langCounts = langData.length ? langData.map(d => parseInt(d.count)) : [1, 1, 1, 1, 1];
const pieColors  = ['#4aaed9','#e05252','#f0a500','#f5c842','#27bfbf','#6b3fa0','#27ae60','#e67e22','#e91e8c','#8bc34a'];

new Chart(document.getElementById('langPieChart'), {
    type: 'pie',
    data: {
        labels: langLabels,
        datasets: [{
            data: langCounts,
            backgroundColor: pieColors.slice(0, langLabels.length),
            borderWidth: 2,
            borderColor: '#1a0a2e'
        }]
    },
    options: {
        responsive: false,
        plugins: {
            legend: {
                position: 'top',
                labels: {
                    font: { family: 'Nunito', size: 11 },
                    color: '#c9b96b',
                    boxWidth: 14,
                    padding: 10
                }
            }
        }
    }
});

function openModal(id)  { document.getElementById(id).style.display = 'flex'; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }
function searchStudent() {
    const q = document.getElementById('searchInput').value.trim(); if (!q) return;
    fetch('admin_search.php?q=' + encodeURIComponent(q)).then(r => r.text()).then(html => { document.getElementById('searchResults').innerHTML = html; });
}
document.getElementById('searchInput').addEventListener('keydown', e => { if (e.key === 'Enter') searchStudent(); });
</script>
</body>
</html>