<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard – CCS</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Nunito', sans-serif;
            min-height: 100vh;
            background: linear-gradient(135deg, #f3eeff 0%, #e8dcff 40%, #f0eaff 100%);
            color: #1a2a3a;
        }
        nav {
            background: linear-gradient(90deg, #4a2678 0%, #6b3fa0 100%);
            padding: 0 2.5rem;
            height: 56px;
            display: flex; align-items: center; justify-content: space-between;
            box-shadow: 0 2px 16px rgba(107,63,160,0.3);
        }
        .nav-brand { color: #fff; font-size: 0.95rem; font-weight: 700; }
        .nav-brand span {
            background: rgba(255,255,255,0.2);
            border-radius: 6px;
            padding: 0.2rem 0.6rem;
            font-size: 0.75rem;
            margin-left: 0.6rem;
            letter-spacing: 0.08em;
        }
        .logout-btn {
            background: rgba(255,255,255,0.15);
            color: #fff; border: 1px solid rgba(255,255,255,0.35);
            padding: 0.35rem 1.1rem; border-radius: 8px;
            font-size: 0.85rem; font-weight: 700;
            text-decoration: none; transition: background 0.2s;
        }
        .logout-btn:hover { background: rgba(255,255,255,0.25); }
        main { max-width: 800px; margin: 3rem auto; padding: 0 1.5rem; }
        .welcome-card {
            background: rgba(255,255,255,0.75);
            backdrop-filter: blur(16px);
            border: 1.5px solid rgba(255,255,255,0.7);
            border-radius: 24px;
            padding: 2.5rem;
            box-shadow: 0 8px 32px rgba(107,63,160,0.12);
            text-align: center;
        }
        .welcome-card h1 {
            font-family: 'Playfair Display', serif;
            font-size: 2rem; color: #6b3fa0; margin-bottom: 0.5rem;
        }
        .welcome-card p { color: #5a7a8a; font-size: 1rem; font-weight: 600; }
        .admin-badge {
            display: inline-block;
            background: linear-gradient(135deg, #6b3fa0, #4a2678);
            color: #fff; border-radius: 20px;
            padding: 0.4rem 1.4rem; font-size: 0.9rem; font-weight: 800;
            margin-top: 1rem; letter-spacing: 0.05em;
        }
        .info-note {
            margin-top: 2rem; padding: 1.2rem;
            background: #f3eeff; border-radius: 12px;
            font-size: 0.88rem; color: #5a7a8a; font-weight: 600;
        }
    </style>
</head>
<body>
    <nav>
        <span class="nav-brand">
            CCS Sit-in Monitoring System
            <span>ADMIN</span>
        </span>
        <a href="?logout=1" class="logout-btn">Logout</a>
    </nav>
    <main>
        <div class="welcome-card">
            <h1>Welcome, <?= htmlspecialchars($_SESSION['admin_name']) ?>!</h1>
            <p>You are logged in as an administrator.</p>
            <div class="admin-badge">🛡 Admin Panel</div>
            <div class="info-note">
                Admin features will be available here SOON.
            </div>
        </div>
    </main>
</body>
</html>