<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php");
    exit();
}
require_once 'config.php';

$student_id = $_SESSION['student_id'];

// Get student info
$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Get sit-in history
$history_stmt = $conn->prepare("
    SELECT * FROM sit_in_sessions 
    WHERE student_id = ? 
    ORDER BY login_time DESC
");
$history_stmt->bind_param("i", $student_id);
$history_stmt->execute();
$history = $history_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$history_stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>History - CCS Sit-in Monitoring</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/dashboard.css">
    <style>
        .history-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        .history-card {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1.5px solid var(--border);
            border-radius: 24px;
            padding: 2rem;
        }
        .page-title {
            font-family: 'Playfair Display', serif;
            font-size: 1.8rem;
            color: var(--gold-light);
            margin-bottom: 1.5rem;
            text-align: center;
        }
        .table-wrap {
            overflow-x: auto;
        }
        .history-table {
            width: 100%;
            border-collapse: collapse;
        }
        .history-table th {
            text-align: left;
            padding: 0.75rem;
            color: var(--gold);
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            border-bottom: 1px solid rgba(212,160,23,0.2);
        }
        .history-table td {
            padding: 0.75rem;
            border-bottom: 1px solid rgba(212,160,23,0.1);
            color: var(--text);
        }
        .history-table tr:hover td {
            background: rgba(212,160,23,0.05);
        }
        .badge-active {
            background: rgba(46,213,115,0.15);
            color: #5de898;
            padding: 0.25rem 0.5rem;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 800;
        }
        .badge-done {
            background: rgba(255,255,255,0.06);
            color: var(--text-muted);
            padding: 0.25rem 0.5rem;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 800;
        }
        .no-data {
            text-align: center;
            padding: 2rem;
            color: var(--text-muted);
        }
        .entry-info {
            text-align: right;
            margin-top: 1rem;
            font-size: 0.8rem;
            color: var(--text-muted);
        }
        .search-bar {
            margin-bottom: 1rem;
            display: flex;
            justify-content: flex-end;
        }
        .search-input {
            padding: 0.5rem 1rem;
            border: 1.5px solid rgba(212,160,23,0.2);
            border-radius: 10px;
            background: rgba(255,255,255,0.05);
            color: var(--text);
            font-family: 'Nunito', sans-serif;
            width: 250px;
        }
        .search-input:focus {
            border-color: var(--gold);
            outline: none;
        }
        @media (max-width: 768px) {
            .history-container { padding: 1rem; }
            .history-table th, .history-table td { font-size: 0.7rem; padding: 0.5rem; }
        }
    </style>
</head>
<body>
    <nav>
        <span class="nav-brand">🎓 CCS Sit-in Monitoring System</span>
        <div class="nav-links">
            <div class="nav-dropdown">
                <div class="nav-drop-toggle">Notifications</div>
                <div class="nav-drop-menu">
                    <a href="student_notifications.php">Announcements</a>
                    <a href="student_alerts.php">Alerts</a>
                    <a href="student_messages.php">Messages</a>
                </div>
            </div>
            <a href="dashboard.php" class="active">Home</a>
            <a href="student_edit_profile.php">Edit Profile</a>
            <a href="student_history.php">History</a>
            <a href="student_leaderboard.php">🏆 Leaderboard</a>
            <a href="student_reservation.php">Reservation</a>
            <a href="?logout=1" class="logout-btn">Logout</a>
        </div>
    </nav>

    <main>
        <div class="history-container">
            <div class="history-card">
                <div class="page-title">History Information</div>
                
                <div class="search-bar">
                    <input type="text" id="searchInput" class="search-input" placeholder="Search history..." onkeyup="filterTable()">
                </div>
                
                <div class="table-wrap">
                    <table class="history-table" id="historyTable">
                        <thead>
                            <tr>
                                <th>ID Number</th>
                                <th>Name</th>
                                <th>Sit Purpose</th>
                                <th>Laboratory</th>
                                <th>Login</th>
                                <th>Logout</th>
                                <th>Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($history)): ?>
                                <tr>
                                    <td colspan="8" class="no-data">No data available</td>
                                </tr>
                            <?php else: 
                                foreach ($history as $row):
                            ?>
                                <tr>
                                    <td><?= htmlspecialchars($student['id_number']) ?></td>
                                    <td><?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?></td>
                                    <td><?= htmlspecialchars($row['purpose']) ?></td>
                                    <td><?= htmlspecialchars($row['lab']) ?></td>
                                    <td><?= date('h:i A', strtotime($row['login_time'])) ?></td>
                                    <td><?= $row['logout_time'] ? date('h:i A', strtotime($row['logout_time'])) : '—' ?></td>
                                    <td><?= date('Y-m-d', strtotime($row['login_time'])) ?></td>
                                    <td>
                                        <span class="badge-<?= $row['status'] === 'Active' ? 'active' : 'done' ?>">
                                            <?= $row['status'] ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="entry-info">
                    Showing <?= count($history) ?> of <?= count($history) ?> entries
                </div>
            </div>
        </div>
    </main>

    <footer>&copy; 2026 College of Computer Studies</footer>

    <script>
        function filterTable() {
            const input = document.getElementById('searchInput');
            const filter = input.value.toLowerCase();
            const table = document.getElementById('historyTable');
            const rows = table.getElementsByTagName('tr');
            
            for (let i = 1; i < rows.length; i++) {
                const cells = rows[i].getElementsByTagName('td');
                let found = false;
                for (let j = 0; j < cells.length; j++) {
                    if (cells[j]) {
                        const text = cells[j].textContent || cells[j].innerText;
                        if (text.toLowerCase().indexOf(filter) > -1) {
                            found = true;
                            break;
                        }
                    }
                }
                rows[i].style.display = found ? '' : 'none';
            }
        }
    </script>
</body>
</html>