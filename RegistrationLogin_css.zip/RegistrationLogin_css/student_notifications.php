<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php"); exit();
}
require_once 'config.php';
$sid = $_SESSION['student_id'];

$stmt = $conn->prepare("SELECT first_name, last_name FROM students WHERE id = ?");
$stmt->bind_param("i", $sid);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();

$ann_rows = $conn->query("SELECT * FROM announcements ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);

$unread_count = $conn->query("SELECT COUNT(*) as c FROM messages WHERE student_id=$sid AND is_read=0 AND sender='admin'")->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcements – CCS Sit-in Monitoring</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/dashboard.css">
    <style>
        .notif-badge {
            background: #e74c3c; color: #fff; border-radius: 50%;
            font-size: 0.65rem; padding: 2px 6px; margin-left: 4px;
            font-weight: 800; vertical-align: top;
        }
        .ann-list { display: flex; flex-direction: column; gap: 1rem; }
        .ann-card {
            background: rgba(255,255,255,0.04);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 12px;
            padding: 1.1rem 1.3rem;
            transition: border-color 0.2s;
        }
        .ann-card:hover { border-color: rgba(212,160,23,0.35); }
        .ann-meta {
            font-size: 0.72rem;
            color: var(--text-muted);
            margin-bottom: 0.5rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.4px;
        }
        .ann-body {
            font-size: 0.88rem;
            color: #ddd;
            line-height: 1.7;
        }
        .ann-empty {
            text-align: center;
            color: var(--text-muted);
            padding: 3rem 1rem;
            font-size: 0.9rem;
        }
        .page-header {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 1.5rem;
        }
        .page-header a {
            color: var(--gold);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 700;
        }
        .page-header a:hover { text-decoration: underline; }
    </style>
</head>
<body>

<nav>
    <span class="nav-brand">🎓 CCS Sit-in Monitoring System</span>
    <div class="nav-links">
        <div class="nav-dropdown">
            <div class="nav-drop-toggle active">Notifications</div>
            <div class="nav-drop-menu">
                <a href="student_notifications.php" class="active">Announcements</a>
                <a href="student_alerts.php">Alerts</a>
                <a href="dashboard.php#" onclick="history.back(); return false;">
                    Messages<?php if ($unread_count > 0): ?><span class="notif-badge"><?= $unread_count ?></span><?php endif; ?>
                </a>
            </div>
        </div>
        <a href="dashboard.php">Home</a>
        <a href="student_edit_profile.php">Edit Profile</a>
        <a href="student_history.php">History</a>
        <a href="student_leaderboard.php">🏆 Leaderboard</a>
        <a href="student_reservation.php">Reservation</a>
        <a href="?logout=1" class="logout-btn">Logout</a>
    </div>
</nav>

<main class="dashboard-main">
    <div style="max-width:780px; margin:0 auto;">
        <div class="page-header">
            <a href="dashboard.php">← Back to Dashboard</a>
        </div>

        <div class="card">
            <div class="card-header">📢 All Announcements</div>
            <div class="card-body">
                <?php if (empty($ann_rows)): ?>
                    <div class="ann-empty">
                        <div style="font-size:2.5rem; margin-bottom:0.75rem;">📭</div>
                        No announcements at this time.
                    </div>
                <?php else: ?>
                    <div class="ann-list">
                        <?php foreach ($ann_rows as $a): ?>
                        <div class="ann-card">
                            <div class="ann-meta">📅 CCS Admin · <?= date('F d, Y · g:i A', strtotime($a['created_at'])) ?></div>
                            <div class="ann-body"><?= nl2br(htmlspecialchars($a['message'])) ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>

<footer>&copy; 2026 College of Computer Studies</footer>

</body>
</html>