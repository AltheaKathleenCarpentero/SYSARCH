<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php");
    exit();
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard – CCS Sit-in Monitoring</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root {
            --accent: #4aaed9;
            --accent-dark: #2e8ab8;
            --purple: #6b3fa0;
            --text: #1a2a3a;
            --text-muted: #5a7a8a;
            --card-bg: rgba(255,255,255,0.75);
        }
        body {
            font-family: 'Nunito', sans-serif;
            min-height: 100vh;
            background: linear-gradient(135deg, #e8f7ff 0%, #d0effc 40%, #daf0ff 100%);
            color: var(--text);
        }
        nav {
            background: linear-gradient(90deg, var(--purple) 0%, #4a2678 100%);
            padding: 0 2.5rem;
            height: 56px;
            display: flex; align-items: center; justify-content: space-between;
            box-shadow: 0 2px 16px rgba(107,63,160,0.25);
        }
        .nav-brand { color: #fff; font-size: 0.95rem; font-weight: 700; }
        .logout-btn {
            background: rgba(255,255,255,0.18);
            color: #fff; border: 1px solid rgba(255,255,255,0.4);
            padding: 0.35rem 1.1rem; border-radius: 8px;
            font-size: 0.85rem; font-weight: 700; cursor: pointer;
            text-decoration: none; transition: background 0.2s;
        }
        .logout-btn:hover { background: rgba(255,255,255,0.28); }
        main {
            max-width: 800px; margin: 3rem auto; padding: 0 1.5rem;
        }
        .welcome-card {
            background: var(--card-bg);
            backdrop-filter: blur(16px);
            border: 1.5px solid rgba(255,255,255,0.7);
            border-radius: 24px;
            padding: 2.5rem;
            box-shadow: 0 8px 32px rgba(74,174,217,0.15);
            text-align: center;
        }
        .welcome-card h1 {
            font-family: 'Playfair Display', serif;
            font-size: 2rem; color: var(--purple); margin-bottom: 0.5rem;
        }
        .welcome-card p { color: var(--text-muted); font-size: 1rem; font-weight: 600; }
        .id-badge {
            display: inline-block;
            background: linear-gradient(135deg, var(--accent), var(--accent-dark));
            color: #fff; border-radius: 20px;
            padding: 0.4rem 1.4rem; font-size: 0.9rem; font-weight: 800;
            margin-top: 1rem; letter-spacing: 0.05em;
        }
        .info-note {
            margin-top: 2rem; padding: 1.2rem;
            background: #e8f7ff; border-radius: 12px;
            font-size: 0.88rem; color: var(--text-muted); font-weight: 600;
        }
    </style>
</head>
<body>
    <nav>
        <span class="nav-brand">CCS Sit-in Monitoring System</span>
        <a href="?logout=1" class="logout-btn">Logout</a>
    </nav>
    <main>
        <div class="welcome-card">
            <h1>Welcome, <?= htmlspecialchars($_SESSION['student_name']) ?>!</h1>
            <p>You are now logged in to the CCS Sit-in Monitoring System.</p>
            <div class="id-badge"><?= htmlspecialchars($_SESSION['id_number']) ?></div>
            <div class="info-note">
                🎓 This is your student dashboard. Sit-in session features will be available here.
            </div>
        </div>
    </main>
</body>
</html>
