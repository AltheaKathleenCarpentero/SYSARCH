<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php"); exit();
}
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php"); exit();
}

$show_welcome = false;
if (!isset($_SESSION['welcome_shown'])) {
    $_SESSION['welcome_shown'] = true;
    $show_welcome = true;
}

require_once 'config.php';
$sid = $_SESSION['student_id'];

// Fetch student
$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->bind_param("i", $sid);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Handle profile photo upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_photo'])) {
    $allowed = ['image/jpeg','image/png','image/gif','image/webp'];
    $file = $_FILES['profile_photo'];
    if (in_array($file['type'], $allowed) && $file['error'] === 0) {
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'student_' . $sid . '.' . $ext;
        $upload_path = 'assets/uploads/' . $filename;
        if (!is_dir('assets/uploads')) mkdir('assets/uploads', 0755, true);
        if (move_uploaded_file($file['tmp_name'], $upload_path)) {
            $stmt = $conn->prepare("UPDATE students SET photo = ? WHERE id = ?");
            $stmt->bind_param("si", $filename, $sid);
            $stmt->execute(); $stmt->close();
            $student['photo'] = $filename;
        }
    }
    header("Location: dashboard.php"); exit();
}

// Check if student has an ACTIVE sit-in session
$res = $conn->prepare("SELECT * FROM sit_in_sessions WHERE student_id = ? AND status = 'Active' LIMIT 1");
$res->bind_param("i", $sid);
$res->execute();
$active_session = $res->get_result()->fetch_assoc();
$res->close();

// Handle SIT-IN REQUEST (start session)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['start_sitin'])) {
    if ($active_session) {
        $sitin_error = "You already have an active sit-in session. Please log out first.";
    } elseif (($student['sessions'] ?? 30) <= 0) {
        $sitin_error = "You have no remaining sessions.";
    } else {
        $purpose = trim($_POST['purpose']);
        $lab     = trim($_POST['lab']);
        if (!empty($purpose) && !empty($lab)) {
            $ins = $conn->prepare("INSERT INTO sit_in_sessions (student_id, purpose, lab) VALUES (?,?,?)");
            $ins->bind_param("iss", $sid, $purpose, $lab);
            $ins->execute(); $ins->close();
            $res = $conn->prepare("SELECT * FROM sit_in_sessions WHERE student_id = ? AND status = 'Active' LIMIT 1");
            $res->bind_param("i", $sid);
            $res->execute();
            $active_session = $res->get_result()->fetch_assoc();
            $res->close();
            $sitin_success = "Sit-in session started! Lab: $lab";
        } else {
            $sitin_error = "Please fill in purpose and lab.";
        }
    }
}

// Handle SIT-OUT (end session)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['end_sitin'])) {
    if ($active_session) {
        $upd = $conn->prepare("UPDATE sit_in_sessions SET logout_time = NOW(), status = 'Done' WHERE id = ? AND student_id = ?");
        $upd->bind_param("ii", $active_session['id'], $sid);
        $upd->execute(); $upd->close();
        $conn->query("UPDATE students SET sessions = GREATEST(0, sessions - 1) WHERE id = $sid");
        $stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
        $stmt->bind_param("i", $sid);
        $stmt->execute();
        $student = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $active_session = null;
        $sitin_success = "Sit-in session ended. Sessions remaining: " . $student['sessions'];
    }
}

// Handle feedback submission from history (with duplicate check)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_feedback'])) {
    $fsid   = (int)$_POST['feedback_session_id'];
    $rating = max(1, min(5, (int)$_POST['rating']));
    $ftext  = trim($_POST['feedback_text']);
    $chk = $conn->prepare("SELECT id FROM session_feedback WHERE student_id=? AND session_id=?");
    $chk->bind_param("ii", $sid, $fsid);
    $chk->execute();
    if ($chk->get_result()->num_rows === 0) {
        $ins = $conn->prepare("INSERT INTO session_feedback (student_id, session_id, rating, feedback) VALUES (?,?,?,?)");
        $ins->bind_param("iiis", $sid, $fsid, $rating, $ftext);
        $ins->execute(); $ins->close();
    }
    $chk->close();
    header("Location: dashboard.php"); exit();
}

// Fetch sit-in history (latest 3 only)
$history = $conn->prepare("SELECT * FROM sit_in_sessions WHERE student_id = ? ORDER BY login_time DESC LIMIT 3");
$history->bind_param("i", $sid);
$history->execute();
$history_rows = $history->get_result()->fetch_all(MYSQLI_ASSOC);
$history->close();

// Get session IDs that already have feedback
$fb_res = $conn->query("SELECT session_id FROM session_feedback WHERE student_id = $sid");
$already_rated = [];
while ($row = $fb_res->fetch_assoc()) $already_rated[] = $row['session_id'];

// Fetch announcements
$ann_rows = $conn->query("SELECT * FROM announcements ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);

// Fetch messages
$msgs = $conn->prepare("SELECT * FROM messages WHERE student_id=? ORDER BY created_at DESC");
$msgs->bind_param("i", $sid);
$msgs->execute();
$msg_rows = $msgs->get_result()->fetch_all(MYSQLI_ASSOC);
$msgs->close();

// Unread message count
$unread_count = $conn->query("SELECT COUNT(*) as c FROM messages WHERE student_id=$sid AND is_read=0 AND sender='admin'")->fetch_assoc()['c'];

$photo = (!empty($student['photo']) && file_exists('assets/uploads/' . $student['photo']))
    ? 'assets/uploads/' . $student['photo'] : null;
$sessions_left = $student['sessions'] ?? 30;

// --- 30-MIN SESSION BONUS ---
$session_bonus_earned = false;
if ($active_session) {
    $elapsed = (time() - strtotime($active_session['login_time'])) / 60;
    if ($elapsed >= 30 && !$active_session['bonus_awarded']) {
        $conn->query("UPDATE sit_in_sessions SET bonus_awarded=1 WHERE id=" . $active_session['id']);
        $conn->query("UPDATE students SET points = points + 0.15, total_points = total_points + 0.15 WHERE id = $sid");
        $session_bonus_earned = true;
        $res2 = $conn->prepare("SELECT * FROM sit_in_sessions WHERE id=?");
        $res2->bind_param("i", $active_session['id']);
        $res2->execute();
        $active_session = $res2->get_result()->fetch_assoc();
        $res2->close();
    }
}

// Refresh student points + total_points
$stmt2 = $conn->prepare("SELECT points, total_points FROM students WHERE id=?");
$stmt2->bind_param("i", $sid);
$stmt2->execute();
$pts_row = $stmt2->get_result()->fetch_assoc();
$student['points'] = $pts_row['points'];
$student['total_points'] = $pts_row['total_points'] ?? 0;
$stmt2->close();

// Count distinct sit-in days (for 5-day reward)
$days_res = $conn->prepare("SELECT COUNT(DISTINCT DATE(login_time)) as day_count FROM sit_in_sessions WHERE student_id = ? AND status = 'Done'");
$days_res->bind_param("i", $sid);
$days_res->execute();
$sit_in_days = (int)$days_res->get_result()->fetch_assoc()['day_count'];
$days_res->close();

// Award 3 points every 5 distinct sit-in days
$milestone = floor($sit_in_days / 5);
$awarded_res = $conn->prepare("SELECT sitin_milestone FROM students WHERE id=?");
$awarded_res->bind_param("i", $sid);
$awarded_res->execute();
$row_m = $awarded_res->get_result()->fetch_assoc();
$awarded_res->close();
$current_milestone = (int)($row_m['sitin_milestone'] ?? 0);
$sitin_reward_earned = false;
if ($milestone > $current_milestone) {
    $new_pts = ($milestone - $current_milestone) * 3;
    $conn->query("UPDATE students SET points = points + $new_pts, total_points = total_points + $new_pts, sitin_milestone = $milestone WHERE id = $sid");
    $student['points'] += $new_pts;
    $student['total_points'] += $new_pts;
    $sitin_reward_earned = $new_pts;
}
$days_to_next = (($current_milestone + 1) * 5) - $sit_in_days;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard – CCS Sit-in Monitoring</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/dashboard.css">
    <style>
        .notif-badge {
            background: #e74c3c;
            color: #fff;
            border-radius: 50%;
            font-size: 0.65rem;
            padding: 2px 6px;
            margin-left: 4px;
            font-weight: 800;
            vertical-align: top;
        }
    </style>
</head>
<body>

<nav>
    <span class="nav-brand">🎓 CCS Sit-in Monitoring System</span>
    <div class="nav-links">
        <div class="nav-dropdown">
            <div class="nav-drop-toggle">Notifications</div>
            <div class="nav-drop-menu">
                <a href="student_notifications.php">Announcements</a>
                <a href="student_alerts.php">Alerts</a>
                <a href="#" onclick="openMessagesPanel(); return false;">
                    Messages<?php if ($unread_count > 0): ?><span class="notif-badge"><?= $unread_count ?></span><?php endif; ?>
                </a>
            </div>
        </div>
        <a href="dashboard.php" class="active">Home</a>
        <a href="student_edit_profile.php">Edit Profile</a>
        <a href="student_history.php">History</a>
        <a href="student_leaderboard.php">🏆 Leaderboard</a>
        <a href="student_reservation.php">Reservation</a>
        <a href="?logout=1" class="logout-btn">Logout</a>
    </div>
</nav>

<!-- WELCOME POPUP -->
<?php if ($show_welcome): ?>
<div class="popup-overlay" id="welcomePopup">
    <div class="popup-box">
        <div class="popup-icon">🎉</div>
        <div class="popup-title">Welcome back!</div>
        <div class="popup-msg">
            Good to see you, <strong><?= htmlspecialchars($student['first_name']) ?>!</strong><br>
            You're logged in to the CCS Sit-in Monitoring System.
        </div>
        <button class="popup-btn" onclick="closeWelcome()">Got It!</button>
    </div>
</div>
<?php endif; ?>

<!-- ANNOUNCEMENTS POPUP -->
<div class="popup-overlay" id="announcementsPopup" style="display:none">
    <div class="popup-box popup-wide">
        <div class="popup-icon">📢</div>
        <div class="popup-title">Announcements</div>
        <div class="popup-scroll">
            <?php if (empty($ann_rows)): ?>
                <div class="announcement-item"><div class="announcement-text">No announcements at this time.</div></div>
            <?php else: foreach ($ann_rows as $a): ?>
                <div class="announcement-item">
                    <div class="announcement-meta">CCS Admin · <?= date('Y-M-d', strtotime($a['created_at'])) ?></div>
                    <div class="announcement-text"><?= nl2br(htmlspecialchars($a['message'])) ?></div>
                </div>
            <?php endforeach; endif; ?>
        </div>
        <button class="popup-btn" onclick="closePopup('announcementsPopup')">Close</button>
    </div>
</div>

<!-- RULES POPUP -->
<div class="popup-overlay" id="rulesPopup" style="display:none">
    <div class="popup-box popup-wide">
        <div class="popup-icon">📋</div>
        <div class="popup-title">Rules & Regulations</div>
        <div class="popup-scroll">
            <div class="rules-title">University of Cebu</div>
            <div class="rules-subtitle">College of Computer Studies<br>Laboratory Rules and Regulations</div>
            <p>1. Maintain silence, proper decorum, and discipline inside the laboratory.</p>
            <p>2. Games are not allowed inside the lab.</p>
            <p>3. Surfing the Internet is allowed only with the permission of the instructor.</p>
            <p>4. Getting access to other websites not related to the course is strictly prohibited.</p>
            <p>5. Deleting computer files and changing the set-up of the computer is a major offense.</p>
            <p>6. Observe computer time usage carefully. A fifteen-minute allowance is given for each use.</p>
            <p>7. Observe proper decorum while inside the laboratory.</p>
            <ul>
                <li>Do not get inside the lab unless the instructor is present.</li>
                <li>All bags and knapsacks must be deposited at the counter.</li>
                <li>Follow the seating arrangement of your instructor.</li>
                <li>At the end of class, all software programs must be closed.</li>
                <li>Return all chairs to their proper places after using.</li>
            </ul>
            <p>8. Chewing gum, eating, drinking, smoking, and vandalism are prohibited inside the lab.</p>
            <p>9. Anyone causing a continual disturbance will be asked to leave the lab.</p>
            <p>10. Persons exhibiting hostile or threatening behavior will be asked to leave the lab.</p>
            <div class="rules-section">Disciplinary Action</div>
            <ul>
                <li><strong>First Offense</strong> — Suspension from classes.</li>
                <li><strong>Second and Subsequent Offenses</strong> — Heavier sanction.</li>
            </ul>
        </div>
        <button class="popup-btn" onclick="closePopup('rulesPopup')">Close</button>
    </div>
</div>

<!-- SIT-IN MODAL -->
<div class="popup-overlay" id="sitinModal" style="display:none">
    <div class="popup-box" style="max-width:450px">
        <div class="popup-icon">💻</div>
        <div class="popup-title">Request Sit-in</div>
        <?php if (!empty($sitin_error)): ?>
            <div class="alert-error" style="margin-bottom:1rem;">⚠ <?= htmlspecialchars($sitin_error) ?></div>
        <?php endif; ?>
        <form method="POST" style="text-align:left; margin-top:1rem">
            <div class="form-group" style="margin-bottom:1rem">
                <label class="field-label">PURPOSE / PROGRAMMING LANGUAGE</label>
                <select name="purpose" class="field-input" required>
                    <option value="">Select Programming Language</option>
                    <option value="PHP">PHP</option>
                    <option value="ASP.NET">ASP.NET</option>
                    <option value="C">C</option>
                    <option value="C++">C++</option>
                    <option value="C#">C#</option>
                    <option value="Java">Java</option>
                    <option value="Python">Python</option>
                    <option value="JavaScript">JavaScript</option>
                    <option value="SQL">SQL</option>
                    <option value="HTML/CSS">HTML/CSS</option>
                    <option value="Others">Others</option>
                </select>
            </div>
            <div class="form-group" style="margin-bottom:1.5rem">
                <label class="field-label">LABORATORY</label>
                <select name="lab" class="field-input" required>
                    <option value="">Select Lab</option>
                    <option value="Lab 524">Lab 524</option>
                    <option value="Lab 526">Lab 526</option>
                    <option value="Lab 528">Lab 528</option>
                    <option value="Lab 530">Lab 530</option>
                    <option value="Lab 542">Lab 542</option>
                    <option value="Lab 544">Lab 544</option>
                </select>
            </div>
            <div style="display:flex; gap:0.75rem; margin-top:1rem;">
                <button type="button" class="btn-secondary" onclick="closePopup('sitinModal')" style="flex:1;">Cancel</button>
                <button type="submit" name="start_sitin" class="popup-btn" style="flex:2;">Confirm Sit-in</button>
            </div>
        </form>
    </div>
</div>

<!-- MESSAGES MODAL -->
<div class="popup-overlay" id="messagesPopup" style="display:none">
    <div class="popup-box popup-wide">
        <div class="popup-icon">✉️</div>
        <div class="popup-title">Messages</div>
        <div class="popup-scroll">
            <?php if (empty($msg_rows)): ?>
                <div style="text-align:center; color:var(--text-muted); padding:1rem;">No messages yet.</div>
            <?php else: foreach ($msg_rows as $m): ?>
                <div style="padding:0.85rem; border-bottom:1px solid rgba(255,255,255,0.07); background:<?= $m['is_read'] ? 'transparent' : 'rgba(212,160,23,0.06)' ?>; border-radius:8px; margin-bottom:0.4rem;">
                    <div style="display:flex; justify-content:space-between; margin-bottom:0.3rem;">
                        <span style="font-weight:700; color:var(--gold); font-size:0.85rem;">📬 <?= htmlspecialchars($m['subject'] ?? 'Message') ?></span>
                        <span style="font-size:0.72rem; color:var(--text-muted);"><?= date('M d, h:i A', strtotime($m['created_at'])) ?></span>
                    </div>
                    <div style="font-size:0.85rem; color:#ddd; line-height:1.6;"><?= nl2br(htmlspecialchars($m['body'])) ?></div>
                </div>
            <?php endforeach; endif; ?>
        </div>
        <button class="popup-btn" onclick="closePopup('messagesPopup')">Close</button>
    </div>
</div>

<!-- SESSION FEEDBACK MODAL -->
<div class="popup-overlay" id="feedbackModal" style="display:none">
    <div class="popup-box" style="max-width:420px">
        <div class="popup-icon">⭐</div>
        <div class="popup-title">Rate Your Session</div>
        <div class="popup-msg" style="margin-bottom:1rem; font-size:0.88rem; color:var(--text-muted);">
            How was your sit-in experience? Your feedback helps improve the lab.
        </div>
        <form method="POST">
            <input type="hidden" name="feedback_session_id" id="fb_session_id" value="">
            <div style="text-align:center; margin-bottom:1rem;">
                <div style="font-size:0.78rem; color:var(--text-muted); font-weight:700; margin-bottom:0.6rem; text-transform:uppercase; letter-spacing:0.5px;">Your Rating</div>
                <div id="starContainer" style="display:flex; justify-content:center; gap:0.3rem;">
                    <?php for($i=1;$i<=5;$i++): ?>
                        <span class="fb-star" data-val="<?= $i ?>" onclick="setFbRating(<?= $i ?>)"
                            style="font-size:2.4rem; cursor:pointer; color:#444; transition:color 0.15s; user-select:none;">★</span>
                    <?php endfor; ?>
                </div>
                <input type="hidden" name="rating" id="fb_rating_input" value="0">
                <div id="ratingLabel" style="font-size:0.78rem; color:var(--gold); margin-top:0.4rem; font-weight:700; min-height:1.2em;"></div>
            </div>
            <textarea name="feedback_text" id="fb_text" placeholder="Share your experience or suggestions... (optional)"
                style="width:100%; background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.15); border-radius:8px; color:#fff; padding:0.75rem; font-size:0.85rem; resize:vertical; min-height:90px; font-family:inherit; box-sizing:border-box;"></textarea>
            <div style="display:flex; gap:0.75rem; margin-top:1rem;">
                <button type="button" class="btn-secondary" onclick="closePopup('feedbackModal')" style="flex:1;">Cancel</button>
                <button type="submit" name="submit_feedback" id="fb_submit_btn" class="popup-btn" style="flex:2;" disabled>Submit</button>
            </div>
        </form>
    </div>
</div>

<!-- POINTS DETAIL MODAL -->
<div class="popup-overlay" id="pointsModal" style="display:none">
    <div class="popup-box popup-wide">
        <div class="popup-icon">⭐</div>
        <div class="popup-title">My Points Breakdown</div>
        <div class="popup-scroll">
            <table style="width:100%; border-collapse:collapse; font-size:0.88rem;">
                <tr style="border-bottom:1px solid rgba(255,255,255,0.08);">
                    <td style="padding:0.6rem 0; color:var(--text-muted);">🏆 Total Points Earned</td>
                    <td style="text-align:right; font-weight:800; color:var(--gold);"><?= number_format($student['total_points'] ?? 0, 2) ?> pts</td>
                </tr>
                <tr style="border-bottom:1px solid rgba(255,255,255,0.08);">
                    <td style="padding:0.6rem 0; color:var(--text-muted);">📅 Total Sit-in Days</td>
                    <td style="text-align:right; font-weight:800; color:#4aaed9;"><?= $sit_in_days ?> days</td>
                </tr>
                <tr>
                    <td style="padding:0.6rem 0; color:var(--text-muted);">🎯 Days Until Next +3pts Reward</td>
                    <td style="text-align:right; font-weight:800; color:#27ae60;"><?= $days_to_next == 0 ? 'Claimed!' : $days_to_next . ' day' . ($days_to_next > 1 ? 's' : '') ?></td>
                </tr>
            </table>
            <div style="margin-top:1.2rem; padding:0.75rem; background:rgba(212,160,23,0.07); border-radius:8px; border:1px solid rgba(212,160,23,0.2);">
                <div style="font-size:0.78rem; color:var(--text-muted); font-weight:700; margin-bottom:0.5rem;">HOW TO EARN POINTS</div>
                <div style="font-size:0.8rem; color:#ccc; line-height:1.8;">
                    ⏱ Stay 30 minutes in a session: +0.15<br>
                    🪑 Clean desk on logout: +1.00<br>
                    📅 Every 5 sit-in days: +3.00<br>
                    <span style="color:var(--gold);">💡 Every 3 points = +1 session</span>
                </div>
            </div>
        </div>
        <button class="popup-btn" onclick="closePopup('pointsModal')">Close</button>
    </div>
</div>

<main class="dashboard-main">
    <?php if ($session_bonus_earned): ?>
    <div class="alert-success-banner">⏱ 30-Minute Bonus! +0.15 points awarded!</div>
    <?php endif; ?>
    <?php if ($sitin_reward_earned): ?>
    <div class="alert-success-banner">🎯 5-Day Sit-in Reward! +<?= $sitin_reward_earned ?> points awarded!</div>
    <?php endif; ?>
    <?php if (!empty($sitin_success)): ?>
    <div class="alert-success-banner"><?= htmlspecialchars($sitin_success) ?></div>
    <?php endif; ?>

    <div class="dashboard-grid">

        <!-- LEFT: Student Info -->
        <div class="card">
            <div class="card-header">👤 Student Information</div>
            <div class="card-body">
                <form method="POST" enctype="multipart/form-data">
                    <div class="profile-photo-wrap">
                        <?php if ($photo): ?>
                            <img src="<?= htmlspecialchars($photo) ?>?v=<?= time() ?>" class="profile-photo" id="preview" alt="Profile">
                        <?php else: ?>
                            <div class="photo-placeholder" id="preview-placeholder">🎓</div>
                            <img src="" class="profile-photo" id="preview" alt="Profile" style="display:none">
                        <?php endif; ?>
                        <label class="upload-label" for="photo-input">📷 Change Photo</label>
                        <input type="file" id="photo-input" name="profile_photo" accept="image/*" onchange="previewAndUpload(this)">
                    </div>
                </form>

                <div class="info-row"><span class="icon">👤</span>
                    <div><div class="label">Full Name</div>
                    <div class="value"><?= htmlspecialchars($student['first_name'].' '.($student['middle_name'] ?? '').' '.$student['last_name']) ?></div></div>
                </div>
                <div class="info-row"><span class="icon">🪪</span>
                    <div><div class="label">ID Number</div>
                    <div class="value"><?= htmlspecialchars($student['id_number']) ?></div></div>
                </div>
                <div class="info-row"><span class="icon">🎓</span>
                    <div><div class="label">Course</div>
                    <div class="value"><?= htmlspecialchars($student['course']) ?></div></div>
                </div>
                <div class="info-row"><span class="icon">📅</span>
                    <div><div class="label">Year Level</div>
                    <div class="value">Year <?= htmlspecialchars($student['course_level']) ?></div></div>
                </div>
                <div class="info-row"><span class="icon">✉️</span>
                    <div><div class="label">Email</div>
                    <div class="value"><?= htmlspecialchars($student['email'] ?? '—') ?></div></div>
                </div>
                <div class="info-row"><span class="icon">📍</span>
                    <div><div class="label">Address</div>
                    <div class="value"><?= htmlspecialchars($student['address'] ?? '—') ?></div></div>
                </div>

                <div class="session-badge <?= $sessions_left <= 5 ? 'session-low' : '' ?>">
                    <span>🕐</span>
                    Sessions Remaining: <strong><?= $sessions_left ?></strong>
                </div>

                <div class="points-badge" onclick="openPopup('pointsModal')" style="cursor:pointer; margin-top:0.6rem; background:rgba(212,160,23,0.12); border:1px solid rgba(212,160,23,0.35); border-radius:10px; padding:0.6rem 1rem; text-align:center; font-weight:700; color:var(--gold); font-size:0.9rem;">
                    ⭐ Total Points: <strong><?= number_format($student['total_points'] ?? 0, 2) ?></strong>
                    <span style="font-size:0.72rem; color:var(--text-muted); display:block; font-weight:400; margin-top:2px;">Click to view details</span>
                </div>

                <!-- 5-Day Sit-in Progress -->
                <div style="margin-top:0.75rem; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:10px; padding:0.75rem 1rem;">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.4rem;">
                        <span style="font-size:0.78rem; font-weight:700; color:var(--text-muted);">🎯 5-Day Sit-in Reward</span>
                        <span style="font-size:0.75rem; color:var(--gold); font-weight:800;"><?= $sit_in_days % 5 ?>/5 days</span>
                    </div>
                    <div style="background:rgba(255,255,255,0.08); border-radius:20px; height:8px; overflow:hidden;">
                        <div style="height:100%; width:<?= min(100, ($sit_in_days % 5) / 5 * 100) ?>%; background:linear-gradient(90deg, var(--gold), #f0c040); border-radius:20px; transition:width 0.5s ease;"></div>
                    </div>
                    <div style="font-size:0.72rem; color:var(--text-muted); margin-top:0.4rem; text-align:center;">
                        <?php if ($days_to_next == 0): ?>
                            🎉 Reward just claimed! Next in 5 days.
                        <?php else: ?>
                            <?= $days_to_next ?> more day<?= $days_to_next > 1 ? 's' : '' ?> → +3 points
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- RIGHT: Sit-in + Announcements + History -->
        <div style="display:flex; flex-direction:column; gap:1.2rem">

            <!-- Active Sit-in Card -->
            <div class="card">
                <div class="card-header">💻 Sit-in Session</div>
                <div class="card-body">
                    <?php if ($active_session): ?>
                        <div class="active-session-container">
                            <div class="session-status-badge">
                                <span class="pulse-dot"></span> ACTIVE SESSION
                            </div>
                            <div class="session-details">
                                <div class="detail-row">
                                    <span class="detail-label">Laboratory:</span>
                                    <span class="detail-value"><?= htmlspecialchars($active_session['lab']) ?></span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">Purpose:</span>
                                    <span class="detail-value"><?= htmlspecialchars($active_session['purpose']) ?></span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">Started:</span>
                                    <span class="detail-value"><?= date('M d, Y h:i A', strtotime($active_session['login_time'])) ?></span>
                                </div>
                            </div>
                            <div class="timer-container">
                                <div class="timer-label">⏱ Session Duration</div>
                                <div class="timer-display" id="timer-display">00:00:00</div>
                            </div>
                            <div style="margin-top:1rem; text-align:center; color:var(--text-muted); font-size:0.82rem; font-style:italic;">
                                ⏳ Please wait for the admin to end your session.
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="no-session-container">
                            <div class="no-session-icon">🖥️</div>
                            <p class="no-session-text">No active sit-in session</p>
                            <?php if ($sessions_left > 0): ?>
                                <button class="btn-request-sit" onclick="openPopup('sitinModal')">➕ Request Sit-in</button>
                                <button class="btn-request-sit" style="width:100%; margin-top:0.6rem; background:linear-gradient(135deg,#5a3fa0,#7b5ea7); box-shadow:0 4px 15px rgba(90,63,160,0.4);" onclick="openPopup('rulesPopup')">
                                📋 View Rules &amp; Regulations
                                </button>
                            <?php else: ?>
                                <div class="session-error">⚠️ No sessions remaining. Contact admin.</div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        <!-- Announcements & Rules Card -->
        <div class="card">
            <div class="card-header" style="display:flex; justify-content:space-between; align-items:center;">
                <span>📢 Announcements</span>
                <a href="student_notifications.php" style="font-size:0.78rem; color:var(--gold); font-weight:700; text-decoration:none;">View All →</a>
            </div>
            <div class="card-body">
                <?php if (empty($ann_rows)): ?>
                    <p style="color:var(--text-muted); font-size:0.88rem;">No announcements at this time.</p>
                <?php else: $a = $ann_rows[0]; ?>
                    <div style="background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:10px; padding:0.85rem 1rem; margin-bottom:1rem;">
                        <div style="font-size:0.72rem; color:var(--text-muted); margin-bottom:0.4rem;">
                            📅 <?= date('M d, Y', strtotime($a['created_at'])) ?>
                        </div>
                        <div style="font-size:0.88rem; color:#ddd; line-height:1.6; display:-webkit-box; -webkit-line-clamp:3; -webkit-box-orient:vertical; overflow:hidden;">
                            <?= nl2br(htmlspecialchars($a['message'])) ?>
                        </div>
                    </div>
                <?php endif; ?>
                <a href="student_notifications.php" style="display:block; text-align:center; text-decoration:none;">
                    <button class="btn-request-sit" style="width:100%; margin-bottom:0.6rem;">📢 View All Announcements</button>
                </a>
            </div>
        </div>

            <!-- History Card (latest 3) -->
            <div class="card">
                <div class="card-header" style="display:flex; justify-content:space-between; align-items:center;">
                    <span>📋 My Sit-in History</span>
                    <a href="student_history.php" style="font-size:0.78rem; color:var(--gold); font-weight:700; text-decoration:none;">View All →</a>
                </div>
                <div class="card-body" style="padding:0">
                    <?php if (empty($history_rows)): ?>
                        <div class="empty-history">
                            <div class="empty-icon">📭</div>
                            <p>No sit-in history yet.</p>
                            <small>Start your first sit-in session!</small>
                        </div>
                    <?php else: ?>
                        <div class="table-wrapper">
                            <table class="history-table">
                                <thead>
                                    <tr>
                                        <th>Lab</th>
                                        <th>Purpose</th>
                                        <th>Login</th>
                                        <th>Logout</th>
                                        <th>Status</th>
                                        <th>Feedback</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($history_rows as $h): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($h['lab']) ?></td>
                                        <td><?= htmlspecialchars($h['purpose']) ?></td>
                                        <td><?= date('M d, h:i A', strtotime($h['login_time'])) ?></td>
                                        <td><?= $h['logout_time'] ? date('M d, h:i A', strtotime($h['logout_time'])) : '—' ?></td>
                                        <td>
                                            <span class="status-badge <?= $h['status'] === 'Active' ? 'status-active' : 'status-done' ?>">
                                                <?= $h['status'] ?>
                                            </span>
                                        </td>
                                        <td style="text-align:center;">
                                            <?php if ($h['status'] === 'Done'): ?>
                                                <?php if (in_array($h['id'], $already_rated)): ?>
                                                    <span title="Already rated" style="color:#27ae60; font-size:1.1rem;">✅</span>
                                                <?php else: ?>
                                                    <button onclick="openFeedbackModal(<?= $h['id'] ?>)" title="Rate this session"
                                                        style="background:none; border:none; cursor:pointer; font-size:1.2rem; color:#f0c040; padding:0;">⭐</button>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span style="color:#555; font-size:0.75rem;">—</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</main>

<footer>&copy; 2026 College of Computer Studies</footer>

<script>
// Star rating for feedback modal
const ratingLabels = ['','😞 Poor','😕 Fair','😐 Okay','😊 Good','🤩 Excellent'];
function openFeedbackModal(sessionId) {
    document.getElementById('fb_session_id').value = sessionId;
    document.getElementById('fb_rating_input').value = 0;
    document.getElementById('ratingLabel').textContent = '';
    document.getElementById('fb_text').value = '';
    document.getElementById('fb_submit_btn').disabled = true;
    document.querySelectorAll('.fb-star').forEach(s => s.style.color = '#444');
    openPopup('feedbackModal');
}
function setFbRating(val) {
    document.getElementById('fb_rating_input').value = val;
    document.getElementById('ratingLabel').textContent = ratingLabels[val];
    document.getElementById('fb_submit_btn').disabled = false;
    document.querySelectorAll('.fb-star').forEach((s, i) => {
        s.style.color = i < val ? '#f0c040' : '#444';
    });
}

// Messages panel - marks messages as read then opens modal
function openMessagesPanel() {
    fetch('mark_messages_read.php');
    openPopup('messagesPopup');
}

function closeWelcome() {
    const el = document.getElementById('welcomePopup');
    el.style.animation = 'fadeOut 0.2s ease forwards';
    setTimeout(() => el.remove(), 200);
}
function openPopup(id) {
    const el = document.getElementById(id);
    el.style.display = 'flex';
    el.style.animation = 'fadeIn 0.25s ease';
}
function closePopup(id) {
    const el = document.getElementById(id);
    el.style.animation = 'fadeOut 0.2s ease forwards';
    setTimeout(() => { el.style.display = 'none'; el.style.animation = ''; }, 200);
}
document.querySelectorAll('.popup-overlay').forEach(overlay => {
    overlay.addEventListener('click', function(e) {
        if (e.target === this && this.id !== 'welcomePopup') closePopup(this.id);
    });
});
function previewAndUpload(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = e => {
            const preview = document.getElementById('preview');
            const placeholder = document.getElementById('preview-placeholder');
            preview.src = e.target.result;
            preview.style.display = 'block';
            if (placeholder) placeholder.style.display = 'none';
        };
        reader.readAsDataURL(input.files[0]);
        input.closest('form').submit();
    }
}
<?php if ($active_session): ?>
const loginTime = new Date("<?= $active_session['login_time'] ?>").getTime();
function updateTimer() {
    const diff = Date.now() - loginTime;
    const h = Math.floor(diff / 3600000).toString().padStart(2,'0');
    const m = Math.floor((diff % 3600000) / 60000).toString().padStart(2,'0');
    const s = Math.floor((diff % 60000) / 1000).toString().padStart(2,'0');
    document.getElementById('timer-display').textContent = h + ':' + m + ':' + s;
}
updateTimer();
setInterval(updateTimer, 1000);
<?php endif; ?>
<?php if (!empty($sitin_error)): ?>
window.addEventListener('DOMContentLoaded', () => openPopup('sitinModal'));
<?php endif; ?>
</script>
</body>
</html>