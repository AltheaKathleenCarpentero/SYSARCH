<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php");
    exit();
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}

require_once 'config.php';

// Fetch full student data
$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->bind_param("i", $_SESSION['student_id']);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Handle profile photo upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_photo'])) {
    $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $file = $_FILES['profile_photo'];
    if (in_array($file['type'], $allowed) && $file['error'] === 0) {
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'student_' . $_SESSION['student_id'] . '.' . $ext;
        $upload_path = 'assets/uploads/' . $filename;
        if (!is_dir('assets/uploads')) mkdir('assets/uploads', 0755, true);
        if (move_uploaded_file($file['tmp_name'], $upload_path)) {
            $stmt = $conn->prepare("UPDATE students SET photo = ? WHERE id = ?");
            $stmt->bind_param("si", $filename, $_SESSION['student_id']);
            $stmt->execute();
            $stmt->close();
            $student['photo'] = $filename;
        }
    }
}

$photo = !empty($student['photo']) ? 'assets/uploads/' . $student['photo'] : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard – CCS Sit-in Monitoring</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/dashboard.css">
</head>
<body>

    <!-- NAV -->
    <nav>
        <span class="nav-brand">CCS Sit-in Monitoring System</span>
        <a href="?logout=1" class="logout-btn">Logout</a>
    </nav>

    <!-- WELCOME POPUP -->
    <?php if (true): ?>
    <div class="popup-overlay" id="welcomePopup">
        <div class="popup-box">
            <div class="popup-icon">🎉</div>
            <div class="popup-title">Welcome back!</div>
            <div class="popup-msg">
                Good to see you, <strong><?= htmlspecialchars($student['first_name']) ?>!</strong><br>
                You're now logged in to the CCS Sit-in Monitoring System.
            </div>
            <button class="popup-btn" onclick="closeWelcome()">Got It!</button>
        </div>
    </div>
    <?php endif; ?>

    <!-- ANNOUNCEMENTS POPUP -->
    <div class="popup-overlay" id="announcementsPopup" style="display:none">
        <div class="popup-box popup-wide">
            <div class="popup-icon">📢</div>
            <div class="popup-title">Announcements</div>
            <div class="popup-scroll">
                <div class="announcement-item">
                    <div class="announcement-meta">CCS Admin · 2026-March-13</div>
                    <div class="announcement-text">No announcements at this time. Check back later!</div>
                </div>

            </div>
            <button class="popup-btn" onclick="closePopup('announcementsPopup')">Close</button>
        </div>
    </div>

    <!-- RULES POPUP -->
    <div class="popup-overlay" id="rulesPopup" style="display:none">
        <div class="popup-box popup-wide">
            <div class="popup-icon">📋</div>
            <div class="popup-title">Rules & Regulations</div>
            <div class="popup-scroll">
                <div class="rules-title">University of Cebu</div>
                <div class="rules-subtitle">College of Information & Computer Studies<br>Laboratory Rules and Regulations</div>
                <p>To avoid embarrassment and maintain camaraderie with your friends and superiors at our laboratories, please observe the following:</p>
                <p>1. Maintain silence, proper decorum, and discipline inside the laboratory. Mobile phones, walkmans and other personal pieces of equipment must be switched off.</p>
                <p>2. Games are not allowed inside the lab. This includes computer-related games, card games and other games that may disturb the operation of the lab.</p>
                <p>3. Surfing the Internet is allowed only with the permission of the instructor. Downloading and installing of software are strictly prohibited.</p>
                <p>4. Getting access to other websites not related to the course (especially pornographic and illicit sites) is strictly prohibited.</p>
                <p>5. Deleting computer files and changing the set-up of the computer is a major offense.</p>
                <p>6. Observe computer time usage carefully. A fifteen-minute allowance is given for each use. Otherwise, the unit will be given to those who wish to "sit-in".</p>
                <p>7. Observe proper decorum while inside the laboratory.</p>
                <ul>
                    <li>Do not get inside the lab unless the instructor is present.</li>
                    <li>All bags, knapsacks, and the likes must be deposited at the counter.</li>
                    <li>Follow the seating arrangement of your instructor.</li>
                    <li>At the end of class, all software programs must be closed.</li>
                    <li>Return all chairs to their proper places after using.</li>
                </ul>
                <p>8. Chewing gum, eating, drinking, smoking, and other forms of vandalism are prohibited inside the lab.</p>
                <p>9. Anyone causing a continual disturbance will be asked to leave the lab. Acts or gestures offensive to the members of the community, including public display of physical intimacy, are not tolerated.</p>
                <p>10. Persons exhibiting hostile or threatening behavior such as yelling, swearing, or disregarding requests made by lab personnel will be asked to leave the lab.</p>
                <p>11. For serious offense, the lab personnel may call the Civil Security Office (CSU) for assistance.</p>
                <p>12. Any technical problem or difficulty must be addressed to the laboratory supervisor, student assistant or instructor immediately.</p>
                <div class="rules-section">Disciplinary Action</div>
                <ul>
                    <li><strong>First Offense</strong> — The Head or the Dean or OIC recommends to the Guidance Center for a suspension from classes for each offender.</li>
                    <li><strong>Second and Subsequent Offenses</strong> — A recommendation for a heavier sanction will be endorsed to the Guidance Center.</li>
                </ul>
            </div>
            <button class="popup-btn" onclick="closePopup('rulesPopup')">Close</button>
        </div>
    </div>

    <!-- MAIN -->
    <main>
        <div class="card">
            <div class="card-header">👤 Student Information</div>
            <div class="card-body">
                <form method="POST" enctype="multipart/form-data">
                    <div class="profile-photo-wrap">
                        <?php if ($photo && file_exists($photo)): ?>
                            <img src="<?= htmlspecialchars($photo) ?>?v=<?= time() ?>" class="profile-photo" id="preview" alt="Profile">
                        <?php else: ?>
                            <div class="photo-placeholder" id="preview-placeholder">🎓</div>
                            <img src="" class="profile-photo" id="preview" alt="Profile" style="display:none">
                        <?php endif; ?>
                        <label class="upload-label" for="photo-input">📷 Change Photo</label>
                        <input type="file" id="photo-input" name="profile_photo" accept="image/*" onchange="previewAndUpload(this)">
                    </div>
                </form>

                <div class="info-row">
                    <span class="icon">👤</span>
                    <div><div class="label">Name</div><div class="value"><?= htmlspecialchars($student['first_name'] . ' ' . $student['middle_name'] . ' ' . $student['last_name']) ?></div></div>
                </div>
                <div class="info-row">
                    <span class="icon">🎓</span>
                    <div><div class="label">Course</div><div class="value"><?= htmlspecialchars($student['course']) ?></div></div>
                </div>
                <div class="info-row">
                    <span class="icon">📅</span>
                    <div><div class="label">Year Level</div><div class="value">Year <?= htmlspecialchars($student['course_level']) ?></div></div>
                </div>
                <div class="info-row">
                    <span class="icon">✉️</span>
                    <div><div class="label">Email</div><div class="value"><?= htmlspecialchars($student['email'] ?? '—') ?></div></div>
                </div>
                <div class="info-row">
                    <span class="icon">📍</span>
                    <div><div class="label">Address</div><div class="value"><?= htmlspecialchars($student['address'] ?? '—') ?></div></div>
                </div>

                <div class="session-badge">
                    <span>🕐</span>
                    Sessions Remaining: 30
                </div>

                <!-- Quick Action Buttons -->
                <div class="action-btns">
                    <button class="action-btn" onclick="openPopup('announcementsPopup')">📢 Announcements</button>
                    <button class="action-btn" onclick="openPopup('rulesPopup')">📋 Rules & Regulations</button>
                </div>
            </div>
        </div>
    </main>

    <footer>&copy; 2026 College of Computer Studies</footer>

    <script>
        function closeWelcome() {
            document.getElementById('welcomePopup').style.animation = 'fadeOut 0.2s ease forwards';
            setTimeout(() => document.getElementById('welcomePopup').remove(), 200);
        }

        function openPopup(id) {
            const el = document.getElementById(id);
            el.style.display = 'flex';
            el.style.animation = 'fadeIn 0.25s ease';
        }

        function closePopup(id) {
            const el = document.getElementById(id);
            el.style.animation = 'fadeOut 0.2s ease forwards';
            setTimeout(() => { el.style.display = 'none'; el.style.animation = ''; }, 200);
        }

        // Close popup when clicking outside
        document.querySelectorAll('.popup-overlay').forEach(overlay => {
            overlay.addEventListener('click', function(e) {
                if (e.target === this) {
                    const id = this.id;
                    if (id !== 'welcomePopup') closePopup(id);
                }
            });
        });

        function previewAndUpload(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = e => {
                    const preview = document.getElementById('preview');
                    const placeholder = document.getElementById('preview-placeholder');
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                    if (placeholder) placeholder.style.display = 'none';
                };
                reader.readAsDataURL(input.files[0]);
                input.closest('form').submit();
            }
        }
    </script>

</body>
</html>