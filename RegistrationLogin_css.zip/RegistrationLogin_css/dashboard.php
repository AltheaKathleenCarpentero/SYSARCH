<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php"); exit();
}
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php"); exit();
}

require_once 'config.php';
$sid = $_SESSION['student_id'];

// Fetch student
$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->bind_param("i", $sid);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Handle profile photo upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_photo'])) {
    $allowed = ['image/jpeg','image/png','image/gif','image/webp'];
    $file = $_FILES['profile_photo'];
    if (in_array($file['type'], $allowed) && $file['error'] === 0) {
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'student_' . $sid . '.' . $ext;
        $upload_path = 'assets/uploads/' . $filename;
        if (!is_dir('assets/uploads')) mkdir('assets/uploads', 0755, true);
        if (move_uploaded_file($file['tmp_name'], $upload_path)) {
            $stmt = $conn->prepare("UPDATE students SET photo = ? WHERE id = ?");
            $stmt->bind_param("si", $filename, $sid);
            $stmt->execute(); $stmt->close();
            $student['photo'] = $filename;
        }
    }
    header("Location: dashboard.php"); exit();
}

// Check if student has an ACTIVE sit-in session
$res = $conn->prepare("SELECT * FROM sit_in_sessions WHERE student_id = ? AND status = 'Active' LIMIT 1");
$res->bind_param("i", $sid);
$res->execute();
$active_session = $res->get_result()->fetch_assoc();
$res->close();

// Handle SIT-IN REQUEST (start session)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['start_sitin'])) {
    if ($active_session) {
        $sitin_error = "You already have an active sit-in session. Please log out first.";
    } elseif (($student['sessions'] ?? 30) <= 0) {
        $sitin_error = "You have no remaining sessions.";
    } else {
        $purpose = trim($_POST['purpose']);
        $lab     = trim($_POST['lab']);
        if (!empty($purpose) && !empty($lab)) {
            $ins = $conn->prepare("INSERT INTO sit_in_sessions (student_id, purpose, lab) VALUES (?,?,?)");
            $ins->bind_param("iss", $sid, $purpose, $lab);
            $ins->execute(); $ins->close();
            $res = $conn->prepare("SELECT * FROM sit_in_sessions WHERE student_id = ? AND status = 'Active' LIMIT 1");
            $res->bind_param("i", $sid);
            $res->execute();
            $active_session = $res->get_result()->fetch_assoc();
            $res->close();
            $sitin_success = "Sit-in session started! Lab: $lab";
        } else {
            $sitin_error = "Please fill in purpose and lab.";
        }
    }
}

// Handle SIT-OUT (end session)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['end_sitin'])) {
    if ($active_session) {
        $upd = $conn->prepare("UPDATE sit_in_sessions SET logout_time = NOW(), status = 'Done' WHERE id = ? AND student_id = ?");
        $upd->bind_param("ii", $active_session['id'], $sid);
        $upd->execute(); $upd->close();
        $conn->query("UPDATE students SET sessions = GREATEST(0, sessions - 1) WHERE id = $sid");
        $stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
        $stmt->bind_param("i", $sid);
        $stmt->execute();
        $student = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $active_session = null;
        $sitin_success = "Sit-in session ended. Sessions remaining: " . $student['sessions'];
    }
}

// Fetch sit-in history
$history = $conn->prepare("SELECT * FROM sit_in_sessions WHERE student_id = ? ORDER BY login_time DESC LIMIT 20");
$history->bind_param("i", $sid);
$history->execute();
$history_rows = $history->get_result()->fetch_all(MYSQLI_ASSOC);
$history->close();

// Fetch announcements
$ann_rows = $conn->query("SELECT * FROM announcements ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);

$photo = (!empty($student['photo']) && file_exists('assets/uploads/' . $student['photo']))
    ? 'assets/uploads/' . $student['photo'] : null;
$sessions_left = $student['sessions'] ?? 30;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard – CCS Sit-in Monitoring</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/dashboard.css">
</head>
<body>

<nav>
    <span class="nav-brand">🖥️ CCS Sit-in Monitoring System</span>
    <a href="?logout=1" class="logout-btn">Logout</a>
</nav>

<!-- WELCOME POPUP -->
<div class="popup-overlay" id="welcomePopup">
    <div class="popup-box">
        <div class="popup-icon">🎉</div>
        <div class="popup-title">Welcome back!</div>
        <div class="popup-msg">
            Good to see you, <strong><?= htmlspecialchars($student['first_name']) ?>!</strong><br>
            You're logged in to the CCS Sit-in Monitoring System.
        </div>
        <button class="popup-btn" onclick="closeWelcome()">Got It!</button>
    </div>
</div>

<!-- ANNOUNCEMENTS POPUP -->
<div class="popup-overlay" id="announcementsPopup" style="display:none">
    <div class="popup-box popup-wide">
        <div class="popup-icon">📢</div>
        <div class="popup-title">Announcements</div>
        <div class="popup-scroll">
            <?php if (empty($ann_rows)): ?>
                <div class="announcement-item"><div class="announcement-text">No announcements at this time.</div></div>
            <?php else: foreach ($ann_rows as $a): ?>
                <div class="announcement-item">
                    <div class="announcement-meta">CCS Admin · <?= date('Y-M-d', strtotime($a['created_at'])) ?></div>
                    <div class="announcement-text"><?= nl2br(htmlspecialchars($a['message'])) ?></div>
                </div>
            <?php endforeach; endif; ?>
        </div>
        <button class="popup-btn" onclick="closePopup('announcementsPopup')">Close</button>
    </div>
</div>

<!-- RULES POPUP -->
<div class="popup-overlay" id="rulesPopup" style="display:none">
    <div class="popup-box popup-wide">
        <div class="popup-icon">📋</div>
        <div class="popup-title">Rules & Regulations</div>
        <div class="popup-scroll">
            <div class="rules-title">University of Cebu</div>
            <div class="rules-subtitle">College of Computer Studies<br>Laboratory Rules and Regulations</div>
            <p>1. Maintain silence, proper decorum, and discipline inside the laboratory.</p>
            <p>2. Games are not allowed inside the lab.</p>
            <p>3. Surfing the Internet is allowed only with the permission of the instructor.</p>
            <p>4. Getting access to other websites not related to the course is strictly prohibited.</p>
            <p>5. Deleting computer files and changing the set-up of the computer is a major offense.</p>
            <p>6. Observe computer time usage carefully. A fifteen-minute allowance is given for each use.</p>
            <p>7. Observe proper decorum while inside the laboratory.</p>
            <ul>
                <li>Do not get inside the lab unless the instructor is present.</li>
                <li>All bags and knapsacks must be deposited at the counter.</li>
                <li>Follow the seating arrangement of your instructor.</li>
                <li>At the end of class, all software programs must be closed.</li>
                <li>Return all chairs to their proper places after using.</li>
            </ul>
            <p>8. Chewing gum, eating, drinking, smoking, and vandalism are prohibited inside the lab.</p>
            <p>9. Anyone causing a continual disturbance will be asked to leave the lab.</p>
            <p>10. Persons exhibiting hostile or threatening behavior will be asked to leave the lab.</p>
            <div class="rules-section">Disciplinary Action</div>
            <ul>
                <li><strong>First Offense</strong> — Suspension from classes.</li>
                <li><strong>Second and Subsequent Offenses</strong> — Heavier sanction.</li>
            </ul>
        </div>
        <button class="popup-btn" onclick="closePopup('rulesPopup')">Close</button>
    </div>
</div>

<!-- SIT-IN MODAL -->
<div class="popup-overlay" id="sitinModal" style="display:none">
    <div class="popup-box" style="max-width:400px">
        <div class="popup-icon">💻</div>
        <div class="popup-title">Request Sit-in</div>
        <?php if (!empty($sitin_error)): ?>
            <div class="alert-error"><?= htmlspecialchars($sitin_error) ?></div>
        <?php endif; ?>
        <form method="POST" style="text-align:left; margin-top:1rem">
            <div class="form-group" style="margin-bottom:0.9rem">
                <label class="field-label">Purpose / Subject</label>
                <input type="text" name="purpose" class="field-input" placeholder="e.g. Programming Practice" required>
            </div>
            <div class="form-group" style="margin-bottom:1.4rem">
                <label class="field-label">Laboratory</label>
                <select name="lab" class="field-input" required>
                    <option value="">Select Lab</option>
                    <option value="Lab 517">Lab 517</option>
                    <option value="Lab 518">Lab 518</option>
                    <option value="Lab 519">Lab 519</option>
                    <option value="Lab 524">Lab 524</option>
                    <option value="Lab 526">Lab 526</option>
                    <option value="Lab 528">Lab 528</option>
                    <option value="Lab 530">Lab 530</option>
                    <option value="Lab 542">Lab 542</option>
                </select>
            </div>
            <div style="display:flex; gap:0.75rem">
                <button type="button" class="btn-secondary" onclick="closePopup('sitinModal')" style="flex:1">Cancel</button>
                <button type="submit" name="start_sitin" class="popup-btn" style="flex:2; padding:0.7rem">Confirm Sit-in</button>
            </div>
        </form>
    </div>
</div>

<main class="dashboard-main">
    <?php if (!empty($sitin_success)): ?>
        <div class="alert-success-banner"><?= htmlspecialchars($sitin_success) ?></div>
    <?php endif; ?>

    <div class="dashboard-grid">

        <!-- LEFT: Student Info -->
        <div class="card">
            <div class="card-header">👤 Student Information</div>
            <div class="card-body">
                <form method="POST" enctype="multipart/form-data">
                    <div class="profile-photo-wrap">
                        <?php if ($photo): ?>
                            <img src="<?= htmlspecialchars($photo) ?>?v=<?= time() ?>" class="profile-photo" id="preview" alt="Profile">
                        <?php else: ?>
                            <div class="photo-placeholder" id="preview-placeholder">🎓</div>
                            <img src="" class="profile-photo" id="preview" alt="Profile" style="display:none">
                        <?php endif; ?>
                        <label class="upload-label" for="photo-input">📷 Change Photo</label>
                        <input type="file" id="photo-input" name="profile_photo" accept="image/*" onchange="previewAndUpload(this)">
                    </div>
                </form>

                <div class="info-row"><span class="icon">👤</span>
                    <div><div class="label">Full Name</div>
                    <div class="value"><?= htmlspecialchars($student['first_name'].' '.$student['middle_name'].' '.$student['last_name']) ?></div></div>
                </div>
                <div class="info-row"><span class="icon">🪪</span>
                    <div><div class="label">ID Number</div>
                    <div class="value"><?= htmlspecialchars($student['id_number']) ?></div></div>
                </div>
                <div class="info-row"><span class="icon">🎓</span>
                    <div><div class="label">Course</div>
                    <div class="value"><?= htmlspecialchars($student['course']) ?></div></div>
                </div>
                <div class="info-row"><span class="icon">📅</span>
                    <div><div class="label">Year Level</div>
                    <div class="value">Year <?= htmlspecialchars($student['course_level']) ?></div></div>
                </div>
                <div class="info-row"><span class="icon">✉️</span>
                    <div><div class="label">Email</div>
                    <div class="value"><?= htmlspecialchars($student['email'] ?? '—') ?></div></div>
                </div>
                <div class="info-row"><span class="icon">📍</span>
                    <div><div class="label">Address</div>
                    <div class="value"><?= htmlspecialchars($student['address'] ?? '—') ?></div></div>
                </div>

                <div class="session-badge <?= $sessions_left <= 5 ? 'session-low' : '' ?>">
                    <span>🕐</span>
                    Sessions Remaining: <strong><?= $sessions_left ?></strong>
                </div>

                <div class="action-btns">
                    <button class="action-btn" onclick="openPopup('announcementsPopup')">📢 Announcements</button>
                    <button class="action-btn" onclick="openPopup('rulesPopup')">📋 Rules</button>
                </div>
            </div>
        </div>

        <!-- RIGHT: Sit-in + History -->
        <div style="display:flex; flex-direction:column; gap:1.2rem">

            <div class="card">
                <div class="card-header">💻 Sit-in Session</div>
                <div class="card-body">
                    <?php if ($active_session): ?>
                        <div class="active-session-box">
                            <div class="active-badge">🟢 ACTIVE SESSION</div>
                            <div class="active-detail"><strong>Lab:</strong> <?= htmlspecialchars($active_session['lab']) ?></div>
                            <div class="active-detail"><strong>Purpose:</strong> <?= htmlspecialchars($active_session['purpose']) ?></div>
                            <div class="active-detail"><strong>Started:</strong> <?= date('M d, Y h:i A', strtotime($active_session['login_time'])) ?></div>
                            <div class="active-timer">⏱ <span id="timer-display">00:00:00</span></div>
                            <form method="POST" onsubmit="return confirm('End your sit-in session now?')">
                                <button type="submit" name="end_sitin" class="btn-sitout">🚪 Sit-out / End Session</button>
                            </form>
                        </div>
                    <?php else: ?>
                        <div class="no-session-box">
                            <div class="no-session-icon">🖥️</div>
                            <p>No active sit-in session.</p>
                            <?php if ($sessions_left > 0): ?>
                                <button class="btn-sitin" onclick="openPopup('sitinModal')">➕ Request Sit-in</button>
                            <?php else: ?>
                                <div class="alert-error" style="margin-top:0.8rem">No sessions remaining. Please contact the administrator.</div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card">
                <div class="card-header">📋 My Sit-in History</div>
                <div class="card-body" style="padding:0">
                    <?php if (empty($history_rows)): ?>
                        <div style="padding:1.5rem; text-align:center; color:var(--text-muted); font-size:0.88rem; font-weight:600">No sit-in history yet.</div>
                    <?php else: ?>
                    <div class="table-wrap">
                        <table class="history-table">
                            <thead>
                                <tr><th>Lab</th><th>Purpose</th><th>Login</th><th>Logout</th><th>Status</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($history_rows as $h): ?>
                                <tr>
                                    <td><?= htmlspecialchars($h['lab']) ?></td>
                                    <td><?= htmlspecialchars($h['purpose']) ?></td>
                                    <td><?= date('M d, h:i A', strtotime($h['login_time'])) ?></td>
                                    <td><?= $h['logout_time'] ? date('M d, h:i A', strtotime($h['logout_time'])) : '—' ?></td>
                                    <td><span class="<?= $h['status'] === 'Active' ? 'badge-active' : 'badge-done' ?>"><?= $h['status'] ?></span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</main>

<footer>&copy; 2026 College of Computer Studies</footer>

<script>
function closeWelcome() {
    const el = document.getElementById('welcomePopup');
    el.style.animation = 'fadeOut 0.2s ease forwards';
    setTimeout(() => el.remove(), 200);
}
function openPopup(id) {
    const el = document.getElementById(id);
    el.style.display = 'flex';
    el.style.animation = 'fadeIn 0.25s ease';
}
function closePopup(id) {
    const el = document.getElementById(id);
    el.style.animation = 'fadeOut 0.2s ease forwards';
    setTimeout(() => { el.style.display = 'none'; el.style.animation = ''; }, 200);
}
document.querySelectorAll('.popup-overlay').forEach(overlay => {
    overlay.addEventListener('click', function(e) {
        if (e.target === this && this.id !== 'welcomePopup') closePopup(this.id);
    });
});
function previewAndUpload(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = e => {
            const preview = document.getElementById('preview');
            const placeholder = document.getElementById('preview-placeholder');
            preview.src = e.target.result;
            preview.style.display = 'block';
            if (placeholder) placeholder.style.display = 'none';
        };
        reader.readAsDataURL(input.files[0]);
        input.closest('form').submit();
    }
}
<?php if ($active_session): ?>
const loginTime = new Date("<?= $active_session['login_time'] ?>").getTime();
function updateTimer() {
    const diff = Date.now() - loginTime;
    const h = Math.floor(diff / 3600000).toString().padStart(2,'0');
    const m = Math.floor((diff % 3600000) / 60000).toString().padStart(2,'0');
    const s = Math.floor((diff % 60000) / 1000).toString().padStart(2,'0');
    document.getElementById('timer-display').textContent = h + ':' + m + ':' + s;
}
updateTimer();
setInterval(updateTimer, 1000);
<?php endif; ?>
<?php if (!empty($sitin_error)): ?>
window.addEventListener('DOMContentLoaded', () => openPopup('sitinModal'));
<?php endif; ?>
</script>
</body>
</html>