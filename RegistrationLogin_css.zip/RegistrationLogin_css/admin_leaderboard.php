<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php"); exit();
}
require_once 'config.php';

// Handle manual point addition
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_points'])) {
    $student_id = intval($_POST['student_id']);
    $points     = floatval($_POST['points']);
    if ($student_id > 0 && $points > 0) {
        $conn->query("UPDATE students SET points = points + $points, total_points = total_points + $points WHERE id = $student_id");

        // Auto-convert if balance >= 3
        $bal = $conn->query("SELECT points FROM students WHERE id = $student_id")->fetch_assoc();
        $pts = floatval($bal['points']);
        $sessions_to_add = floor($pts / 3);
        if ($sessions_to_add >= 1) {
            $deduct = $sessions_to_add * 3;
            $conn->query("UPDATE students SET points = points - $deduct, sessions = sessions + $sessions_to_add WHERE id = $student_id");
        }
    }
    header("Location: admin_leaderboard.php"); exit();
}

$by_points = $conn->query("
    SELECT id, id_number, CONCAT(first_name,' ',last_name) as name, course, total_points as points
    FROM students
    ORDER BY total_points DESC, last_name ASC
")->fetch_all(MYSQLI_ASSOC);

// All students ranked by total sit-in hours
$by_hours = $conn->query("
    SELECT st.id, st.id_number, CONCAT(st.first_name,' ',st.last_name) as name, st.course,
           COALESCE(SUM(TIMESTAMPDIFF(MINUTE, s.login_time, IFNULL(s.logout_time, NOW()))), 0) as total_minutes
    FROM students st
    LEFT JOIN sit_in_sessions s ON s.student_id = st.id AND s.status = 'Done'
    GROUP BY st.id
    ORDER BY total_minutes DESC, name ASC
")->fetch_all(MYSQLI_ASSOC);

$all_students = $conn->query("SELECT id, id_number, CONCAT(first_name,' ',last_name) as name FROM students ORDER BY last_name")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Leaderboard – CCS Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/admin.css">
    <style>
        .lb-tabs { display:flex; gap:0.5rem; margin-bottom:1.5rem; }
        .lb-tab { padding:0.6rem 1.4rem; border-radius:8px; font-weight:700; font-size:0.85rem; cursor:pointer; border:2px solid rgba(212,160,23,0.3); color:var(--text-muted); background:transparent; transition:all 0.2s; }
        .lb-tab.active { background:var(--gold); color:#1a0a2e; border-color:var(--gold); }
        .lb-panel { display:none; } .lb-panel.active { display:block; }
        .rank-1 td:first-child { color:#FFD700; font-size:1.3rem; }
        .rank-2 td:first-child { color:#C0C0C0; font-size:1.2rem; }
        .rank-3 td:first-child { color:#CD7F32; font-size:1.1rem; }
        .rank-medal { font-size:1.1rem; }
        .pts-badge { background:linear-gradient(135deg,var(--gold),var(--gold-dim)); color:#1a0a2e; padding:2px 10px; border-radius:20px; font-weight:800; font-size:0.85rem; }
        .add-pts-btn { padding:4px 12px; font-size:0.78rem; border-radius:6px; background:rgba(212,160,23,0.15); border:1px solid rgba(212,160,23,0.4); color:var(--gold); cursor:pointer; font-weight:700; transition:all 0.2s; }
        .add-pts-btn:hover { background:var(--gold); color:#1a0a2e; }
        .hours-badge { background:rgba(74,174,217,0.15); color:#4aaed9; padding:2px 10px; border-radius:20px; font-weight:800; font-size:0.85rem; border:1px solid rgba(74,174,217,0.3); }
    </style>
</head>
<body>
<nav>
    <span class="nav-brand">🖥️ CCS Admin Panel</span>
    <div class="nav-links">
        <a href="admin.php">Dashboard</a>
        <a href="#" onclick="openModal('searchModal')">Search</a>
        <a href="admin_students.php">Students</a>
        <div class="nav-dropdown">
            <div class="nav-drop-toggle">Sit-in</div>
            <div class="nav-drop-menu">
                <a href="admin_sitin.php">📋 Sit-in</a>
                <a href="admin_sitin_records.php">📊 View Sit-in Records</a>
                <a href="admin_generate_reports.php">📥 Generate Reports</a>
            </div>
        </div>
        <a href="admin_leaderboard.php" class="active">🏆 Leaderboard</a>
        <a href="admin_feedback.php">Feedback Reports</a>
        <a href="admin_reservation.php">Reservation</a>
        <a href="admin.php?logout=1" class="logout-btn">Log out</a>
    </div>
</nav>

<!-- Search Modal -->
<div class="modal-overlay" id="searchModal" style="display:none">
    <div class="modal-box">
        <div class="modal-header"><span>🔍 Search Student</span><button class="modal-close" onclick="closeModal('searchModal')">✕</button></div>
        <div class="modal-body">
            <input type="text" id="searchInput" class="modal-input" placeholder="Name or ID number...">
            <div id="searchResults" class="search-results"></div>
        </div>
        <div class="modal-footer"><button class="btn-primary" onclick="searchStudent()">Search</button></div>
    </div>
</div>

<!-- Add Points Modal -->
<div class="modal-overlay" id="addPtsModal" style="display:none">
    <div class="modal-box" style="max-width:400px">
        <div class="modal-header"><span>⭐ Add Points</span><button class="modal-close" onclick="closeModal('addPtsModal')">✕</button></div>
        <form method="POST">
            <div class="modal-body">
                <div class="form-group">
                    <label>Student</label>
                    <select name="student_id" id="pts_student_id" class="modal-input" required>
                        <option value="">Select Student</option>
                        <?php foreach ($all_students as $s): ?>
                        <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['id_number'] . ' — ' . $s['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Points to Add</label>
                    <input type="number" name="points" class="modal-input" min="0.01" step="0.01" placeholder="e.g. 1.00" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeModal('addPtsModal')">Cancel</button>
                <button type="submit" name="add_points" class="btn-primary">Add Points</button>
            </div>
        </form>
    </div>
</div>

<main>
    <div class="page-title">🏆 Leaderboard</div>

    <div class="lb-tabs">
        <button class="lb-tab active" onclick="switchTab('points')">⭐ By Points</button>
        <button class="lb-tab" onclick="switchTab('hours')">⏱ By Sit-in Hours</button>
    </div>

    <!-- BY POINTS -->
    <div class="lb-panel active" id="panel-points">
        <div class="card">
            <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
                <span>⭐ Rankings by Points</span>
                <button class="btn-sm" onclick="openModal('addPtsModal')">➕ Add Points</button>
            </div>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr><th>Rank</th><th>ID Number</th><th>Name</th><th>Course</th><th>Points</th><th>Action</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($by_points as $i => $s): ?>
                    <tr class="<?= $i===0?'rank-1':($i===1?'rank-2':($i===2?'rank-3':'')) ?>">
                        <td><?= $i===0?'🥇':($i===1?'🥈':($i===2?'🥉':'#'.($i+1))) ?></td>
                        <td><?= htmlspecialchars($s['id_number']) ?></td>
                        <td><?= htmlspecialchars($s['name']) ?></td>
                        <td><?= htmlspecialchars($s['course']) ?></td>
                        <td><span class="pts-badge">⭐ <?= number_format($s['points'],2) ?></span></td>
                        <td>
                            <button class="add-pts-btn" onclick="openAddPts(<?= $s['id'] ?>)">+ Points</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- BY HOURS -->
    <div class="lb-panel" id="panel-hours">
        <div class="card">
            <div class="card-header">⏱ Rankings by Total Sit-in Hours</div>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr><th>Rank</th><th>ID Number</th><th>Name</th><th>Course</th><th>Total Hours</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($by_hours as $i => $s):
                        $h = floor($s['total_minutes'] / 60);
                        $m = $s['total_minutes'] % 60;
                    ?>
                    <tr class="<?= $i===0?'rank-1':($i===1?'rank-2':($i===2?'rank-3':'')) ?>">
                        <td><?= $i===0?'🥇':($i===1?'🥈':($i===2?'🥉':'#'.($i+1))) ?></td>
                        <td><?= htmlspecialchars($s['id_number']) ?></td>
                        <td><?= htmlspecialchars($s['name']) ?></td>
                        <td><?= htmlspecialchars($s['course']) ?></td>
                        <td><span class="hours-badge">⏱ <?= $h ?>h <?= $m ?>m</span></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<footer>&copy; 2026 College of Computer Studies</footer>
<script>
function switchTab(tab) {
    document.querySelectorAll('.lb-tab').forEach((t,i) => t.classList.toggle('active', (i===0&&tab==='points')||(i===1&&tab==='hours')));
    document.getElementById('panel-points').classList.toggle('active', tab==='points');
    document.getElementById('panel-hours').classList.toggle('active', tab==='hours');
}
function openModal(id)  { document.getElementById(id).style.display = 'flex'; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }
function openAddPts(studentId) {
    document.getElementById('pts_student_id').value = studentId;
    openModal('addPtsModal');
}
function searchStudent() {
    const q = document.getElementById('searchInput').value.trim(); if (!q) return;
    fetch('admin_search.php?q=' + encodeURIComponent(q)).then(r => r.text()).then(html => { document.getElementById('searchResults').innerHTML = html; });
}
document.getElementById('searchInput')?.addEventListener('keydown', e => { if (e.key === 'Enter') searchStudent(); });
</script>
</body>
</html>