<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php"); exit();
}
require_once 'config.php';

// Handle manual point addition
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_points'])) {
    $student_id = intval($_POST['student_id']);
    $points     = floatval($_POST['points']);
    if ($student_id > 0 && $points > 0) {
        $conn->query("UPDATE students SET points = points + $points, total_points = total_points + $points WHERE id = $student_id");
        $bal = $conn->query("SELECT points FROM students WHERE id = $student_id")->fetch_assoc();
        $pts = floatval($bal['points']);
        $sessions_to_add = floor($pts / 3);
        if ($sessions_to_add >= 1) {
            $deduct = $sessions_to_add * 3;
            $conn->query("UPDATE students SET points = points - $deduct, sessions = sessions + $sessions_to_add WHERE id = $student_id");
        }
    }
    header("Location: admin_leaderboard.php"); exit();
}

// Composite leaderboard query
$raw = $conn->query("
    SELECT
        st.id, st.id_number,
        CONCAT(st.first_name,' ',st.last_name) AS name,
        st.course, st.photo,
        COALESCE(st.total_points, 0) AS points,
        COALESCE(SUM(TIMESTAMPDIFF(MINUTE, s.login_time, IFNULL(s.logout_time, NOW()))), 0) AS total_minutes,
        COUNT(CASE WHEN s.status='Done' THEN 1 END) AS tasks_completed
    FROM students st
    LEFT JOIN sit_in_sessions s ON s.student_id = st.id
    GROUP BY st.id
")->fetch_all(MYSQLI_ASSOC);

$max_pts = !empty($raw) ? max(1, max(array_column($raw, 'points'))) : 1;
$max_min = !empty($raw) ? max(1, max(array_column($raw, 'total_minutes'))) : 1;
$max_tsk = !empty($raw) ? max(1, max(array_column($raw, 'tasks_completed'))) : 1;

foreach ($raw as &$r) {
    $r['score'] = round(
        ($r['points']/$max_pts)*60 +
        ($r['total_minutes']/$max_min)*20 +
        ($r['tasks_completed']/$max_tsk)*20, 2);
    $r['hours_h'] = floor($r['total_minutes']/60);
    $r['hours_m'] = $r['total_minutes'] % 60;
}
unset($r);
usort($raw, fn($a,$b) => $b['score'] <=> $a['score']);
$top10 = array_slice($raw, 0, 10);

$all_students = $conn->query("SELECT id, id_number, CONCAT(first_name,' ',last_name) as name FROM students ORDER BY last_name")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Leaderboard – CCS Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800;900&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/admin.css">
    <style>
        /* ── PODIUM SECTION ── */
        .lb-hero {
            text-align: center;
            padding: 2.5rem 1rem 1rem;
        }
        .lb-hero-label {
            font-size: 0.72rem; font-weight: 800; letter-spacing: 0.18em;
            color: var(--gold); text-transform: uppercase;
            border: 1px solid rgba(212,160,23,0.35);
            display: inline-block; padding: 0.3rem 1rem; border-radius: 20px;
            margin-bottom: 0.7rem;
        }
        .lb-hero-title {
            font-family: 'Playfair Display', serif;
            font-size: clamp(2rem, 5vw, 3rem);
            font-weight: 700; color: var(--text);
            margin-bottom: 0.4rem;
        }
        .lb-hero-sub {
            font-size: 0.84rem; color: var(--text-muted);
            max-width: 480px; margin: 0 auto 2rem; line-height: 1.6;
        }
        .lb-formula {
            display: inline-flex; gap: 0.5rem; flex-wrap: wrap;
            justify-content: center; margin-bottom: 2rem;
        }
        .lb-formula-chip {
            padding: 0.35rem 0.9rem; border-radius: 20px; font-size: 0.78rem;
            font-weight: 800; border: 1.5px solid;
        }
        .chip-pts  { background: rgba(212,160,23,0.12); color: var(--gold);    border-color: rgba(212,160,23,0.4); }
        .chip-hrs  { background: rgba(74,174,217,0.12); color: #4aaed9;        border-color: rgba(74,174,217,0.4); }
        .chip-tsk  { background: rgba(94,211,119,0.12); color: #5ed377;        border-color: rgba(94,211,119,0.4); }

        /* ── PODIUM CARDS ── */
        .podium-wrap {
            display: flex; justify-content: center; align-items: flex-end;
            gap: 1.2rem; padding: 0 1rem 2.5rem; flex-wrap: wrap;
        }
        .podium-card {
            background: var(--card-bg);
            border: 1.5px solid var(--border);
            border-radius: 20px;
            padding: 1.5rem 1.2rem 1.2rem;
            text-align: center;
            backdrop-filter: blur(16px);
            position: relative;
            transition: transform 0.2s;
            width: 200px;
        }
        .podium-card:hover { transform: translateY(-4px); }
        .podium-card.rank-1 {
            border-color: rgba(255,215,0,0.55);
            box-shadow: 0 0 40px rgba(255,215,0,0.12), 0 8px 32px rgba(0,0,0,0.4);
            width: 230px;
            padding-top: 2rem;
        }
        .podium-card.rank-2 { border-color: rgba(192,192,192,0.4); box-shadow: 0 0 24px rgba(192,192,192,0.08), 0 8px 24px rgba(0,0,0,0.35); }
        .podium-card.rank-3 { border-color: rgba(205,127,50,0.4);  box-shadow: 0 0 24px rgba(205,127,50,0.08),  0 8px 24px rgba(0,0,0,0.35); }

        .podium-crown {
            font-size: 2rem; line-height: 1;
            position: absolute; top: -1.1rem; left: 50%; transform: translateX(-50%);
            filter: drop-shadow(0 2px 6px rgba(0,0,0,0.6));
        }
        .podium-rank-badge {
            font-size: 0.65rem; font-weight: 900; letter-spacing: 0.12em;
            text-transform: uppercase; padding: 0.2rem 0.6rem;
            border-radius: 10px; display: inline-block; margin-bottom: 0.8rem;
        }
        .rank-1 .podium-rank-badge { background: rgba(255,215,0,0.2); color: #FFD700; border: 1px solid rgba(255,215,0,0.4); }
        .rank-2 .podium-rank-badge { background: rgba(192,192,192,0.15); color: #C0C0C0; border: 1px solid rgba(192,192,192,0.35); }
        .rank-3 .podium-rank-badge { background: rgba(205,127,50,0.15); color: #CD7F32; border: 1px solid rgba(205,127,50,0.35); }

        .podium-avatar {
            width: 80px; height: 80px; border-radius: 50%;
            object-fit: cover; margin: 0 auto 0.75rem; display: block;
            border: 3px solid;
        }
        .podium-avatar-placeholder {
            width: 80px; height: 80px; border-radius: 50%;
            margin: 0 auto 0.75rem; display: flex; align-items: center;
            justify-content: center; font-size: 2rem;
            background: linear-gradient(135deg, var(--violet-light), var(--violet-mid));
            border: 3px solid;
        }
        .rank-1 .podium-avatar, .rank-1 .podium-avatar-placeholder { border-color: #FFD700; width:96px; height:96px; }
        .rank-2 .podium-avatar, .rank-2 .podium-avatar-placeholder { border-color: #C0C0C0; }
        .rank-3 .podium-avatar, .rank-3 .podium-avatar-placeholder { border-color: #CD7F32; }

        .podium-name { font-size: 1rem; font-weight: 900; color: var(--text); margin-bottom: 0.15rem; }
        .rank-1 .podium-name { font-size: 1.1rem; }
        .podium-course { font-size: 0.72rem; color: var(--text-muted); font-weight: 600; margin-bottom: 0.8rem; }
        .podium-score {
            font-size: 1.5rem; font-weight: 900; line-height: 1;
            margin-bottom: 0.15rem;
        }
        .rank-1 .podium-score { color: #FFD700; font-size: 1.8rem; }
        .rank-2 .podium-score { color: #C0C0C0; }
        .rank-3 .podium-score { color: #CD7F32; }
        .podium-score-label { font-size: 0.68rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 0.75rem; }
        .podium-stats {
            display: flex; gap: 0.4rem; justify-content: center; flex-wrap: wrap;
        }
        .podium-stat {
            font-size: 0.68rem; font-weight: 800; padding: 0.2rem 0.5rem;
            border-radius: 8px;
        }
        .pstat-pts  { background: rgba(212,160,23,0.15); color: var(--gold); }
        .pstat-hrs  { background: rgba(74,174,217,0.15); color: #4aaed9; }
        .pstat-tsk  { background: rgba(94,211,119,0.15); color: #5ed377; }

        /* ── TABLE ── */
        .lb-table-section { max-width: 900px; margin: 0 auto 3rem; padding: 0 1.5rem; }
        .lb-table-title {
            font-size: 0.75rem; font-weight: 800; letter-spacing: 0.14em;
            text-transform: uppercase; color: var(--gold); margin-bottom: 0.8rem;
            padding-left: 0.25rem;
        }
        .lb-add-btn-row { display: flex; justify-content: flex-end; margin-bottom: 0.75rem; }

        .lb-table-wrap { overflow-x: auto; }
        .lb-table { width: 100%; border-collapse: collapse; font-size: 0.88rem; }
        .lb-table thead th {
            padding: 0.7rem 1rem; text-align: left;
            font-size: 0.7rem; font-weight: 800; text-transform: uppercase;
            letter-spacing: 0.08em; color: var(--text-muted);
            border-bottom: 1px solid var(--border);
        }
        .lb-table tbody tr {
            border-bottom: 1px solid rgba(212,160,23,0.07);
            transition: background 0.15s;
        }
        .lb-table tbody tr:hover { background: rgba(212,160,23,0.05); }
        .lb-table td { padding: 0.75rem 1rem; color: var(--text); vertical-align: middle; }
        .rank-num { font-weight: 900; color: var(--text-muted); font-size: 1rem; }
        .score-badge {
            background: linear-gradient(135deg, rgba(212,160,23,0.2), rgba(212,160,23,0.08));
            color: var(--gold-light); padding: 0.2rem 0.7rem; border-radius: 12px;
            font-weight: 900; font-size: 0.82rem; border: 1px solid rgba(212,160,23,0.3);
        }
        .pts-badge  { background: rgba(212,160,23,0.12); color: var(--gold); padding: 2px 8px; border-radius: 10px; font-weight: 800; font-size: 0.78rem; }
        .hrs-badge  { background: rgba(74,174,217,0.12); color: #4aaed9; padding: 2px 8px; border-radius: 10px; font-weight: 800; font-size: 0.78rem; }
        .tsk-badge  { background: rgba(94,211,119,0.12); color: #5ed377; padding: 2px 8px; border-radius: 10px; font-weight: 800; font-size: 0.78rem; }
        .add-pts-btn { padding: 4px 12px; font-size: 0.75rem; border-radius: 6px; background: rgba(212,160,23,0.12); border: 1px solid rgba(212,160,23,0.3); color: var(--gold); cursor: pointer; font-weight: 700; transition: all 0.2s; }
        .add-pts-btn:hover { background: var(--gold); color: #1a0a2e; }
    </style>
    <link rel="stylesheet" href="assets/schema.css">
</head>
<body>
<nav>
    <span class="nav-brand">🖥️ CCS Admin Panel</span>
    <div class="nav-links">
        <a href="admin.php">Dashboard</a>
        <a href="#" onclick="openModal('searchModal')">Search</a>
        <a href="admin_students.php">Students</a>
        <div class="nav-dropdown">
            <div class="nav-drop-toggle">Sit-in</div>
            <div class="nav-drop-menu">
                <a href="admin_sitin.php">📋 Sit-in</a>
                <a href="admin_sitin_records.php">📊 View Sit-in Records</a>
                <a href="admin_generate_reports.php">📥 Generate Reports</a>
            </div>
        </div>
        <a href="admin_leaderboard.php" class="active">🏆 Leaderboard</a>
        <a href="admin_feedback.php">Feedback Reports</a>
        <a href="admin_reservation.php">Reservation</a>
        <a href="admin.php?logout=1" class="logout-btn">Log out</a>
    </div>
</nav>

<!-- Search Modal -->
<div class="modal-overlay" id="searchModal" style="display:none">
    <div class="modal-box">
        <div class="modal-header"><span>🔍 Search Student</span><button class="modal-close" onclick="closeModal('searchModal')">✕</button></div>
        <div class="modal-body">
            <input type="text" id="searchInput" class="modal-input" placeholder="Name or ID number...">
            <div id="searchResults" class="search-results"></div>
        </div>
        <div class="modal-footer"><button class="btn-primary" onclick="searchStudent()">Search</button></div>
    </div>
</div>

<!-- Add Points Modal -->
<div class="modal-overlay" id="addPtsModal" style="display:none">
    <div class="modal-box" style="max-width:400px">
        <div class="modal-header"><span>⭐ Add Points</span><button class="modal-close" onclick="closeModal('addPtsModal')">✕</button></div>
        <form method="POST">
            <div class="modal-body">
                <div class="form-group">
                    <label>Student</label>
                    <select name="student_id" id="pts_student_id" class="modal-input" required>
                        <option value="">Select Student</option>
                        <?php foreach ($all_students as $s): ?>
                        <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['id_number'] . ' — ' . $s['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Points to Add</label>
                    <input type="number" name="points" class="modal-input" min="0.01" step="0.01" placeholder="e.g. 1.00" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeModal('addPtsModal')">Cancel</button>
                <button type="submit" name="add_points" class="btn-primary">Add Points</button>
            </div>
        </form>
    </div>
</div>

<main>
    <!-- HERO -->
    <div class="lb-hero">
        <div class="lb-hero-label">Hall of Fame</div>
        <h1 class="lb-hero-title">Top Students.</h1>
        <p class="lb-hero-sub">Rankings are calculated using a composite score based on rewards, sit-in hours, and tasks completed.</p>
    </div>

    <!-- TOP 3 PODIUM -->
    <?php if (count($top10) >= 1): ?>
    <div class="podium-wrap">
        <?php
        // Display order: 2nd, 1st, 3rd
        $podium_order = [];
        if (isset($top10[1])) $podium_order[] = ['data' => $top10[1], 'rank' => 2];
        if (isset($top10[0])) $podium_order[] = ['data' => $top10[0], 'rank' => 1];
        if (isset($top10[2])) $podium_order[] = ['data' => $top10[2], 'rank' => 3];

        $crowns = [1 => '👑', 2 => '🥈', 3 => '🥉'];
        $rank_labels = [1 => '🥇 Rank #1 · Champion', 2 => '🥈 Rank #2', 3 => '🥉 Rank #3'];

        foreach ($podium_order as $p):
            $s = $p['data']; $rank = $p['rank'];
            $photo_url = ($s['photo'] && file_exists("assets/uploads/".$s['photo']))
                ? "assets/uploads/".htmlspecialchars($s['photo']) : null;
        ?>
        <div class="podium-card rank-<?= $rank ?>">
            <div class="podium-crown"><?= $crowns[$rank] ?></div>
            <div class="podium-rank-badge"><?= $rank_labels[$rank] ?></div>
            <?php if ($photo_url): ?>
                <img src="<?= $photo_url ?>" class="podium-avatar" alt="">
            <?php else: ?>
                <div class="podium-avatar-placeholder">👤</div>
            <?php endif; ?>
            <div class="podium-name"><?= htmlspecialchars($s['name']) ?></div>
            <div class="podium-course"><?= htmlspecialchars($s['course']) ?></div>
            <div class="podium-score"><?= number_format($s['score'], 1) ?></div>
            <div class="podium-score-label">Composite Score</div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- RANKS 4–10 TABLE -->
    <?php $rest = array_slice($top10, 3); if (count($rest)): ?>
    <div class="lb-table-section">
        <div class="lb-table-title">Ranks 4 – 10</div>
        <div class="lb-add-btn-row">
            <button class="btn-sm" onclick="openModal('addPtsModal')">➕ Add Points</button>
        </div>
        <div class="card">
            <div class="lb-table-wrap">
                <table class="lb-table">
                    <thead>
                        <tr>
                            <th>Rank</th>
                            <th>Name</th>
                            <th>Course</th>
                            <th>⭐ Points</th>
                            <th>⏱ Hours</th>
                            <th>✅ Tasks</th>
                            <th>Score</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($rest as $i => $s): $rank = $i + 4; ?>
                    <tr>
                        <td><span class="rank-num">#<?= $rank ?></span></td>
                        <td><strong><?= htmlspecialchars($s['name']) ?></strong></td>
                        <td><?= htmlspecialchars($s['course']) ?></td>
                        <td><span class="pts-badge">⭐ <?= number_format($s['points'], 2) ?></span></td>
                        <td><span class="hrs-badge">⏱ <?= $s['hours_h'] ?>h <?= $s['hours_m'] ?>m</span></td>
                        <td><span class="tsk-badge">✅ <?= $s['tasks_completed'] ?></span></td>
                        <td><span class="score-badge"><?= number_format($s['score'], 1) ?></span></td>
                        <td><button class="add-pts-btn" onclick="openAddPts(<?= $s['id'] ?>)">+ Points</button></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Add Points button for top 3 (no table shown) -->
    <?php if (count($rest) === 0): ?>
    <div style="text-align:center; margin-bottom:2rem;">
        <button class="btn-primary" onclick="openModal('addPtsModal')">➕ Add Points</button>
    </div>
    <?php endif; ?>
</main>

<footer>&copy; 2026 College of Computer Studies</footer>
<script>
function openModal(id)  { document.getElementById(id).style.display = 'flex'; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }
function openAddPts(studentId) {
    document.getElementById('pts_student_id').value = studentId;
    openModal('addPtsModal');
}
function searchStudent() {
    const q = document.getElementById('searchInput').value.trim(); if (!q) return;
    fetch('admin_search.php?q=' + encodeURIComponent(q)).then(r => r.text()).then(html => { document.getElementById('searchResults').innerHTML = html; });
}
document.getElementById('searchInput')?.addEventListener('keydown', e => { if (e.key === 'Enter') searchStudent(); });
</script>
</body>
</html>