<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php"); exit();
}
require_once 'config.php';

$records = $conn->query("
    SELECT s.id, st.id_number, CONCAT(st.first_name,' ',st.last_name) as name,
           s.purpose, s.lab, COALESCE(st.sessions,30) as sessions,
           s.login_time, s.logout_time, s.status
    FROM sit_in_sessions s
    JOIN students st ON s.student_id = st.id
    ORDER BY s.login_time DESC
")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sit-in Records – CCS Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
    <nav>
        <span class="nav-brand">College of Computer Studies Admin</span>
        <div class="nav-links">
            <a href="admin.php">Home</a>
            <a href="#" onclick="openModal('searchModal')">Search</a>
            <a href="admin_students.php">Students</a>
            <a href="admin_sitin.php">Sit-in</a>
            <a href="admin_sitin_records.php" class="active">View Sit-in Records</a>
        </div>
        <a href="admin.php?logout=1" class="logout-btn">Log out</a>
    </nav>

    <!-- SEARCH MODAL -->
    <div class="modal-overlay" id="searchModal" style="display:none">
        <div class="modal-box">
            <div class="modal-header">
                <span>Search Student</span>
                <button class="modal-close" onclick="closeModal('searchModal')">✕</button>
            </div>
            <div class="modal-body">
                <input type="text" id="searchInput" class="modal-input" placeholder="Search...">
                <div id="searchResults" class="search-results"></div>
            </div>
            <div class="modal-footer">
                <button class="btn-primary" onclick="searchStudent()">Search</button>
            </div>
        </div>
    </div>

    <main>
        <div class="page-title">Sit-in Records</div>
        <div class="table-toolbar">
            <div></div>
            <input type="text" id="tableSearch" class="table-search" placeholder="Search..." oninput="filterTable()">
        </div>
        <div class="card">
            <div class="table-wrap">
                <table id="recordsTable">
                    <thead>
                        <tr>
                            <th>Sit ID</th>
                            <th>ID Number</th>
                            <th>Name</th>
                            <th>Purpose</th>
                            <th>Lab</th>
                            <th>Login Time</th>
                            <th>Logout Time</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($records)): ?>
                            <tr><td colspan="8" class="no-data">No records yet.</td></tr>
                        <?php else: ?>
                            <?php foreach ($records as $r): ?>
                            <tr>
                                <td><?= $r['id'] ?></td>
                                <td><?= htmlspecialchars($r['id_number']) ?></td>
                                <td><?= htmlspecialchars($r['name']) ?></td>
                                <td><?= htmlspecialchars($r['purpose']) ?></td>
                                <td><?= htmlspecialchars($r['lab']) ?></td>
                                <td><?= $r['login_time'] ?></td>
                                <td><?= $r['logout_time'] ?? '—' ?></td>
                                <td><span class="<?= $r['status'] === 'Active' ? 'badge-active' : 'badge-done' ?>"><?= $r['status'] ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <footer>&copy; 2026 College of Computer Studies</footer>

    <script>
        function openModal(id)  { document.getElementById(id).style.display = 'flex'; }
        function closeModal(id) { document.getElementById(id).style.display = 'none'; }
        function filterTable() {
            const q = document.getElementById('tableSearch').value.toLowerCase();
            document.querySelectorAll('#recordsTable tbody tr').forEach(row => {
                row.style.display = row.innerText.toLowerCase().includes(q) ? '' : 'none';
            });
        }
        function searchStudent() {
            const q = document.getElementById('searchInput').value.trim();
            if (!q) return;
            fetch('admin_search.php?q=' + encodeURIComponent(q))
                .then(r => r.text())
                .then(html => { document.getElementById('searchResults').innerHTML = html; });
        }
    </script>
</body>
</html>