<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php"); exit();
}
require_once 'config.php';

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM sit_in_sessions WHERE id = $id");
    header("Location: admin_sitin_records.php"); exit();
}

$filter_status = $_GET['status'] ?? '';
$filter_date   = $_GET['date'] ?? '';
$where = "WHERE 1=1";
if ($filter_status) $where .= " AND s.status = '" . $conn->real_escape_string($filter_status) . "'";
if ($filter_date)   $where .= " AND DATE(s.login_time) = '" . $conn->real_escape_string($filter_date) . "'";

$records = $conn->query("
    SELECT s.id, st.id_number, CONCAT(st.first_name,' ',st.last_name) as name,
           st.course, s.purpose, s.lab, s.login_time, s.logout_time, s.status
    FROM sit_in_sessions s
    JOIN students st ON s.student_id = st.id
    $where
    ORDER BY s.login_time DESC
")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sit-in Records – CCS Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/admin.css">
    <link rel="stylesheet" href="assets/schema.css">
</head>
<body>
<nav>
    <span class="nav-brand">🖥️ CCS Admin Panel</span>
    <div class="nav-links">
        <a href="admin.php">Dashboard</a>
        <a href="#" onclick="openModal('searchModal')">Search</a>
        <a href="admin_students.php">Students</a>
        
        <!-- Sit-in Dropdown -->
        <div class="nav-dropdown">
            <div class="nav-drop-toggle active">Sit-in</div>
            <div class="nav-drop-menu">
                <a href="admin_sitin.php">📋 Sit-in</a>
                <a href="admin_sitin_records.php" class="active">📊 View Sit-in Records</a>
                <a href="admin_generate_reports.php">📥 Generate Reports</a>
            </div>
        </div>
        
        <a href="admin_feedback.php">Feedback Reports</a>
        <a href="admin_reservation.php">Reservation</a>
        <a href="admin.php?logout=1" class="logout-btn">Log out</a>
    </div>
</nav>

<div class="modal-overlay" id="searchModal" style="display:none">
    <div class="modal-box">
        <div class="modal-header"><span>🔍 Search Student</span><button class="modal-close" onclick="closeModal('searchModal')">✕</button></div>
        <div class="modal-body">
            <input type="text" id="searchInput" class="modal-input" placeholder="Name or ID number...">
            <div id="searchResults" class="search-results"></div>
        </div>
        <div class="modal-footer"><button class="btn-primary" onclick="searchStudent()">Search</button></div>
    </div>
</div>

<main>
    <div class="page-title">Sit-in Records</div>
    <form method="GET" class="filter-bar">
        <div style="display:flex; gap:0.75rem; align-items:center; flex-wrap:wrap">
            <select name="status" class="table-search" style="width:auto">
                <option value="">All Status</option>
                <option value="Active" <?= $filter_status==='Active'?'selected':'' ?>>Active</option>
                <option value="Done" <?= $filter_status==='Done'?'selected':'' ?>>Done</option>
            </select>
            <input type="date" name="date" class="table-search" style="width:auto" value="<?= htmlspecialchars($filter_date) ?>">
            <button type="submit" class="btn-primary">Filter</button>
            <a href="admin_sitin_records.php" class="btn-secondary">Clear</a>
        </div>
        <input type="text" id="tableSearch" class="table-search" placeholder="Search records..." oninput="filterTable()">
    </form>
    <div class="card">
        <div class="card-header">📋 All Sit-in Records (<?= count($records) ?>)</div>
        <div class="table-wrap">
            <table id="recordsTable">
                <thead>
                    <tr><th>#</th><th>ID Number</th><th>Name</th><th>Course</th><th>Purpose</th><th>Lab</th><th>Login</th><th>Logout</th><th>Duration</th><th>Status</th><th>Action</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($records)): ?>
                    <tr><td colspan="11" class="no-data">No records found.</td></tr>
                    <?php else: foreach ($records as $r): ?>
                    <tr>
                        <td><?= $r['id'] ?></td>
                        <td><?= htmlspecialchars($r['id_number']) ?></td>
                        <td><?= htmlspecialchars($r['name']) ?></td>
                        <td><?= htmlspecialchars($r['course']) ?></td>
                        <td><?= htmlspecialchars($r['purpose']) ?></td>
                        <td><?= htmlspecialchars($r['lab']) ?></td>
                        <td><?= date('M d, h:i A', strtotime($r['login_time'])) ?></td>
                        <td><?= $r['logout_time'] ? date('M d, h:i A', strtotime($r['logout_time'])) : '—' ?></td>
                        <td><?php
                            if ($r['logout_time']) {
                                $diff = strtotime($r['logout_time']) - strtotime($r['login_time']);
                                $h = floor($diff/3600); $m = floor(($diff%3600)/60);
                                echo ($h > 0 ? $h.'h ' : '') . $m.'m';
                            } else { echo '<span style="color:var(--accent);font-weight:700">Active</span>'; }
                        ?></td>
                        <td><span class="<?= $r['status']==='Active'?'badge-active':'badge-done' ?>"><?= $r['status'] ?></span></td>
                        <td><a href="?delete=<?= $r['id'] ?>&status=<?= urlencode($filter_status) ?>&date=<?= urlencode($filter_date) ?>" class="btn-del" onclick="return confirm('Delete this record?')">Delete</a></td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
<footer>&copy; 2026 College of Computer Studies</footer>
<script>
function openModal(id)  { document.getElementById(id).style.display = 'flex'; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }
function filterTable() {
    const q = document.getElementById('tableSearch').value.toLowerCase();
    document.querySelectorAll('#recordsTable tbody tr').forEach(row => {
        row.style.display = row.innerText.toLowerCase().includes(q) ? '' : 'none';
    });
}
function searchStudent() {
    const q = document.getElementById('searchInput').value.trim(); if (!q) return;
    fetch('admin_search.php?q=' + encodeURIComponent(q)).then(r => r.text()).then(html => { document.getElementById('searchResults').innerHTML = html; });
}
document.getElementById('searchInput')?.addEventListener('keydown', e => { if (e.key === 'Enter') searchStudent(); });
</script>
</body>
</html>