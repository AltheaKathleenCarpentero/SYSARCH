# CCS Sit-in Monitoring System
## Setup Instructions for XAMPP

### 1. Install XAMPP
Download and install XAMPP from https://www.apachefriends.org/

### 2. Copy Project Files
Copy the entire `ccs_sitin` folder to:
- **Windows**: `C:\xampp\htdocs\ccs_sitin\`
- **Mac/Linux**: `/opt/lampp/htdocs/ccs_sitin/`

### 3. Set Up the Database
1. Open XAMPP Control Panel and start **Apache** and **MySQL**
2. Open your browser and go to: `http://localhost/phpmyadmin`
3. Click **"New"** on the left sidebar to create a new database
4. Name it `ccs_sitin` and click **Create**
5. Click the **SQL** tab, paste the contents of `database.sql`, and click **Go**

   OR simply import `database.sql` via the **Import** tab.

### 4. Run the Application
Open your browser and visit:
```
http://localhost/ccs_sitin/
```

### 5. (Optional) Add the CCS Logo
- Create a folder: `ccs_sitin/assets/`
- Place the CCS logo image as: `ccs_sitin/assets/ccs_logo.png`
- The login page will automatically display it

### File Structure
```
ccs_sitin/
├── index.php       ← Login page
├── register.php    ← Registration page
├── dashboard.php   ← Student dashboard (after login)
├── config.php      ← Database connection
├── database.sql    ← SQL to set up the database
├── assets/
│   └── ccs_logo.png  (add manually)
└── README.md
```

### Default DB Config (config.php)
- Host: localhost
- User: root
- Password: (empty)
- Database: ccs_sitin

Change these in `config.php` if your XAMPP MySQL has a password.
