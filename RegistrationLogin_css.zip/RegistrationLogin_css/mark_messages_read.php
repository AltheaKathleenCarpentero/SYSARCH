<?php
session_start();
if (!isset($_SESSION['student_id'])) exit();
require_once 'config.php';
$sid = $_SESSION['student_id'];
$conn->query("UPDATE messages SET is_read=1 WHERE student_id=$sid AND sender='admin'");
echo "ok";  