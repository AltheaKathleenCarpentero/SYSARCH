<?php
session_start();
require_once 'config.php';

// Redirect if already logged in
if (isset($_SESSION['student_id'])) { header("Location: dashboard.php"); exit(); }
if (isset($_SESSION['admin_id']))   { header("Location: admin.php"); exit(); }

$error = '';

// Hardcoded admin credentials
define('ADMIN_USERNAME', '21515010');
define('ADMIN_PASSWORD', 'admin123');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_number = trim($_POST['id_number']);
    $password  = $_POST['password'];

    if (empty($id_number) || empty($password)) {
        $error = 'Please fill in all fields.';
    } else {

        // --- Check admin first ---
        if ($id_number === ADMIN_USERNAME && $password === ADMIN_PASSWORD) {
            $_SESSION['admin_id']   = 1;
            $_SESSION['admin_name'] = 'Administrator';
            $_SESSION['role']       = 'admin';
            header("Location: admin.php");
            exit();

        } else {
            // --- Check students ---
            $stmt = $conn->prepare("SELECT * FROM students WHERE id_number = ?");
            $stmt->bind_param("s", $id_number);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 1) {
                $student = $result->fetch_assoc();
                if (password_verify($password, $student['password'])) {
                    $_SESSION['student_id']   = $student['id'];
                    $_SESSION['student_name'] = $student['first_name'] . ' ' . $student['last_name'];
                    $_SESSION['id_number']    = $student['id_number'];
                    $_SESSION['role']         = 'student';
                    header("Location: dashboard.php");
                    exit();
                } else {
                    $error = 'Invalid ID number or password.';
                }
            } else {
                $error = 'Invalid ID number or password.';
            }
            $stmt->close();
        }
    }
}