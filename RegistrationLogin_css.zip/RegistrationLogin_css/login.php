<?php
session_start();
require_once 'config.php';

// Redirect if already logged in
if (isset($_SESSION['student_id'])) { header("Location: dashboard.php"); exit(); }
if (isset($_SESSION['admin_id']))   { header("Location: admin_dashboard.php"); exit(); }

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_number = trim($_POST['id_number']);
    $password  = $_POST['password'];

    if (empty($id_number) || empty($password)) {
        $error = 'Please fill in all fields.';
    } else {

        // --- Check admins first ---
        $stmt = $conn->prepare("SELECT * FROM admins WHERE username = ?");
        $stmt->bind_param("s", $id_number);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $admin = $result->fetch_assoc();
            if (password_verify($password, $admin['password'])) {
                $_SESSION['admin_id']   = $admin['id'];
                $_SESSION['admin_name'] = $admin['full_name'];
                $_SESSION['role']       = 'admin';
                header("Location: admin.php");
                exit();
            } else {
                $error = 'Invalid credentials.';
            }
        } else {
            // --- Check students ---
            $stmt = $conn->prepare("SELECT * FROM students WHERE id_number = ?");
            $stmt->bind_param("s", $id_number);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 1) {
                $student = $result->fetch_assoc();
                if (password_verify($password, $student['password'])) {
                    $_SESSION['student_id']   = $student['id'];
                    $_SESSION['student_name'] = $student['first_name'] . ' ' . $student['last_name'];
                    $_SESSION['id_number']    = $student['id_number'];
                    $_SESSION['role']         = 'student';
                    header("Location: dashboard.php");
                    exit();
                } else {
                    $error = 'Invalid ID number or password.';
                }
            } else {
                $error = 'Invalid ID number or password.';
            }
            $stmt->close();
        }
    }
}