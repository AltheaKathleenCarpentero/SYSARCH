<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') exit();
require_once 'config.php';

$q    = trim($_GET['q'] ?? '');
$json = isset($_GET['json']);

if (empty($q)) { 
    echo $json ? 'null' : '<div class="no-data">Enter an ID number or name to search.</div>'; 
    exit(); 
}

$like = '%' . $q . '%';
$stmt = $conn->prepare("SELECT * FROM students WHERE id_number LIKE ? OR first_name LIKE ? OR last_name LIKE ? LIMIT 5");
$stmt->bind_param("sss", $like, $like, $like);
$stmt->execute();
$results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

if ($json) {
    echo json_encode($results[0] ?? null);
    exit();
}

if (empty($results)) {
    echo '<div class="no-data">❌ No students found matching "' . htmlspecialchars($q) . '"</div>';
} else {
    $student = $results[0];
    
    ?>
<div class="search-result-card">
    <div style="text-align: center; margin-bottom: 1rem;">
        <div style="width: 80px; height: 80px; background: linear-gradient(135deg, var(--violet-light), var(--violet-mid)); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto; border: 2px solid var(--gold);">
            <span style="font-size: 2.5rem;">👤</span>
        </div>
    </div>
    
    <div class="search-detail-row">
        <span class="search-detail-label">ID Number:</span>
        <span class="search-detail-value"><?= htmlspecialchars($student['id_number']) ?></span>
    </div>
    
    <div class="search-detail-row">
        <span class="search-detail-label">Full Name:</span>
        <span class="search-detail-value"><?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?></span>
    </div>
    
    <div class="search-detail-row">
        <span class="search-detail-label">Course:</span>
        <span class="search-detail-value"><?= htmlspecialchars($student['course'] ?? 'N/A') ?></span>
    </div>
    
    <div class="search-detail-row">
        <span class="search-detail-label">Year Level:</span>
        <span class="search-detail-value"><?= htmlspecialchars($student['course_level'] ?? 'N/A') ?></span>
    </div>
    
    <div class="search-detail-row">
        <span class="search-detail-label">Email:</span>
        <span class="search-detail-value"><?= htmlspecialchars($student['email'] ?? 'N/A') ?></span>
    </div>
    
    <div class="search-detail-row">
        <span class="search-detail-label">Remaining Sessions:</span>
        <span class="search-detail-value"><?= $student['sessions'] ?? 30 ?> / 30</span>
    </div>
</div>
        
        
        <?php if (isset($student['status'])): ?>
        <div class="search-detail-row">
            <span class="search-detail-label">Status:</span>
            <span class="search-detail-value">
                <span class="badge-<?= $student['status'] === 'Active' ? 'active' : 'done' ?>">
                    <?= htmlspecialchars($student['status']) ?>
                </span>
            </span>
        </div>
        <?php endif; ?>
    </div>
    
    <?php if (count($results) > 1): ?>
    <div class="more-results">
        <small>📋 Other matching students:</small>
        <?php for ($i = 1; $i < count($results); $i++): ?>
            <div class="search-result-item">
                <strong><?= htmlspecialchars($results[$i]['id_number']) ?></strong> — 
                <?= htmlspecialchars($results[$i]['first_name'] . ' ' . $results[$i]['last_name']) ?>
            </div>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
    <?php
}
?>