<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') { exit(); }
require_once 'config.php';

header('Content-Type: application/json');

$q = trim($_GET['q'] ?? '');
if (empty($q)) { echo json_encode(null); exit(); }

$stmt = $conn->prepare("SELECT id_number, first_name, middle_name, last_name, course, course_level, email, address, sessions FROM students WHERE id_number = ?");
$stmt->bind_param("s", $q);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();
$stmt->close();

echo json_encode($student ?: null);