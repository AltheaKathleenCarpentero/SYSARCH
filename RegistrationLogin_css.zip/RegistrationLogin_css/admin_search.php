<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') exit();
require_once 'config.php';

$q    = trim($_GET['q'] ?? '');
$json = isset($_GET['json']);

if (empty($q)) { echo $json ? 'null' : ''; exit(); }

$like = '%' . $q . '%';
$stmt = $conn->prepare("SELECT * FROM students WHERE id_number LIKE ? OR first_name LIKE ? OR last_name LIKE ? LIMIT 5");
$stmt->bind_param("sss", $like, $like, $like);
$stmt->execute();
$results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

if ($json) {
    echo json_encode($results[0] ?? null);
    exit();
}

if (empty($results)) {
    echo '<div class="no-data">No students found.</div>';
} else {
    foreach ($results as $s) {
        echo '<div class="search-result-item">';
        echo '<strong>' . htmlspecialchars($s['id_number']) . '</strong> — ';
        echo htmlspecialchars($s['first_name'] . ' ' . $s['last_name']);
        echo '</div>';
    }
}