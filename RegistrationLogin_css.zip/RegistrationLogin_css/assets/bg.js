(function () {
    const canvas = document.createElement('canvas');
    canvas.id = 'bg-canvas';
    canvas.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;z-index:-1;pointer-events:none;';
    document.body.prepend(canvas);

    const ctx = canvas.getContext('2d');
    const colors = ['#554226', '#03162D', '#002027', '#020210', '#02152A'];
    let t = 0;

    function resize() {
        canvas.width  = window.innerWidth;
        canvas.height = window.innerHeight;
    }

    function lerp(a, b, t) { return a + (b - a) * t; }

    function draw() {
        const w = canvas.width, h = canvas.height;
        ctx.clearRect(0, 0, w, h);

        // Base background
        const base = ctx.createLinearGradient(0, 0, w, h);
        base.addColorStop(0,   '#020210');
        base.addColorStop(0.4, '#02152A');
        base.addColorStop(1,   '#002027');
        ctx.fillStyle = base;
        ctx.fillRect(0, 0, w, h);

        // Animated blobs
        const blobs = [
            { x: 0.2 + 0.15 * Math.sin(t * 0.7),  y: 0.3 + 0.1  * Math.cos(t * 0.5),  r: 0.45, c: '#03162D' },
            { x: 0.7 + 0.1  * Math.cos(t * 0.6),  y: 0.6 + 0.12 * Math.sin(t * 0.8),  r: 0.4,  c: '#554226' },
            { x: 0.5 + 0.2  * Math.sin(t * 0.4),  y: 0.2 + 0.15 * Math.cos(t * 0.9),  r: 0.35, c: '#002027' },
            { x: 0.85 + 0.08 * Math.cos(t * 1.1), y: 0.15 + 0.1 * Math.sin(t * 0.6),  r: 0.3,  c: '#02152A' },
            { x: 0.1  + 0.1  * Math.sin(t * 0.9), y: 0.8 + 0.08 * Math.cos(t * 0.7),  r: 0.38, c: '#554226' },
        ];

        blobs.forEach(b => {
            const gx = b.x * w, gy = b.y * h, gr = b.r * Math.max(w, h);
            const g = ctx.createRadialGradient(gx, gy, 0, gx, gy, gr);
            g.addColorStop(0,   b.c + 'cc');
            g.addColorStop(0.5, b.c + '55');
            g.addColorStop(1,   'transparent');
            ctx.fillStyle = g;
            ctx.fillRect(0, 0, w, h);
        });

        // Wave overlay
        const waveY = h * 0.55 + 200 + Math.sin(t * 0.3) * 8 * 1.8;
        const wg = ctx.createLinearGradient(0, waveY - 100, 0, h);
        wg.addColorStop(0, 'rgba(2,2,16,0)');
        wg.addColorStop(1, 'rgba(2,2,16,0.6)');
        ctx.fillStyle = wg;
        ctx.fillRect(0, waveY - 100, w, h);

    }

    resize();
    window.addEventListener('resize', resize);
    draw();
})();