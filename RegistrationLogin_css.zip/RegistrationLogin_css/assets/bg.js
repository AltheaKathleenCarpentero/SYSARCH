(function () {
    const canvas = document.createElement('canvas');
    canvas.id = 'bg-canvas';
    canvas.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;z-index:-1;pointer-events:none;';
    document.body.prepend(canvas);

    const ctx = canvas.getContext('2d');
    let t = 0;

    function resize() {
        canvas.width  = window.innerWidth;
        canvas.height = window.innerHeight;
    }

    function draw() {
        const w = canvas.width, h = canvas.height;
        ctx.clearRect(0, 0, w, h);

        // Base dark violet background
        const base = ctx.createLinearGradient(0, 0, w, h);
        base.addColorStop(0,   '#0d0018');
        base.addColorStop(0.4, '#1a0035');
        base.addColorStop(1,   '#0a0020');
        ctx.fillStyle = base;
        ctx.fillRect(0, 0, w, h);

        // Animated blobs — dark violet + gold hints
        const blobs = [
            { x: 0.2 + 0.15 * Math.sin(t * 0.7),  y: 0.3 + 0.1  * Math.cos(t * 0.5),  r: 0.45, c: '#3b0070' },
            { x: 0.7 + 0.1  * Math.cos(t * 0.6),  y: 0.6 + 0.12 * Math.sin(t * 0.8),  r: 0.4,  c: '#b8860b' },
            { x: 0.5 + 0.2  * Math.sin(t * 0.4),  y: 0.2 + 0.15 * Math.cos(t * 0.9),  r: 0.35, c: '#4b0082' },
            { x: 0.85 + 0.08 * Math.cos(t * 1.1), y: 0.15 + 0.1 * Math.sin(t * 0.6),  r: 0.3,  c: '#d4a017' },
            { x: 0.1  + 0.1  * Math.sin(t * 0.9), y: 0.8 + 0.08 * Math.cos(t * 0.7),  r: 0.38, c: '#5c0099' },
            { x: 0.6  + 0.12 * Math.sin(t * 0.5), y: 0.85 + 0.1 * Math.cos(t * 0.4),  r: 0.32, c: '#9a7200' },
        ];

        blobs.forEach(b => {
            const gx = b.x * w, gy = b.y * h, gr = b.r * Math.max(w, h);
            const g = ctx.createRadialGradient(gx, gy, 0, gx, gy, gr);
            g.addColorStop(0,   b.c + 'bb');
            g.addColorStop(0.5, b.c + '44');
            g.addColorStop(1,   'transparent');
            ctx.fillStyle = g;
            ctx.fillRect(0, 0, w, h);
        });

        // Subtle gold shimmer overlay
        const shimmerX = w * (0.5 + 0.3 * Math.sin(t * 0.25));
        const sg = ctx.createRadialGradient(shimmerX, h * 0.5, 0, shimmerX, h * 0.5, w * 0.6);
        sg.addColorStop(0,   'rgba(212,160,23,0.06)');
        sg.addColorStop(0.5, 'rgba(184,134,11,0.03)');
        sg.addColorStop(1,   'transparent');
        ctx.fillStyle = sg;
        ctx.fillRect(0, 0, w, h);

        // Wave overlay darkening at bottom
        const waveY = h * 0.55 + 200 + Math.sin(t * 0.3) * 8 * 1.8;
        const wg = ctx.createLinearGradient(0, waveY - 100, 0, h);
        wg.addColorStop(0, 'rgba(10,0,32,0)');
        wg.addColorStop(1, 'rgba(10,0,32,0.65)');
        ctx.fillStyle = wg;
        ctx.fillRect(0, waveY - 100, w, h);

        t += 0.008;
        requestAnimationFrame(draw);
    }

    resize();
    window.addEventListener('resize', resize);
    draw();
})();