-- CCS Sit-in Monitoring System Database
CREATE DATABASE IF NOT EXISTS ccs_sitin;
USE ccs_sitin;

CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_number VARCHAR(20) UNIQUE NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    course_level INT DEFAULT 1,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    course VARCHAR(20) DEFAULT 'BSIT',
    address TEXT,
    photo VARCHAR(255) DEFAULT NULL,
    sessions INT DEFAULT 30,
    points DECIMAL(10,2) DEFAULT 0.00,
    total_points DECIMAL(10,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sit_in_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    purpose VARCHAR(100) NOT NULL,
    lab VARCHAR(50) NOT NULL,
    login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    logout_time DATETIME DEFAULT NULL,
    status ENUM('Active','Done') DEFAULT 'Active',
    bonus_awarded TINYINT(1) DEFAULT 0,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS reservations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    purpose VARCHAR(100) NOT NULL,
    lab VARCHAR(10) NOT NULL,
    reservation_date DATE NOT NULL,
    reservation_time TIME NOT NULL,
    duration INT DEFAULT 1,
    status ENUM('Pending', 'Approved', 'Cancelled', 'Completed') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS daily_bonus_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    bonus_date DATE NOT NULL,
    points_earned DECIMAL(5,2) NOT NULL,
    UNIQUE KEY unique_daily(student_id, bonus_date),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

ALTER TABLE students ADD COLUMN IF NOT EXISTS total_points DECIMAL(10,2) DEFAULT 0.00;
UPDATE students SET total_points = points;

ALTER TABLE students ADD COLUMN IF NOT EXISTS sitin_milestone INT DEFAULT 0;
ALTER TABLE students ADD COLUMN IF NOT EXISTS total_points DECIMAL(10,2) DEFAULT 0.00;
UPDATE students SET total_points = points WHERE total_points = 0;