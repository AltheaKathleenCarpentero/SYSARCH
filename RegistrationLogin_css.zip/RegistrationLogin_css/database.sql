-- CCS Sit-in Monitoring System Database
CREATE DATABASE IF NOT EXISTS ccs_sitin;
USE ccs_sitin;

CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_number VARCHAR(20) UNIQUE NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    course_level INT DEFAULT 1,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    course VARCHAR(20) DEFAULT 'BSIT',
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO admins (username, password, full_name)
VALUES ('admin', '$2y$10$RTYVWaIqjPz2Q7QRIzmzMehnqznKERn/C.P742djfCci.YiMOgmVy', 'System Admin');