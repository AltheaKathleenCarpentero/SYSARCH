<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php"); exit();
}
require_once 'config.php';
$sid = $_SESSION['student_id'];

// Composite leaderboard query
$raw = $conn->query("
    SELECT
        st.id, st.id_number,
        CONCAT(st.first_name,' ',st.last_name) AS name,
        st.course, st.photo,
        COALESCE(st.total_points, 0) AS points,
        COALESCE(SUM(TIMESTAMPDIFF(MINUTE, s.login_time, IFNULL(s.logout_time, NOW()))), 0) AS total_minutes,
        COUNT(CASE WHEN s.status='Done' THEN 1 END) AS tasks_completed
    FROM students st
    LEFT JOIN sit_in_sessions s ON s.student_id = st.id
    GROUP BY st.id
")->fetch_all(MYSQLI_ASSOC);

$max_pts = max(1, max(array_column($raw, 'points')));
$max_min = max(1, max(array_column($raw, 'total_minutes')));
$max_tsk = max(1, max(array_column($raw, 'tasks_completed')));

foreach ($raw as &$r) {
    $r['score'] = round(
        ($r['points']/$max_pts)*60 +
        ($r['total_minutes']/$max_min)*20 +
        ($r['tasks_completed']/$max_tsk)*20, 2);
    $r['hours_h'] = floor($r['total_minutes']/60);
    $r['hours_m'] = $r['total_minutes'] % 60;
}
unset($r);
usort($raw, fn($a,$b) => $b['score'] <=> $a['score']);
$top10 = array_slice($raw, 0, 10);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Leaderboard – CCS</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800;900&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/dashboard.css">
    <style>
        /* ── PODIUM ── */
        .lb-hero {
            text-align: center;
            padding: 2.5rem 1rem 1rem;
        }
        .lb-hero-label {
            font-size: 0.72rem; font-weight: 800; letter-spacing: 0.18em;
            color: var(--gold, #d4a017); text-transform: uppercase;
            border: 1px solid rgba(212,160,23,0.35);
            display: inline-block; padding: 0.3rem 1rem; border-radius: 20px;
            margin-bottom: 0.7rem;
        }
        .lb-hero-title {
            font-family: 'Playfair Display', serif;
            font-size: clamp(2rem, 5vw, 3rem);
            font-weight: 700; color: var(--text, #f0e6ff);
            margin-bottom: 0.4rem;
        }
        .lb-hero-sub {
            font-size: 0.84rem; color: var(--text-muted, #c8a8e8);
            max-width: 480px; margin: 0 auto 1.5rem; line-height: 1.6;
        }
        .lb-formula {
            display: inline-flex; gap: 0.5rem; flex-wrap: wrap;
            justify-content: center; margin-bottom: 2rem;
        }
        .lb-formula-chip {
            padding: 0.35rem 0.9rem; border-radius: 20px; font-size: 0.78rem;
            font-weight: 800; border: 1.5px solid;
        }
        .chip-pts { background: rgba(212,160,23,0.12); color: #d4a017; border-color: rgba(212,160,23,0.4); }
        .chip-hrs { background: rgba(74,174,217,0.12); color: #4aaed9;  border-color: rgba(74,174,217,0.4); }
        .chip-tsk { background: rgba(94,211,119,0.12); color: #5ed377;  border-color: rgba(94,211,119,0.4); }

        .podium-wrap {
            display: flex; justify-content: center; align-items: flex-end;
            gap: 1.2rem; padding: 0 1rem 2.5rem; flex-wrap: wrap;
        }
        .podium-card {
            background: #ffffff;
            border: 1px solid var(--line, #ded6ea);
            border-radius: 8px; padding: 1.5rem 1.2rem 1.2rem;
            text-align: center; backdrop-filter: none;
            position: relative; transition: transform 0.2s, box-shadow 0.2s; width: 200px;
            box-shadow: 0 14px 34px rgba(61,31,111,0.10);
        }
        .podium-card:hover { transform: translateY(-4px); }
        .podium-card.rank-1 { border-color: var(--brand-line, #d9c9f3); box-shadow: 0 18px 42px rgba(61,31,111,0.14); width: 230px; padding-top: 2rem; }
        .podium-card.rank-2 { border-color: var(--line, #ded6ea); }
        .podium-card.rank-3 { border-color: var(--line, #ded6ea); }

        .podium-crown { font-size: 2rem; line-height: 1; position: absolute; top: -1.1rem; left: 50%; transform: translateX(-50%); filter: drop-shadow(0 4px 10px rgba(61,31,111,0.18)); }
        .podium-rank-badge { font-size: 0.65rem; font-weight: 900; letter-spacing: 0.12em; text-transform: uppercase; padding: 0.2rem 0.6rem; border-radius: 10px; display: inline-block; margin-bottom: 0.8rem; }
        .rank-1 .podium-rank-badge { background: var(--brand-soft, #eee7fb); color: var(--brand-strong, #3b1f6f); border: 1px solid var(--brand-line, #d9c9f3); }
        .rank-2 .podium-rank-badge { background: #f8fafc; color: #64748b; border: 1px solid #d8dee8; }
        .rank-3 .podium-rank-badge { background: #fff7ed; color: #9a5b21; border: 1px solid #f1d0ae; }

        .podium-avatar { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; margin: 0 auto 0.75rem; display: block; border: 3px solid; }
        .podium-avatar-placeholder { width: 80px; height: 80px; border-radius: 50%; margin: 0 auto 0.75rem; display: flex; align-items: center; justify-content: center; font-size: 2rem; background: var(--brand-soft, #eee7fb); border: 3px solid; color: var(--brand, #6d4bb3); }
        .rank-1 .podium-avatar, .rank-1 .podium-avatar-placeholder { border-color: var(--brand, #6d4bb3); width:96px; height:96px; }
        .rank-2 .podium-avatar, .rank-2 .podium-avatar-placeholder { border-color: #cbd5e1; }
        .rank-3 .podium-avatar, .rank-3 .podium-avatar-placeholder { border-color: #d6a56f; }

        .podium-name  { font-size: 1rem; font-weight: 900; color: var(--ink,#20192e); margin-bottom: 0.15rem; }
        .rank-1 .podium-name { font-size: 1.1rem; }
        .podium-course { font-size: 0.72rem; color: var(--ink-muted,#756985); font-weight: 600; margin-bottom: 0.8rem; }
        .podium-score  { font-size: 1.5rem; font-weight: 900; line-height: 1; margin-bottom: 0.15rem; }
        .rank-1 .podium-score { color: var(--brand, #6d4bb3); font-size: 1.8rem; }
        .rank-2 .podium-score { color: #64748b; }
        .rank-3 .podium-score { color: #b46a2a; }
        .podium-score-label { font-size: 0.68rem; color: var(--ink-muted,#756985); font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 0.75rem; }
        .podium-stats { display: flex; gap: 0.4rem; justify-content: center; flex-wrap: wrap; }
        .podium-stat  { font-size: 0.68rem; font-weight: 800; padding: 0.2rem 0.5rem; border-radius: 8px; }
        .pstat-pts { background: rgba(212,160,23,0.15); color: #d4a017; }
        .pstat-hrs { background: rgba(74,174,217,0.15); color: #4aaed9; }
        .pstat-tsk { background: rgba(94,211,119,0.15); color: #5ed377; }
        .you-glow  { box-shadow: 0 0 0 3px rgba(109,75,179,0.18), 0 18px 42px rgba(61,31,111,0.16) !important; }

        /* ── TABLE ── */
        .lb-table-section { max-width: 860px; margin: 0 auto 3rem; padding: 0 1.5rem; }
        .lb-table-title { font-size: 0.75rem; font-weight: 800; letter-spacing: 0.14em; text-transform: uppercase; color: #d4a017; margin-bottom: 0.8rem; padding-left: 0.25rem; }
        .lb-table-wrap  { overflow-x: auto; }
        .lb-table { width: 100%; border-collapse: collapse; font-size: 0.88rem; }
        .lb-table thead th { padding: 0.7rem 1rem; text-align: left; font-size: 0.7rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.08em; color: var(--text-muted,#c8a8e8); border-bottom: 1px solid rgba(212,160,23,0.2); }
        .lb-table tbody tr { border-bottom: 1px solid rgba(212,160,23,0.07); transition: background 0.15s; }
        .lb-table tbody tr:hover { background: rgba(212,160,23,0.05); }
        .lb-table tbody tr.you-row { background: rgba(212,160,23,0.08); }
        .lb-table td { padding: 0.75rem 1rem; color: var(--text,#f0e6ff); vertical-align: middle; }
        .rank-num    { font-weight: 900; color: var(--text-muted,#c8a8e8); font-size: 1rem; }
        .score-badge { background: linear-gradient(135deg, rgba(212,160,23,0.2), rgba(212,160,23,0.08)); color: #f0c040; padding: 0.2rem 0.7rem; border-radius: 12px; font-weight: 900; font-size: 0.82rem; border: 1px solid rgba(212,160,23,0.3); }
        .pts-badge   { background: rgba(212,160,23,0.12); color: #d4a017; padding: 2px 8px; border-radius: 10px; font-weight: 800; font-size: 0.78rem; }
        .hrs-badge   { background: rgba(74,174,217,0.12); color: #4aaed9; padding: 2px 8px; border-radius: 10px; font-weight: 800; font-size: 0.78rem; }
        .tsk-badge   { background: rgba(94,211,119,0.12); color: #5ed377; padding: 2px 8px; border-radius: 10px; font-weight: 800; font-size: 0.78rem; }
        .you-tag     { font-size: 0.65rem; background: #d4a017; color: #1a0a2e; padding: 1px 6px; border-radius: 10px; margin-left: 6px; font-weight: 800; vertical-align: middle; }
    </style>
    <link rel="stylesheet" href="assets/schema.css">
</head>
<body>
<nav>
    <span class="nav-brand">🎓 CCS Sit-in Monitoring System</span>
    <div class="nav-links">
        <div class="nav-dropdown">
            <div class="nav-drop-toggle">Notifications</div>
            <div class="nav-drop-menu">
                <a href="student_notifications.php">Announcements</a>
                <a href="student_alerts.php">Alerts</a>
                <a href="student_messages.php">Messages</a>
            </div>
        </div>
        <a href="dashboard.php">Home</a>
        <a href="student_edit_profile.php">Edit Profile</a>
        <a href="student_history.php">History</a>
        <a href="student_leaderboard.php" class="active">🏆 Leaderboard</a>
        <a href="student_reservation.php">Reservation</a>
        <a href="dashboard.php?logout=1" class="logout-btn">Logout</a>
    </div>
</nav>

<main class="dashboard-main" style="max-width:960px; margin:0 auto; padding:0 1rem 2rem;">

    <!-- HERO -->
    <div class="lb-hero">
        <div class="lb-hero-label">Hall of Fame</div>
        <h1 class="lb-hero-title">Top Students.</h1>
        <p class="lb-hero-sub">Rankings are calculated using a composite score based on rewards, sit-in hours, and tasks completed.</p>
    </div>

    <!-- TOP 3 PODIUM -->
    <?php if (count($top10) >= 1):
        $podium_order = [];
        if (isset($top10[1])) $podium_order[] = ['data' => $top10[1], 'rank' => 2];
        if (isset($top10[0])) $podium_order[] = ['data' => $top10[0], 'rank' => 1];
        if (isset($top10[2])) $podium_order[] = ['data' => $top10[2], 'rank' => 3];
        $crowns      = [1=>'👑', 2=>'🥈', 3=>'🥉'];
        $rank_labels = [1=>'🥇 Rank #1 · Champion', 2=>'🥈 Rank #2', 3=>'🥉 Rank #3'];
    ?>
    <div class="podium-wrap">
        <?php foreach ($podium_order as $p):
            $s = $p['data']; $rank = $p['rank'];
            $photo_url = ($s['photo'] && file_exists("assets/uploads/".$s['photo']))
                ? "assets/uploads/".htmlspecialchars($s['photo']) : null;
            $is_you = ($s['id'] == $sid);
        ?>
        <div class="podium-card rank-<?= $rank ?><?= $is_you ? ' you-glow' : '' ?>">
            <div class="podium-crown"><?= $crowns[$rank] ?></div>
            <div class="podium-rank-badge"><?= $rank_labels[$rank] ?></div>
            <?php if ($photo_url): ?>
                <img src="<?= $photo_url ?>" class="podium-avatar" alt="">
            <?php else: ?>
                <div class="podium-avatar-placeholder">👤</div>
            <?php endif; ?>
            <div class="podium-name">
                <?= htmlspecialchars($s['name']) ?>
                <?php if ($is_you): ?><span class="you-tag">YOU</span><?php endif; ?>
            </div>
            <div class="podium-course"><?= htmlspecialchars($s['course']) ?></div>
            <div class="podium-score"><?= number_format($s['score'], 1) ?></div>
            <div class="podium-score-label">Composite Score</div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- RANKS 4–10 TABLE -->
    <?php $rest = array_slice($top10, 3); if (count($rest)): ?>
    <div class="lb-table-section">
        <div class="lb-table-title">Ranks 4 – 10</div>
        <div class="card">
            <div class="lb-table-wrap">
                <table class="lb-table">
                    <thead>
                        <tr>
                            <th>Rank</th>
                            <th>Name</th>
                            <th>Course</th>
                            <th>⭐ Points</th>
                            <th>⏱ Hours</th>
                            <th>✅ Tasks</th>
                            <th>Score</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($rest as $i => $s): $rank = $i + 4; ?>
                    <tr class="<?= $s['id']==$sid ? 'you-row' : '' ?>">
                        <td><span class="rank-num">#<?= $rank ?></span></td>
                        <td>
                            <strong><?= htmlspecialchars($s['name']) ?></strong>
                            <?php if ($s['id']==$sid): ?><span class="you-tag">YOU</span><?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($s['course']) ?></td>
                        <td><span class="pts-badge">⭐ <?= number_format($s['points'], 2) ?></span></td>
                        <td><span class="hrs-badge">⏱ <?= $s['hours_h'] ?>h <?= $s['hours_m'] ?>m</span></td>
                        <td><span class="tsk-badge">✅ <?= $s['tasks_completed'] ?></span></td>
                        <td><span class="score-badge"><?= number_format($s['score'], 1) ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

</main>

<footer>&copy; 2026 College of Computer Studies</footer>
</body>
</html>
