<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php"); exit();
}
require_once 'config.php';
$sid = $_SESSION['student_id'];

$by_points = $conn->query("
    SELECT id, id_number, CONCAT(first_name,' ',last_name) as name, course, points
    FROM students ORDER BY points DESC, last_name ASC
")->fetch_all(MYSQLI_ASSOC);

$by_hours = $conn->query("
    SELECT st.id, st.id_number, CONCAT(st.first_name,' ',st.last_name) as name, st.course,
           COALESCE(SUM(TIMESTAMPDIFF(MINUTE, s.login_time, s.logout_time)), 0) as total_minutes
    FROM students st
    LEFT JOIN sit_in_sessions s ON s.student_id = st.id AND s.status = 'Done'
    GROUP BY st.id ORDER BY total_minutes DESC, name ASC
")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Leaderboard – CCS</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/dashboard.css">
    <style>
        .lb-tabs { display:flex; gap:0.5rem; margin-bottom:1.5rem; }
        .lb-tab { padding:0.6rem 1.4rem; border-radius:8px; font-weight:700; font-size:0.85rem; cursor:pointer; border:2px solid rgba(212,160,23,0.3); color:var(--text-muted, #aaa); background:transparent; transition:all 0.2s; }
        .lb-tab.active { background:var(--gold, #d4a017); color:#1a0a2e; border-color:var(--gold, #d4a017); }
        .lb-panel { display:none; } .lb-panel.active { display:block; }
        .rank-1 td:first-child { color:#FFD700; font-size:1.3rem; }
        .rank-2 td:first-child { color:#C0C0C0; font-size:1.2rem; }
        .rank-3 td:first-child { color:#CD7F32; font-size:1.1rem; }
        .you-row { background: rgba(212,160,23,0.08) !important; }
        .pts-badge { background:linear-gradient(135deg,#d4a017,#a07010); color:#1a0a2e; padding:2px 10px; border-radius:20px; font-weight:800; font-size:0.85rem; }
        .hours-badge { background:rgba(74,174,217,0.15); color:#4aaed9; padding:2px 10px; border-radius:20px; font-weight:800; font-size:0.85rem; border:1px solid rgba(74,174,217,0.3); }
        .you-tag { font-size:0.7rem; background:#d4a017; color:#1a0a2e; padding:1px 6px; border-radius:10px; margin-left:6px; font-weight:800; }
    </style>
</head>
<body>
<nav>
    <span class="nav-brand">🎓 CCS Sit-in Monitoring System</span>
    <div class="nav-links">
        <div class="nav-dropdown">
            <div class="nav-drop-toggle">Notifications</div>
            <div class="nav-drop-menu">
                <a href="student_notifications.php">Announcements</a>
                <a href="student_alerts.php">Alerts</a>
                <a href="student_messages.php">Messages</a>
            </div>
        </div>
        <a href="dashboard.php">Home</a>
        <a href="student_edit_profile.php">Edit Profile</a>
        <a href="student_history.php">History</a>
        <a href="student_leaderboard.php" class="active">🏆 Leaderboard</a>
        <a href="student_reservation.php">Reservation</a>
        <a href="dashboard.php?logout=1" class="logout-btn">Logout</a>
    </div>
</nav>

<main class="dashboard-main" style="max-width:900px; margin:0 auto; padding:2rem 1rem;">
    <div style="font-size:1.8rem; font-weight:900; color:var(--gold,#d4a017); margin-bottom:1.5rem;">🏆 Leaderboard</div>

    <div class="lb-tabs">
        <button class="lb-tab active" onclick="switchTab('points')">⭐ By Points</button>
        <button class="lb-tab" onclick="switchTab('hours')">⏱ By Sit-in Hours</button>
    </div>

    <!-- BY POINTS -->
    <div class="lb-panel active" id="panel-points">
        <div class="card">
            <div class="card-header">⭐ Rankings by Points</div>
            <div class="table-wrapper">
                <table class="history-table">
                    <thead><tr><th>Rank</th><th>ID Number</th><th>Name</th><th>Course</th><th>Points</th></tr></thead>
                    <tbody>
                    <?php foreach ($by_points as $i => $s): ?>
                    <tr class="<?= $i===0?'rank-1':($i===1?'rank-2':($i===2?'rank-3':'')) ?> <?= $s['id']==$sid?'you-row':'' ?>">
                        <td><?= $i===0?'🥇':($i===1?'🥈':($i===2?'🥉':'#'.($i+1))) ?></td>
                        <td><?= htmlspecialchars($s['id_number']) ?></td>
                        <td><?= htmlspecialchars($s['name']) ?><?= $s['id']==$sid ? '<span class="you-tag">YOU</span>' : '' ?></td>
                        <td><?= htmlspecialchars($s['course']) ?></td>
                        <td><span class="pts-badge">⭐ <?= number_format($s['points'],2) ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- BY HOURS -->
    <div class="lb-panel" id="panel-hours">
        <div class="card">
            <div class="card-header">⏱ Rankings by Total Sit-in Hours</div>
            <div class="table-wrapper">
                <table class="history-table">
                    <thead><tr><th>Rank</th><th>ID Number</th><th>Name</th><th>Course</th><th>Total Hours</th></tr></thead>
                    <tbody>
                    <?php foreach ($by_hours as $i => $s):
                        $h = floor($s['total_minutes'] / 60);
                        $m = $s['total_minutes'] % 60;
                    ?>
                    <tr class="<?= $i===0?'rank-1':($i===1?'rank-2':($i===2?'rank-3':'')) ?> <?= $s['id']==$sid?'you-row':'' ?>">
                        <td><?= $i===0?'🥇':($i===1?'🥈':($i===2?'🥉':'#'.($i+1))) ?></td>
                        <td><?= htmlspecialchars($s['id_number']) ?></td>
                        <td><?= htmlspecialchars($s['name']) ?><?= $s['id']==$sid ? '<span class="you-tag">YOU</span>' : '' ?></td>
                        <td><?= htmlspecialchars($s['course']) ?></td>
                        <td><span class="hours-badge">⏱ <?= $h ?>h <?= $m ?>m</span></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<footer>&copy; 2026 College of Computer Studies</footer>
<script>
function switchTab(tab) {
    document.querySelectorAll('.lb-tab').forEach((t,i) => t.classList.toggle('active',(i===0&&tab==='points')||(i===1&&tab==='hours')));
    document.getElementById('panel-points').classList.toggle('active', tab==='points');
    document.getElementById('panel-hours').classList.toggle('active', tab==='hours');
}
</script>
</body>
</html>