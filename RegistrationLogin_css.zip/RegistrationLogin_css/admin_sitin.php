<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php"); exit();
}
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['do_timeout'])) {
    $session_id = intval($_POST['session_id']);
    $student_id = intval($_POST['student_id']);
    $is_clean = (isset($_POST['desk_clean']) && $_POST['desk_clean'] == '1') ? 1 : 0;

    $res = $conn->query("SELECT s.*, st.first_name FROM sit_in_sessions s JOIN students st ON st.id = s.student_id WHERE s.id = $session_id AND s.status = 'Active'");
    if ($res->num_rows > 0) {
        $session_row = $res->fetch_assoc();

        $conn->query("UPDATE sit_in_sessions SET logout_time = NOW(), status = 'Done' WHERE id = $session_id");
        $conn->query("UPDATE students SET sessions = GREATEST(0, sessions - 1) WHERE id = $student_id");

        // Award 1 point per 30 minutes of sit-in time
        $login_time = strtotime($session_row['login_time']);
        $logout_time = time();
        $minutes_spent = ($logout_time - $login_time) / 60;
        $time_points = floor($minutes_spent / 30); // 1 point every 30 mins
        if ($time_points > 0) {
            $conn->query("UPDATE students SET points = points + $time_points, total_points = total_points + $time_points WHERE id = $student_id");
        }

        if ($is_clean) {
            $conn->query("UPDATE students SET points = points + 1, total_points = total_points + 1 WHERE id = $student_id");
            $bal = $conn->query("SELECT points FROM students WHERE id = $student_id")->fetch_assoc();
            $pts = floatval($bal['points']);
            $sessions_to_add = floor($pts / 3);
            if ($sessions_to_add >= 1) {
                $deduct = $sessions_to_add * 3;
                $conn->query("UPDATE students SET points = points - $deduct, sessions = sessions + $sessions_to_add WHERE id = $student_id");
            }
        }

        // ✅ Auto-send message to student after timeout
        $lab = $session_row['lab'];
        $points_msg = $time_points > 0 ? " You earned $time_points point" . ($time_points > 1 ? "s" : "") . " for your time in the lab!" : "";
        $auto_msg = "Your sit-in session at " . $lab . " has ended. Thank you for using the CCS Computer Laboratory! We hope your session was productive." . $points_msg . " Please don't forget to leave your feedback — it helps us improve the lab experience for everyone.";
        $ins_msg = $conn->prepare("INSERT INTO messages (student_id, sender, subject, body) VALUES (?, 'admin', 'Your Sit-in Session Has Ended', ?)");
        $ins_msg->bind_param("is", $student_id, $auto_msg);
        $ins_msg->execute();
        $ins_msg->close();
    }
    header("Location: admin_sitin.php"); exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['manual_sitin'])) {
    $student_id = intval($_POST['student_id']);
    $purpose = trim($_POST['purpose']);
    $lab = trim($_POST['lab']);
    $check = $conn->query("SELECT id FROM sit_in_sessions WHERE student_id = $student_id AND status = 'Active'");
    if ($check->num_rows === 0 && !empty($purpose) && !empty($lab)) {
        $ins = $conn->prepare("INSERT INTO sit_in_sessions (student_id, purpose, lab) VALUES (?,?,?)");
        $ins->bind_param("iss", $student_id, $purpose, $lab);
        $ins->execute(); $ins->close();
    }
    header("Location: admin_sitin.php"); exit();
}

if (isset($_POST['reset_sessions'])) {
    $conn->query("UPDATE students SET sessions = 30");
    header("Location: admin_sitin.php"); exit();
}

$active   = $conn->query("SELECT s.id, st.id_number, CONCAT(st.first_name,' ',st.last_name) as name, s.purpose, s.lab, s.login_time, st.id as student_id FROM sit_in_sessions s JOIN students st ON s.student_id = st.id WHERE s.status = 'Active' ORDER BY s.login_time DESC")->fetch_all(MYSQLI_ASSOC);
$students = $conn->query("SELECT id, id_number, CONCAT(first_name,' ',last_name) as name FROM students ORDER BY last_name")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sit-in Management – CCS Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/admin.css">
    <link rel="stylesheet" href="assets/schema.css">
</head>
<body>
<nav>
    <span class="nav-brand">🖥️ CCS Admin Panel</span>
    <div class="nav-links">
        <a href="admin.php">Dashboard</a>
        <a href="#" onclick="openModal('searchModal')">Search</a>
        <a href="admin_students.php">Students</a>
        
        <!-- Sit-in Dropdown -->
        <div class="nav-dropdown">
            <div class="nav-drop-toggle active">Sit-in</div>
            <div class="nav-drop-menu">
                <a href="admin_sitin.php" class="active">📋 Sit-in</a>
                <a href="admin_sitin_records.php">📊 View Sit-in Records</a>
                <a href="admin_generate_reports.php">📥 Generate Reports</a>
            </div>
        </div>
        <a href="admin_leaderboard.php">🏆 Leaderboard</a>
        <a href="admin_feedback.php">Feedback Reports</a>
        <a href="admin_reservation.php">Reservation</a>
        <a href="admin.php?logout=1" class="logout-btn">Log out</a>
    </div>
</nav>

<div class="modal-overlay" id="searchModal" style="display:none">
    <div class="modal-box">
        <div class="modal-header"><span>🔍 Search Student</span><button class="modal-close" onclick="closeModal('searchModal')">✕</button></div>
        <div class="modal-body">
            <input type="text" id="searchInput" class="modal-input" placeholder="Name or ID number...">
            <div id="searchResults" class="search-results"></div>
        </div>
        <div class="modal-footer"><button class="btn-primary" onclick="searchStudent()">Search</button></div>
    </div>
</div>

<div class="modal-overlay" id="manualModal" style="display:none">
    <div class="modal-box">
        <div class="modal-header"><span>➕ Manual Sit-in</span><button class="modal-close" onclick="closeModal('manualModal')">✕</button></div>
        <form method="POST">
            <div class="modal-body">
                <div class="form-group"><label>Student</label>
                    <select name="student_id" class="modal-input" required>
                        <option value="">Select Student</option>
                        <?php foreach ($students as $s): ?>
                        <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['id_number'] . ' — ' . $s['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group"><label>Purpose</label>
                    <input type="text" name="purpose" class="modal-input" placeholder="e.g. Programming Practice" required>
                </div>
                <div class="form-group"><label>Laboratory</label>
                    <select name="lab" class="modal-input" required>
                        <option value="">Select Lab</option>
                        <option>Lab 517</option><option>Lab 518</option><option>Lab 519</option>
                        <option>Lab 524</option><option>Lab 526</option><option>Lab 528</option>
                        <option>Lab 530</option><option>Lab 542</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeModal('manualModal')">Cancel</button>
                <button type="submit" name="manual_sitin" class="btn-primary">Start Sit-in</button>
            </div>
        </form>
    </div>
</div>
<!-- Force Timeout Modal -->
<div class="modal-overlay" id="timeoutModal" style="display:none">
    <div class="modal-box" style="max-width:420px">
        <div class="modal-header">
            <span>🚪 Force Timeout</span>
            <button class="modal-close" onclick="closeModal('timeoutModal')">✕</button>
        </div>
        <form method="POST">
            <input type="hidden" name="session_id" id="to_session_id">
            <input type="hidden" name="student_id" id="to_student_id">
            <div class="modal-body">
                <div style="text-align:center; margin-bottom:1.2rem;">
                    <div style="font-size:1rem; color:var(--text-muted); margin-bottom:0.3rem;">Student</div>
                    <div style="font-size:1.2rem; font-weight:800; color:var(--gold)" id="to_name"></div>
                    <div style="font-size:0.85rem; color:var(--text-muted); margin-top:0.2rem;" id="to_lab"></div>
                </div>
                <div style="background:rgba(212,160,23,0.08); border:1px solid rgba(212,160,23,0.2); border-radius:10px; padding:1rem;">
                    <div style="font-weight:800; color:var(--gold); margin-bottom:0.75rem; font-size:0.85rem;">🪑 Desk Condition</div>
                    <label style="display:flex; align-items:center; gap:0.75rem; cursor:pointer; margin-bottom:0.5rem;">
                        <input type="radio" name="desk_clean" value="1" style="accent-color:var(--gold); width:16px; height:16px;">
                        <span style="color:#27ae60; font-weight:700;">✅ Clean — Award +1 point</span>
                    </label>
                    <label style="display:flex; align-items:center; gap:0.75rem; cursor:pointer;">
                        <input type="radio" name="desk_clean" value="0" checked style="accent-color:var(--gold); width:16px; height:16px;">
                        <span style="color:#e05252; font-weight:700;">❌ Not Clean — No points</span>
                    </label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeModal('timeoutModal')">Cancel</button>
                <button type="submit" name="do_timeout" class="btn-primary">Confirm Timeout</button>
            </div>
        </form>
    </div>
</div>
<main>
    <div class="page-title">Sit-in Management</div>
    <div class="table-toolbar">
        <div style="display:flex; gap:0.75rem; flex-wrap:wrap">
            <button class="btn-primary" onclick="openModal('manualModal')">➕ Manual Sit-in</button>
            <form method="POST" style="display:inline">
                <button type="submit" name="reset_sessions" class="btn-danger" onclick="return confirm('Reset ALL student sessions to 30?')">🔄 Reset All Sessions</button>
            </form>
        </div>
        <input type="text" id="tableSearch" class="table-search" placeholder="Filter active sit-ins..." oninput="filterTable()">
    </div>
    <div class="card">
        <div class="card-header">🟢 Currently Active Sit-in Sessions (<?= count($active) ?>)</div>
        <div class="table-wrap">
            <table id="sitinTable">
                <thead>
                    <tr><th>Sit-in ID</th><th>ID Number</th><th>Name</th><th>Purpose</th><th>Lab</th><th>Login Time</th><th>Duration</th><th>Action</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($active)): ?>
                    <tr><td colspan="8" class="no-data">No active sit-in sessions.</td></tr>
                    <?php else: foreach ($active as $r): ?>
                    <tr>
                        <td>#<?= $r['id'] ?></td>
                        <td><?= htmlspecialchars($r['id_number']) ?></td>
                        <td><?= htmlspecialchars($r['name']) ?></td>
                        <td><?= htmlspecialchars($r['purpose']) ?></td>
                        <td><?= htmlspecialchars($r['lab']) ?></td>
                        <td><?= date('M d, h:i A', strtotime($r['login_time'])) ?></td>
                        <td class="duration-cell" data-login="<?= $r['login_time'] ?>">—</td>
                        <td><button class="btn-del" onclick="openTimeoutModal(<?= $r['id'] ?>, '<?= htmlspecialchars($r['name'], ENT_QUOTES) ?>', '<?= htmlspecialchars($r['lab'], ENT_QUOTES) ?>', <?= $r['student_id'] ?>)">Force Out</button></td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
<footer>&copy; 2026 College of Computer Studies</footer>
<script>
function openModal(id)  { document.getElementById(id).style.display = 'flex'; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }
function filterTable() {
    const q = document.getElementById('tableSearch').value.toLowerCase();
    document.querySelectorAll('#sitinTable tbody tr').forEach(row => {
        row.style.display = row.innerText.toLowerCase().includes(q) ? '' : 'none';
    });
}
function searchStudent() {
    const q = document.getElementById('searchInput').value.trim(); if (!q) return;
    fetch('admin_search.php?q=' + encodeURIComponent(q)).then(r => r.text()).then(html => { document.getElementById('searchResults').innerHTML = html; });
}
document.getElementById('searchInput')?.addEventListener('keydown', e => { if (e.key === 'Enter') searchStudent(); });
function updateDurations() {
    document.querySelectorAll('.duration-cell').forEach(cell => {
        const login = new Date(cell.dataset.login).getTime();
        const diff = Date.now() - login;
        const h = Math.floor(diff/3600000).toString().padStart(2,'0');
        const m = Math.floor((diff%3600000)/60000).toString().padStart(2,'0');
        const s = Math.floor((diff%60000)/1000).toString().padStart(2,'0');
        cell.textContent = h+':'+m+':'+s;
    });
}
updateDurations();
setInterval(updateDurations, 1000);

function openTimeoutModal(sessionId, name, lab, studentId) {
    document.getElementById('to_session_id').value = sessionId;
    document.getElementById('to_student_id').value = studentId;
    document.getElementById('to_name').textContent = name;
    document.getElementById('to_lab').textContent = lab;
    openModal('timeoutModal');
}
</script>
</body>
</html>