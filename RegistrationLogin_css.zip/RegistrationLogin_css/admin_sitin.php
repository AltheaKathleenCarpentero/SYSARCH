<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php"); exit();
}
require_once 'config.php';

if (isset($_GET['timeout'])) {
    $session_id = intval($_GET['timeout']);
    $res = $conn->query("SELECT student_id FROM sit_in_sessions WHERE id = $session_id AND status = 'Active'");
    if ($row = $res->fetch_assoc()) {
        $conn->query("UPDATE sit_in_sessions SET logout_time = NOW(), status = 'Done' WHERE id = $session_id");
        $conn->query("UPDATE students SET sessions = GREATEST(0, sessions - 1) WHERE id = " . $row['student_id']);
    }
    header("Location: admin_sitin.php"); exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['manual_sitin'])) {
    $student_id = intval($_POST['student_id']);
    $purpose = trim($_POST['purpose']);
    $lab = trim($_POST['lab']);
    $check = $conn->query("SELECT id FROM sit_in_sessions WHERE student_id = $student_id AND status = 'Active'");
    if ($check->num_rows === 0 && !empty($purpose) && !empty($lab)) {
        $ins = $conn->prepare("INSERT INTO sit_in_sessions (student_id, purpose, lab) VALUES (?,?,?)");
        $ins->bind_param("iss", $student_id, $purpose, $lab);
        $ins->execute(); $ins->close();
    }
    header("Location: admin_sitin.php"); exit();
}

if (isset($_POST['reset_sessions'])) {
    $conn->query("UPDATE students SET sessions = 30");
    header("Location: admin_sitin.php"); exit();
}

$active   = $conn->query("SELECT s.id, st.id_number, CONCAT(st.first_name,' ',st.last_name) as name, s.purpose, s.lab, s.login_time, st.id as student_id FROM sit_in_sessions s JOIN students st ON s.student_id = st.id WHERE s.status = 'Active' ORDER BY s.login_time DESC")->fetch_all(MYSQLI_ASSOC);
$students = $conn->query("SELECT id, id_number, CONCAT(first_name,' ',last_name) as name FROM students ORDER BY last_name")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sit-in Management – CCS Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
<nav>
    <span class="nav-brand">🖥️ CCS Admin Panel</span>
    <div class="nav-links">
        <a href="admin.php">Dashboard</a>
        <a href="#" onclick="openModal('searchModal')">🔍 Search</a>
        <a href="admin_students.php">Students</a>
        <a href="admin_sitin.php" class="active">Sit-in</a>
        <a href="admin_sitin_records.php">Records</a>
    </div>
    <a href="admin.php?logout=1" class="logout-btn">Log out</a>
</nav>

<div class="modal-overlay" id="searchModal" style="display:none">
    <div class="modal-box">
        <div class="modal-body">
            <div class="sitin-id-row" style="display: flex; gap: 8px;">
                <input type="text" id="searchInput" class="modal-input" 
                    placeholder="Enter student ID (e.g. 21454640)" 
                    onkeyup="if(event.key==='Enter') searchStudent()">
                <button class="btn-find" onclick="searchStudent()" style="white-space: nowrap;">🔍 Find Student</button>
            </div>
            
            <!-- This is where the formatted Card will appear -->
            <div id="searchResults" style="margin-top:1.5rem"></div>
        </div>
    </div>
</div>

<div class="modal-overlay" id="manualModal" style="display:none">
    <div class="modal-box sitin-modal-box">
        <div class="modal-header sitin-modal-header">
            <span>&#128100; Sit-in Form</span>
            <button class="modal-close" onclick="closeModal('manualModal')">&#10005;</button>
        </div>
        <form method="POST" id="sitinForm">
            <div class="modal-body sitin-modal-body">

                <div class="sitin-section-label">
                    <span class="sitin-icon">&#128196;</span> ID NUMBER
                </div>
                <div class="sitin-id-row">
                    <input type="text" id="idLookupInput" class="modal-input sitin-input" placeholder="Enter student ID number" autocomplete="off">
                    <button type="button" class="btn-find" onclick="lookupStudent()">&#128269; Find</button>
                </div>
                <input type="hidden" name="student_id" id="foundStudentId">

                <div class="sitin-section-label">
                    <span class="sitin-icon">&#128100;</span> STUDENT NAME
                </div>
                <div id="studentNameDisplay" class="sitin-readonly-field">Auto-filled after ID lookup</div>

                <div class="sitin-two-col">
                    <div>
                        <div class="sitin-section-label">
                            <span class="sitin-icon">&#9776;</span> PURPOSE
                        </div>
                        <select name="purpose" id="purposeSelect" class="modal-input sitin-input" required>
                            <option value="">Select Purpose</option>
                            <option value="Java">Java</option>
                            <option value="C">C</option>
                            <option value="C++">C++</option>
                            <option value="C#">C#</option>
                            <option value="Python">Python</option>
                            <option value="JavaScript">JavaScript</option>
                            <option value="HTML/CSS">HTML/CSS</option>
                            <option value="SQL">SQL</option>
                            <option value="PHP">PHP</option>
                            <option value="Others">Others</option>
                        </select>
                    </div>
                    <div>
                        <div class="sitin-section-label">
                            <span class="sitin-icon">&#128187;</span> LABORATORY
                        </div>
                        <select name="lab" class="modal-input sitin-input" required>
                            <option value="">Select Lab</option>
                            <option>Lab 517</option><option>Lab 518</option><option>Lab 519</option>
                            <option>Lab 524</option><option>Lab 526</option><option>Lab 528</option>
                            <option>Lab 530</option><option>Lab 542</option>
                        </select>
                    </div>
                </div>

                <div class="sitin-section-label">
                    <span class="sitin-icon">&#9203;</span> REMAINING SESSIONS
                </div>
                <div id="remainingSessionsDisplay" class="sitin-readonly-field sitin-sessions-field">Auto-filled after ID lookup</div>

            </div>
            <div class="modal-footer sitin-modal-footer">
                <button type="button" class="btn-secondary" onclick="closeModal('manualModal')">&#10005; Close</button>
                <button type="submit" name="manual_sitin" class="btn-primary sitin-btn-submit">&#128266; Sit In</button>
            </div>
        </form>
    </div>
</div>

<main>
    <div class="page-title">Sit-in Management</div>
    <div class="table-toolbar">
        <div style="display:flex; gap:0.75rem; flex-wrap:wrap">
            <button class="btn-primary" onclick="openModal('manualModal')">&#128100; Sit-in Form</button>
            <form method="POST" style="display:inline">
                <button type="submit" name="reset_sessions" class="btn-danger" onclick="return confirm('Reset ALL student sessions to 30?')">🔄 Reset All Sessions</button>
            </form>
        </div>
        <input type="text" id="tableSearch" class="table-search" placeholder="Filter active sit-ins..." oninput="filterTable()">
    </div>
    <div class="card">
        <div class="card-header">🟢 Currently Active Sit-in Sessions (<?= count($active) ?>)</div>
        <div class="table-wrap">
            <table id="sitinTable">
                <thead>
                    <tr><th>Sit-in ID</th><th>ID Number</th><th>Name</th><th>Purpose</th><th>Lab</th><th>Login Time</th><th>Duration</th><th>Action</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($active)): ?>
                    <tr><td colspan="8" class="no-data">No active sit-in sessions.</td></tr>
                    <?php else: foreach ($active as $r): ?>
                    <tr>
                        <td>#<?= $r['id'] ?></td>
                        <td><?= htmlspecialchars($r['id_number']) ?></td>
                        <td><?= htmlspecialchars($r['name']) ?></td>
                        <td><?= htmlspecialchars($r['purpose']) ?></td>
                        <td><?= htmlspecialchars($r['lab']) ?></td>
                        <td><?= date('M d, h:i A', strtotime($r['login_time'])) ?></td>
                        <td class="duration-cell" data-login="<?= $r['login_time'] ?>">—</td>
                        <td><a href="?timeout=<?= $r['id'] ?>" class="btn-del" onclick="return confirm('Force logout this student?')">Force Out</a></td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
<footer>&copy; 2026 College of Computer Studies</footer>
<script>
const studentMap = <?php
    $map = [];
    foreach ($students as $s) { $map[$s['id_number']] = ['id' => $s['id'], 'name' => $s['name']]; }
    echo json_encode($map);
?>;

const studentSessions = <?php
    $sess = [];
    $res2 = $conn->query("SELECT id_number, sessions FROM students");
    while ($row2 = $res2->fetch_assoc()) { $sess[$row2['id_number']] = $row2['sessions']; }
    echo json_encode($sess);
?>;

function lookupStudent() {
    const idNum = document.getElementById('idLookupInput').value.trim();
    if (!idNum) { alert('Please enter a student ID number.'); return; }
    if (studentMap[idNum]) {
        const student = studentMap[idNum];
        document.getElementById('foundStudentId').value = student.id;
        document.getElementById('studentNameDisplay').textContent = student.name;
        document.getElementById('studentNameDisplay').classList.add('sitin-filled');
        const sessions = studentSessions[idNum] !== undefined ? studentSessions[idNum] : '—';
        document.getElementById('remainingSessionsDisplay').textContent = sessions + ' session(s) remaining';
        document.getElementById('remainingSessionsDisplay').classList.add('sitin-filled');
        document.getElementById('remainingSessionsDisplay').style.color = sessions == 0 ? '#e05252' : '';
    } else {
        document.getElementById('foundStudentId').value = '';
        document.getElementById('studentNameDisplay').textContent = 'Student not found.';
        document.getElementById('studentNameDisplay').classList.remove('sitin-filled');
        document.getElementById('remainingSessionsDisplay').textContent = 'Auto-filled after ID lookup';
        document.getElementById('remainingSessionsDisplay').classList.remove('sitin-filled');
    }
}

document.getElementById('idLookupInput')?.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); lookupStudent(); } });

function openModal(id) {
    document.getElementById(id).style.display = 'flex';
    if (id === 'manualModal') {
        document.getElementById('idLookupInput').value = '';
        document.getElementById('foundStudentId').value = '';
        document.getElementById('studentNameDisplay').textContent = 'Auto-filled after ID lookup';
        document.getElementById('studentNameDisplay').classList.remove('sitin-filled');
        document.getElementById('remainingSessionsDisplay').textContent = 'Auto-filled after ID lookup';
        document.getElementById('remainingSessionsDisplay').classList.remove('sitin-filled');
        document.getElementById('purposeSelect').value = '';
    }
}
function closeModal(id) { document.getElementById(id).style.display = 'none'; }
function filterTable() {
    const q = document.getElementById('tableSearch').value.toLowerCase();
    document.querySelectorAll('#sitinTable tbody tr').forEach(row => {
        row.style.display = row.innerText.toLowerCase().includes(q) ? '' : 'none';
    });
}
function searchStudent() {
    const q = document.getElementById('searchInput').value.trim();
    if (!q) return;
    
    const box = document.getElementById('searchResults');
    box.innerHTML = `<div class="search-loading">Searching database...</div>`;
    
    fetch('admin_search.php?q=' + encodeURIComponent(q))
        .then(r => r.json())
        .then(s => {
            if (!s) { 
                box.innerHTML = `<div class="search-error">❌ No student found with ID: ${q}</div>`; 
                return; 
            }
            
            // Generate the Form/Card Layout
            box.innerHTML = `
                <div class="student-result-card">
                    <div class="result-header">
                        <div class="result-avatar">${s.first_name[0]}${s.last_name[0]}</div>
                        <div class="result-title">
                            <h3>${s.first_name} ${s.last_name}</h3>
                            <span>${s.id_number}</span>
                        </div>
                    </div>
                    
                    <div class="result-grid">
                        <div class="grid-item"><strong>Course:</strong> ${s.course}</div>
                        <div class="grid-item"><strong>Year Level:</strong> ${s.course_level}</div>
                        <div class="grid-item"><strong>Sessions:</strong> <span class="session-badge">${s.sessions} left</span></div>
                        <div class="grid-item"><strong>Email:</strong> ${s.email ?? 'N/A'}</div>
                    </div>

                    <div class="result-footer">
                        <strong>Address:</strong> ${s.address ?? 'No address provided'}
                    </div>
                </div>`;
        })
        .catch(() => { 
            box.innerHTML = `<div class="search-error">⚠️ Connection error. Please try again.</div>`; 
        });
}
document.getElementById('searchInput')?.addEventListener('keydown', e => { if (e.key === 'Enter') searchStudent(); });
function updateDurations() {
    document.querySelectorAll('.duration-cell').forEach(cell => {
        const login = new Date(cell.dataset.login).getTime();
        const diff = Date.now() - login;
        const h = Math.floor(diff/3600000).toString().padStart(2,'0');
        const m = Math.floor((diff%3600000)/60000).toString().padStart(2,'0');
        const s = Math.floor((diff%60000)/1000).toString().padStart(2,'0');
        cell.textContent = h+':'+m+':'+s;
    });
}
updateDurations();
setInterval(updateDurations, 1000);
</script>
</body>
</html>