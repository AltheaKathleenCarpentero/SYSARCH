<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php"); exit();
}
require_once 'config.php';

// Reset all sessions
if (isset($_POST['reset_sessions'])) {
    $conn->query("UPDATE students SET sessions = 30");
}

// Delete student
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM students WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: admin_students.php"); exit();
}

// Edit student
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_id'])) {
    $stmt = $conn->prepare("UPDATE students SET first_name=?, last_name=?, course=?, course_level=?, email=?, sessions=? WHERE id=?");
    $stmt->bind_param("sssisii",
        $_POST['first_name'], $_POST['last_name'],
        $_POST['course'], $_POST['course_level'],
        $_POST['email'], $_POST['sessions'], $_POST['edit_id']
    );
    $stmt->execute();
    header("Location: admin_students.php"); exit();
}

$students = $conn->query("SELECT * FROM students ORDER BY last_name ASC")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Students – CCS Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
    <nav>
        <span class="nav-brand">College of Computer Studies Admin</span>
        <div class="nav-links">
            <a href="admin.php">Home</a>
            <a href="#" onclick="openModal('searchModal')">Search</a>
            <a href="admin_students.php" class="active">Students</a>
            <a href="admin_sitin.php">Sit-in</a>
            <a href="admin_sitin_records.php">View Sit-in Records</a>
        </div>
        <a href="admin.php?logout=1" class="logout-btn">Log out</a>
    </nav>

    <!-- SEARCH MODAL -->
    <div class="modal-overlay" id="searchModal" style="display:none">
        <div class="modal-box">
            <div class="modal-header">
                <span>Search Student</span>
                <button class="modal-close" onclick="closeModal('searchModal')">✕</button>
            </div>
            <div class="modal-body">
                <input type="text" id="searchInput" class="modal-input" placeholder="Search...">
                <div id="searchResults" class="search-results"></div>
            </div>
            <div class="modal-footer">
                <button class="btn-primary" onclick="searchStudent()">Search</button>
            </div>
        </div>
    </div>

    <!-- EDIT MODAL -->
    <div class="modal-overlay" id="editModal" style="display:none">
        <div class="modal-box">
            <div class="modal-header">
                <span>Edit Student</span>
                <button class="modal-close" onclick="closeModal('editModal')">✕</button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="edit_id" id="edit_id">
                    <div class="form-group"><label>First Name</label><input type="text" name="first_name" id="edit_first_name" class="modal-input"></div>
                    <div class="form-group"><label>Last Name</label><input type="text" name="last_name" id="edit_last_name" class="modal-input"></div>
                    <div class="form-group"><label>Course</label><input type="text" name="course" id="edit_course" class="modal-input"></div>
                    <div class="form-group"><label>Year Level</label><input type="number" name="course_level" id="edit_course_level" class="modal-input" min="1" max="5"></div>
                    <div class="form-group"><label>Email</label><input type="email" name="email" id="edit_email" class="modal-input"></div>
                    <div class="form-group"><label>Sessions</label><input type="number" name="sessions" id="edit_sessions" class="modal-input"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-secondary" onclick="closeModal('editModal')">Cancel</button>
                    <button type="submit" class="btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>

    <main>
        <div class="page-title">Students Information</div>
        <div class="table-toolbar">
            <div style="display:flex; gap:0.75rem;">
                <form method="POST" style="display:inline">
                    <button type="submit" name="reset_sessions" class="btn-danger" onclick="return confirm('Reset all sessions to 30?')">Reset All Sessions</button>
                </form>
            </div>
            <input type="text" id="tableSearch" class="table-search" placeholder="Search..." oninput="filterTable()">
        </div>
        <div class="card">
            <div class="table-wrap">
                <table id="studentsTable">
                    <thead>
                        <tr>
                            <th>ID Number</th>
                            <th>Name</th>
                            <th>Year Level</th>
                            <th>Course</th>
                            <th>Remaining Sessions</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $s): ?>
                        <tr>
                            <td><?= htmlspecialchars($s['id_number']) ?></td>
                            <td><?= htmlspecialchars($s['first_name'] . ' ' . $s['last_name']) ?></td>
                            <td><?= $s['course_level'] ?></td>
                            <td><?= htmlspecialchars($s['course']) ?></td>
                            <td><?= $s['sessions'] ?? 30 ?></td>
                            <td>
                                <button class="btn-edit" onclick="openEdit(<?= htmlspecialchars(json_encode($s)) ?>)">Edit</button>
                                <a href="?delete=<?= $s['id'] ?>" class="btn-del" onclick="return confirm('Delete this student?')">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <footer>&copy; 2026 College of Computer Studies</footer>

    <script>
        function openEdit(s) {
            document.getElementById('edit_id').value           = s.id;
            document.getElementById('edit_first_name').value   = s.first_name;
            document.getElementById('edit_last_name').value    = s.last_name;
            document.getElementById('edit_course').value       = s.course;
            document.getElementById('edit_course_level').value = s.course_level;
            document.getElementById('edit_email').value        = s.email || '';
            document.getElementById('edit_sessions').value     = s.sessions || 30;
            document.getElementById('editModal').style.display = 'flex';
        }
        function openModal(id)  { document.getElementById(id).style.display = 'flex'; }
        function closeModal(id) { document.getElementById(id).style.display = 'none'; }
        function filterTable() {
            const q = document.getElementById('tableSearch').value.toLowerCase();
            document.querySelectorAll('#studentsTable tbody tr').forEach(row => {
                row.style.display = row.innerText.toLowerCase().includes(q) ? '' : 'none';
            });
        }
        function searchStudent() {
            const q = document.getElementById('searchInput').value.trim();
            if (!q) return;
            fetch('admin_search.php?q=' + encodeURIComponent(q))
                .then(r => r.text())
                .then(html => { document.getElementById('searchResults').innerHTML = html; });
        }
    </script>
</body>
</html>