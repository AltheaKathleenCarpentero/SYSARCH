<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php"); exit();
}
require_once 'config.php';

if (isset($_GET['timeout'])) {
    $session_id = intval($_GET['timeout']);
    $res = $conn->query("SELECT student_id FROM sit_in_sessions WHERE id = $session_id AND status = 'Active'");
    if ($row = $res->fetch_assoc()) {
        $conn->query("UPDATE sit_in_sessions SET logout_time = NOW(), status = 'Done' WHERE id = $session_id");
        $conn->query("UPDATE students SET sessions = GREATEST(0, sessions - 1) WHERE id = " . $row['student_id']);
    }
    header("Location: admin_sitin.php"); exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['manual_sitin'])) {
    $student_id = intval($_POST['student_id']);
    $purpose = trim($_POST['purpose']);
    $lab = trim($_POST['lab']);
    $check = $conn->query("SELECT id FROM sit_in_sessions WHERE student_id = $student_id AND status = 'Active'");
    if ($check->num_rows === 0 && !empty($purpose) && !empty($lab)) {
        $ins = $conn->prepare("INSERT INTO sit_in_sessions (student_id, purpose, lab) VALUES (?,?,?)");
        $ins->bind_param("iss", $student_id, $purpose, $lab);
        $ins->execute(); $ins->close();
    }
    header("Location: admin_sitin.php"); exit();
}

if (isset($_POST['reset_sessions'])) {
    $conn->query("UPDATE students SET sessions = 30");
    header("Location: admin_sitin.php"); exit();
}

$active   = $conn->query("SELECT s.id, st.id_number, CONCAT(st.first_name,' ',st.last_name) as name, s.purpose, s.lab, s.login_time, st.id as student_id FROM sit_in_sessions s JOIN students st ON s.student_id = st.id WHERE s.status = 'Active' ORDER BY s.login_time DESC")->fetch_all(MYSQLI_ASSOC);
$students = $conn->query("SELECT id, id_number, CONCAT(first_name,' ',last_name) as name FROM students ORDER BY last_name")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sit-in Management – CCS Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
<nav>
    <span class="nav-brand">🖥️ CCS Admin Panel</span>
    <div class="nav-links">
        <a href="admin.php">Dashboard</a>
        <a href="#" onclick="openModal('searchModal')">Search</a>
        <a href="admin_students.php">Students</a>
        
        <!-- Sit-in Dropdown -->
        <div class="nav-dropdown">
            <div class="nav-drop-toggle active">Sit-in</div>
            <div class="nav-drop-menu">
                <a href="admin_sitin.php" class="active">📋 Sit-in</a>
                <a href="admin_sitin_records.php">📊 View Sit-in Records</a>
                <a href="admin_sitin_reports.php">📈 Sit-in Reports</a>
            </div>
        </div>
        
        <a href="admin_feedback.php">Feedback Reports</a>
        <a href="admin_reservation.php">Reservation</a>
        <a href="admin.php?logout=1" class="logout-btn">Log out</a>
    </div>
</nav>

<div class="modal-overlay" id="searchModal" style="display:none">
    <div class="modal-box">
        <div class="modal-header"><span>🔍 Search Student</span><button class="modal-close" onclick="closeModal('searchModal')">✕</button></div>
        <div class="modal-body">
            <input type="text" id="searchInput" class="modal-input" placeholder="Name or ID number...">
            <div id="searchResults" class="search-results"></div>
        </div>
        <div class="modal-footer"><button class="btn-primary" onclick="searchStudent()">Search</button></div>
    </div>
</div>

<div class="modal-overlay" id="manualModal" style="display:none">
    <div class="modal-box">
        <div class="modal-header"><span>➕ Manual Sit-in</span><button class="modal-close" onclick="closeModal('manualModal')">✕</button></div>
        <form method="POST">
            <div class="modal-body">
                <div class="form-group"><label>Student</label>
                    <select name="student_id" class="modal-input" required>
                        <option value="">Select Student</option>
                        <?php foreach ($students as $s): ?>
                        <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['id_number'] . ' — ' . $s['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group"><label>Purpose</label>
                    <input type="text" name="purpose" class="modal-input" placeholder="e.g. Programming Practice" required>
                </div>
                <div class="form-group"><label>Laboratory</label>
                    <select name="lab" class="modal-input" required>
                        <option value="">Select Lab</option>
                        <option>Lab 517</option><option>Lab 518</option><option>Lab 519</option>
                        <option>Lab 524</option><option>Lab 526</option><option>Lab 528</option>
                        <option>Lab 530</option><option>Lab 542</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeModal('manualModal')">Cancel</button>
                <button type="submit" name="manual_sitin" class="btn-primary">Start Sit-in</button>
            </div>
        </form>
    </div>
</div>

<main>
    <div class="page-title">Sit-in Management</div>
    <div class="table-toolbar">
        <div style="display:flex; gap:0.75rem; flex-wrap:wrap">
            <button class="btn-primary" onclick="openModal('manualModal')">➕ Manual Sit-in</button>
            <form method="POST" style="display:inline">
                <button type="submit" name="reset_sessions" class="btn-danger" onclick="return confirm('Reset ALL student sessions to 30?')">🔄 Reset All Sessions</button>
            </form>
        </div>
        <input type="text" id="tableSearch" class="table-search" placeholder="Filter active sit-ins..." oninput="filterTable()">
    </div>
    <div class="card">
        <div class="card-header">🟢 Currently Active Sit-in Sessions (<?= count($active) ?>)</div>
        <div class="table-wrap">
            <table id="sitinTable">
                <thead>
                    <tr><th>Sit-in ID</th><th>ID Number</th><th>Name</th><th>Purpose</th><th>Lab</th><th>Login Time</th><th>Duration</th><th>Action</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($active)): ?>
                    <tr><td colspan="8" class="no-data">No active sit-in sessions.</td></tr>
                    <?php else: foreach ($active as $r): ?>
                    <tr>
                        <td>#<?= $r['id'] ?></td>
                        <td><?= htmlspecialchars($r['id_number']) ?></td>
                        <td><?= htmlspecialchars($r['name']) ?></td>
                        <td><?= htmlspecialchars($r['purpose']) ?></td>
                        <td><?= htmlspecialchars($r['lab']) ?></td>
                        <td><?= date('M d, h:i A', strtotime($r['login_time'])) ?></td>
                        <td class="duration-cell" data-login="<?= $r['login_time'] ?>">—</td>
                        <td><a href="?timeout=<?= $r['id'] ?>" class="btn-del" onclick="return confirm('Force logout this student?')">Force Out</a></td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
<footer>&copy; 2026 College of Computer Studies</footer>
<script>
function openModal(id)  { document.getElementById(id).style.display = 'flex'; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }
function filterTable() {
    const q = document.getElementById('tableSearch').value.toLowerCase();
    document.querySelectorAll('#sitinTable tbody tr').forEach(row => {
        row.style.display = row.innerText.toLowerCase().includes(q) ? '' : 'none';
    });
}
function searchStudent() {
    const q = document.getElementById('searchInput').value.trim(); if (!q) return;
    fetch('admin_search.php?q=' + encodeURIComponent(q)).then(r => r.text()).then(html => { document.getElementById('searchResults').innerHTML = html; });
}
document.getElementById('searchInput')?.addEventListener('keydown', e => { if (e.key === 'Enter') searchStudent(); });
function updateDurations() {
    document.querySelectorAll('.duration-cell').forEach(cell => {
        const login = new Date(cell.dataset.login).getTime();
        const diff = Date.now() - login;
        const h = Math.floor(diff/3600000).toString().padStart(2,'0');
        const m = Math.floor((diff%3600000)/60000).toString().padStart(2,'0');
        const s = Math.floor((diff%60000)/1000).toString().padStart(2,'0');
        cell.textContent = h+':'+m+':'+s;
    });
}
updateDurations();
setInterval(updateDurations, 1000);
</script>
</body>
</html>