<?php
session_start();
if (!isset($_SESSION['student_id'])) { header("Location: index.php"); exit(); }
require_once 'config.php';

$student_id = $_SESSION['student_id'];
$error = ''; $success = '';

$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Broken PCs per lab (hardcoded — adjust as needed)
$broken_pcs = [
    '524' => [15, 27],
    '526' => [3, 18],
    '528' => [7, 22],
    '530' => [10, 35],
    '542' => [5, 42],
    '544' => [12, 30],
];

$labs = ['524', '526', '528', '530', '542', '544'];
$programming_languages = ['C', 'C++', 'C#', 'Java', 'Python', 'JavaScript', 'PHP', 'ASP.NET', 'SQL', 'HTML/CSS', 'Web Development', 'Others'];
$time_slots = [
    '07:30' => '07:30 – 08:30',
    '08:30' => '08:30 – 09:30',
    '09:30' => '09:30 – 10:30',
    '10:30' => '10:30 – 11:30',
    '13:30' => '13:30 – 14:30',
    '14:30' => '14:30 – 15:30',
    '15:30' => '15:30 – 16:30',
    '16:30' => '16:30 – 17:30',
    '17:30' => '17:30 – 18:30',
];
$days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reserve'])) {
    $purpose          = trim($_POST['purpose']);
    $lab              = trim($_POST['lab']);
    $pc_number        = trim($_POST['pc_number']);
    $reservation_date = $_POST['reservation_date'];
    $reservation_time = $_POST['reservation_time'];
    $day              = trim($_POST['day']);
    $duration         = intval($_POST['duration'] ?? 1);

    if ($student['sessions'] <= 0) {
        $error = "You have no remaining sessions. Please contact the administrator.";
    } else {
        $chk = $conn->prepare("SELECT id FROM reservations WHERE student_id = ? AND status = 'Pending'");
        $chk->bind_param("i", $student_id);
        $chk->execute();
        if ($chk->get_result()->num_rows > 0) {
            $error = "You already have a pending reservation. Please wait for confirmation or cancel it first.";
        } else {
            // Check if chosen PC is already reserved at that date/time
            $pc_chk = $conn->prepare("SELECT id FROM reservations WHERE lab = ? AND pc_number = ? AND reservation_date = ? AND reservation_time = ? AND status IN ('Pending','Approved')");
            $pc_chk->bind_param("ssss", $lab, $pc_number, $reservation_date, $reservation_time);
            $pc_chk->execute();
            if ($pc_chk->get_result()->num_rows > 0) {
                $error = "That PC is already reserved for the selected date and time. Please choose another.";
            } else {
                $ins = $conn->prepare("INSERT INTO reservations (student_id, purpose, lab, pc_number, reservation_date, reservation_time, duration, status, created_at) VALUES (?,?,?,?,?,?,?,'Pending',NOW())");
                $ins->bind_param("isssssi", $student_id, $purpose, $lab, $pc_number, $reservation_date, $reservation_time, $duration);
                if ($ins->execute()) {
                    $success = "Your reservation has been submitted successfully and is currently pending admin approval.";
                    $stmt2 = $conn->prepare("SELECT * FROM students WHERE id = ?");
                    $stmt2->bind_param("i", $student_id);
                    $stmt2->execute();
                    $student = $stmt2->get_result()->fetch_assoc();
                    $stmt2->close();
                } else {
                    $error = "Reservation failed. Please try again.";
                }
                $ins->close();
            }
            $pc_chk->close();
        }
        $chk->close();
    }
}

if (isset($_GET['cancel'])) {
    $rid = intval($_GET['cancel']);
    $conn->prepare("UPDATE reservations SET status='Cancelled' WHERE id=? AND student_id=?")->execute() || null;
    $cstmt = $conn->prepare("UPDATE reservations SET status='Cancelled' WHERE id=? AND student_id=?");
    $cstmt->bind_param("ii", $rid, $student_id);
    $cstmt->execute();
    header("Location: student_reservation.php"); exit();
}

// Fetch reserved PCs for the JS availability check
$reserved_pcs_raw = $conn->query("
    SELECT lab, pc_number, reservation_date, reservation_time
    FROM reservations WHERE status IN ('Pending','Approved')
")->fetch_all(MYSQLI_ASSOC);

$reservations = $conn->query("
    SELECT * FROM reservations WHERE student_id=$student_id ORDER BY created_at DESC
")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reservation – CCS Sit-in</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800;900&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/dashboard.css">
    <style>
        .res-wrap { max-width: 860px; margin: 0 auto; padding: 2rem 1.5rem; }
        .page-title { font-size: 1.7rem; font-weight: 900; color: var(--gold); margin-bottom: 1.75rem; }

        /* ── FORM CARD ── */
        .res-card { background: var(--card-bg); border: 1.5px solid var(--border); border-radius: 20px; padding: 2rem; margin-bottom: 2rem; }
        .res-card h3 { font-size: 1rem; font-weight: 800; color: var(--gold-light); text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 1.5rem; }

        .fgroup { margin-bottom: 1.25rem; }
        .fgroup label { display: block; font-size: 0.72rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.08em; color: var(--text-muted); margin-bottom: 0.45rem; }
        .fgroup label .req { color: var(--gold); }
        .fgroup input, .fgroup select {
            width: 100%; padding: 0.7rem 1rem;
            border: 1.5px solid rgba(212,160,23,0.2); border-radius: 10px;
            font-size: 0.92rem; font-family: 'Nunito', sans-serif;
            background: rgba(255,255,255,0.05); color: var(--text);
            outline: none; transition: border-color 0.2s, box-shadow 0.2s;
        }
        .fgroup input:focus, .fgroup select:focus {
            border-color: var(--gold); box-shadow: 0 0 0 3px rgba(212,160,23,0.14);
        }
        .fgroup select option { background: #1a0035; color: #f0e6ff; }
        .frow { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }

        /* ── LAB BUTTONS ── */
        .lab-btns { display: flex; flex-wrap: wrap; gap: 0.5rem; }
        .lab-btn {
            padding: 0.5rem 1.1rem; border-radius: 10px; font-size: 0.85rem; font-weight: 800;
            cursor: pointer; border: 1.5px solid rgba(212,160,23,0.3);
            color: var(--text-muted); background: transparent; transition: all 0.2s;
        }
        .lab-btn:hover { border-color: var(--gold); color: var(--gold); }
        .lab-btn.active { background: var(--gold); color: #1a0a2e; border-color: var(--gold); }

        /* ── DAY BUTTONS ── */
        .day-btns { display: flex; flex-wrap: wrap; gap: 0.5rem; }
        .day-btn {
            padding: 0.45rem 1rem; border-radius: 10px; font-size: 0.83rem; font-weight: 700;
            cursor: pointer; border: 1.5px solid rgba(212,160,23,0.25);
            color: var(--text-muted); background: transparent; transition: all 0.2s;
        }
        .day-btn.active { background: var(--gold); color: #1a0a2e; border-color: var(--gold); }

        /* ── TIME SLOT BUTTONS ── */
        .time-btns { display: flex; flex-wrap: wrap; gap: 0.5rem; }
        .time-btn {
            padding: 0.5rem 0.9rem; border-radius: 10px; font-size: 0.82rem; font-weight: 700;
            cursor: pointer; border: 1.5px solid rgba(212,160,23,0.25);
            color: var(--text-muted); background: transparent; transition: all 0.2s;
        }
        .time-btn.active { background: var(--gold); color: #1a0a2e; border-color: var(--gold); }

        /* ── PC GRID ── */
        .pc-section { margin-top: 0.2rem; }
        .pc-legend { display: flex; gap: 1.2rem; margin-bottom: 0.75rem; font-size: 0.78rem; font-weight: 700; }
        .legend-dot { width: 9px; height: 9px; border-radius: 50%; display: inline-block; margin-right: 4px; }
        .dot-available { background: #5de898; }
        .dot-taken     { background: #ff7070; }
        .dot-broken    { background: #f0c040; }
        .dot-selected  { background: var(--gold); border: 2px solid #fff; }

        .pc-grid { display: grid; grid-template-columns: repeat(8, 1fr); gap: 0.45rem; }
        .pc-btn {
            padding: 0.5rem 0.25rem; border-radius: 9px; font-size: 0.72rem; font-weight: 800;
            cursor: pointer; border: 1.5px solid rgba(212,160,23,0.2);
            background: rgba(255,255,255,0.04); color: var(--text);
            text-align: center; transition: all 0.15s; line-height: 1.3;
        }
        .pc-btn .pc-label { display: block; font-size: 0.78rem; font-weight: 900; }
        .pc-btn .pc-status { display: block; font-size: 0.6rem; font-weight: 700; }
        .pc-btn.available:hover { border-color: var(--gold); background: rgba(212,160,23,0.12); }
        .pc-btn.selected  { border-color: var(--gold); background: rgba(212,160,23,0.22); color: var(--gold); box-shadow: 0 0 0 2px rgba(212,160,23,0.4); }
        .pc-btn.taken     { border-color: rgba(255,80,80,0.4); background: rgba(255,80,80,0.08); color: #ff9090; cursor: not-allowed; opacity: 0.7; }
        .pc-btn.broken    { border-color: rgba(240,192,64,0.4); background: rgba(240,192,64,0.08); color: #f0c040; cursor: not-allowed; opacity: 0.65; }

        /* ── SUBMIT ── */
        .btn-reserve {
            width: 100%; padding: 0.9rem; border-radius: 12px; font-size: 0.95rem; font-weight: 900;
            background: linear-gradient(135deg, var(--gold), var(--gold-dim)); color: #1a0a2e;
            border: none; cursor: pointer; letter-spacing: 0.06em; text-transform: uppercase;
            transition: transform 0.15s, box-shadow 0.15s; margin-top: 1.5rem;
            box-shadow: 0 4px 18px rgba(212,160,23,0.3);
        }
        .btn-reserve:hover { transform: translateY(-1px); box-shadow: 0 6px 22px rgba(212,160,23,0.45); }

        /* ── ALERTS ── */
        .alert { padding: 0.9rem 1.1rem; border-radius: 12px; margin-bottom: 1.25rem; font-weight: 700; font-size: 0.88rem; }
        .alert-success { background: rgba(46,213,115,0.1); border: 1px solid rgba(46,213,115,0.3); color: #5de898; }
        .alert-error   { background: rgba(255,60,60,0.1);  border: 1px solid rgba(255,60,60,0.3);  color: #ff9090; }

        /* ── MY RESERVATIONS TABLE ── */
        .res-table { width: 100%; border-collapse: collapse; font-size: 0.86rem; }
        .res-table th { padding: 0.65rem 0.9rem; text-align: left; font-size: 0.7rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.07em; color: var(--text-muted); border-bottom: 1px solid var(--border); }
        .res-table td { padding: 0.7rem 0.9rem; border-bottom: 1px solid rgba(212,160,23,0.07); color: var(--text); vertical-align: middle; }
        .status-pending   { background: rgba(212,160,23,0.15); color: var(--gold); padding: 2px 10px; border-radius: 12px; font-weight: 800; font-size: 0.78rem; }
        .status-approved  { background: rgba(46,213,115,0.15); color: #5de898; padding: 2px 10px; border-radius: 12px; font-weight: 800; font-size: 0.78rem; }
        .status-cancelled { background: rgba(255,80,80,0.12); color: #ff9090; padding: 2px 10px; border-radius: 12px; font-weight: 800; font-size: 0.78rem; }
        .status-completed { background: rgba(100,100,255,0.12); color: #a0a0ff; padding: 2px 10px; border-radius: 12px; font-weight: 800; font-size: 0.78rem; }
        .btn-cancel-sm { padding: 3px 10px; font-size: 0.72rem; border-radius: 6px; background: rgba(255,80,80,0.1); border: 1px solid rgba(255,80,80,0.3); color: #ff9090; cursor: pointer; font-weight: 700; text-decoration: none; }
        .btn-cancel-sm:hover { background: rgba(255,80,80,0.22); }
    </style>
    <link rel="stylesheet" href="assets/schema.css">
</head>
<body>
<nav>
    <span class="nav-brand">🎓 CCS Sit-in Monitoring System</span>
    <div class="nav-links">
        <div class="nav-dropdown">
            <div class="nav-drop-toggle">Notifications</div>
            <div class="nav-drop-menu">
                <a href="student_notifications.php">Announcements</a>
                <a href="student_alerts.php">Alerts</a>
                <a href="student_messages.php">Messages</a>
            </div>
        </div>
        <a href="dashboard.php">Home</a>
        <a href="student_edit_profile.php">Edit Profile</a>
        <a href="student_history.php">History</a>
        <a href="student_leaderboard.php">🏆 Leaderboard</a>
        <a href="student_reservation.php" class="active">Reservation</a>
        <a href="dashboard.php?logout=1" class="logout-btn">Logout</a>
    </div>
</nav>

<main>
<div class="res-wrap">
    <div class="page-title">🖥️ PC Reservation</div>

    <?php if ($error): ?>
        <div class="alert alert-error">⚠ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success">✓ <?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <!-- FORM -->
    <div class="res-card">
        <h3>Make a Reservation</h3>
        <form method="POST" id="resForm">
            <input type="hidden" name="pc_number" id="pc_number_input">
            <input type="hidden" name="lab"        id="lab_input">
            <input type="hidden" name="day"        id="day_input">
            <input type="hidden" name="reservation_time" id="time_input">

            <!-- Purpose -->
            <div class="fgroup">
                <label>Purpose <span class="req">*</span></label>
                <select name="purpose" required>
                    <option value="">Select Programming Language / Purpose</option>
                    <?php foreach ($programming_languages as $l): ?>
                        <option value="<?= $l ?>"><?= $l ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Lab -->
            <div class="fgroup">
                <label>Select Laboratory <span class="req">*</span></label>
                <div class="lab-btns">
                    <?php foreach ($labs as $lab): ?>
                        <button type="button" class="lab-btn" onclick="selectLab('<?= $lab ?>', this)">Lab <?= $lab ?></button>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Date & Day side by side -->
            <div class="frow">
                <div class="fgroup">
                    <label>Select Date <span class="req">*</span></label>
                    <input type="date" name="reservation_date" id="res_date" min="<?= date('Y-m-d') ?>" required onchange="autoSelectDay(this.value)">
                </div>
                <div class="fgroup">
                    <label>Day <span class="req">*</span></label>
                    <div class="day-btns" id="day-btns">
                        <?php foreach ($days as $d): ?>
                            <button type="button" class="day-btn" onclick="selectDay('<?= $d ?>', this)"><?= $d ?></button>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Time Slot -->
            <div class="fgroup">
                <label>Select Time Slot <span class="req">*</span></label>
                <div class="time-btns">
                    <?php foreach ($time_slots as $val => $label): ?>
                        <button type="button" class="time-btn" onclick="selectTime('<?= $val ?>', this)"><?= $label ?></button>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- PC Grid -->
            <div class="fgroup pc-section" id="pc-section" style="display:none">
                <label>Select PC <span class="req">*</span> — <span id="pc-lab-label" style="color:var(--gold);font-size:0.8rem;"></span></label>
                <div class="pc-legend">
                    <span><span class="legend-dot dot-available"></span>Available</span>
                    <span><span class="legend-dot dot-taken" style="background:#ff7070"></span>Reserved</span>
                    <span><span class="legend-dot dot-broken" style="background:#f0c040"></span>Out of Service</span>
                </div>
                <div class="pc-grid" id="pc-grid"></div>
            </div>

            <button type="submit" name="reserve" class="btn-reserve">Submit Reservation</button>
        </form>
    </div>

    <!-- MY RESERVATIONS -->
    <div class="res-card">
        <h3>My Reservations</h3>
        <?php if (empty($reservations)): ?>
            <p style="text-align:center;color:var(--text-muted);padding:1.5rem 0;">No reservations found.</p>
        <?php else: ?>
        <div style="overflow-x:auto">
            <table class="res-table">
                <thead>
                    <tr><th>Purpose</th><th>Lab</th><th>PC</th><th>Date</th><th>Time</th><th>Status</th><th></th></tr>
                </thead>
                <tbody>
                <?php foreach ($reservations as $r): ?>
                <tr>
                    <td><?= htmlspecialchars($r['purpose']) ?></td>
                    <td>Lab <?= htmlspecialchars($r['lab']) ?></td>
                    <td><?= $r['pc_number'] ? 'PC '.$r['pc_number'] : '—' ?></td>
                    <td><?= date('M d, Y', strtotime($r['reservation_date'])) ?></td>
                    <td><?= substr($r['reservation_time'], 0, 5) ?></td>
                    <td><span class="status-<?= strtolower($r['status']) ?>"><?= $r['status'] ?></span></td>
                    <td>
                        <?php if ($r['status'] === 'Pending'): ?>
                            <a href="?cancel=<?= $r['id'] ?>" class="btn-cancel-sm" onclick="return confirm('Cancel this reservation?')">Cancel</a>
                        <?php else: ?>—<?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
</main>

<footer>&copy; 2026 College of Computer Studies</footer>

<script>
// Reserved PCs from DB
const reservedPCs = <?= json_encode($reserved_pcs_raw) ?>;

// Broken PCs per lab
const brokenPCs = <?= json_encode($broken_pcs) ?>;

let selectedLab  = '';
let selectedTime = '';
let selectedDate = '';
let selectedPC   = '';

function selectLab(lab, btn) {
    selectedLab = lab;
    document.getElementById('lab_input').value = lab;
    document.querySelectorAll('.lab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('pc-lab-label').textContent = 'Lab ' + lab;
    renderPCGrid();
}

function selectDay(day, btn) {
    document.getElementById('day_input').value = day;
    document.querySelectorAll('.day-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
}

function selectTime(val, btn) {
    selectedTime = val + ':00';
    document.getElementById('time_input').value = selectedTime;
    document.querySelectorAll('.time-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderPCGrid();
}

function autoSelectDay(dateStr) {
    selectedDate = dateStr;
    if (!dateStr) return;
    const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    const d = new Date(dateStr + 'T00:00:00');
    const dayName = days[d.getDay()];
    document.querySelectorAll('.day-btn').forEach(btn => {
        if (btn.textContent === dayName) {
            selectDay(dayName, btn);
        }
    });
    renderPCGrid();
}

function renderPCGrid() {
    if (!selectedLab) return;
    const grid = document.getElementById('pc-grid');
    const section = document.getElementById('pc-section');
    section.style.display = 'block';
    grid.innerHTML = '';
    selectedPC = '';
    document.getElementById('pc_number_input').value = '';

    const broken = brokenPCs[selectedLab] || [];

    for (let i = 1; i <= 50; i++) {
        const pcNum = String(i);
        const isBroken = broken.includes(i);
        const isTaken  = !isBroken && reservedPCs.some(r =>
            r.lab === selectedLab &&
            r.pc_number === pcNum &&
            r.reservation_date === (document.getElementById('res_date').value || '') &&
            r.reservation_time.substring(0,5) === selectedTime.substring(0,5)
        );

        let cls = 'pc-btn ';
        let statusLabel = 'Available';
        if (isBroken) { cls += 'broken'; statusLabel = 'Out of Service'; }
        else if (isTaken) { cls += 'taken'; statusLabel = 'Reserved'; }
        else cls += 'available';

        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = cls;
        btn.innerHTML = `<span class="pc-label">PC ${i}</span><span class="pc-status">${statusLabel}</span>`;
        if (!isBroken && !isTaken) {
            btn.onclick = () => selectPC(pcNum, btn);
        }
        grid.appendChild(btn);
    }
}

function selectPC(pc, btn) {
    selectedPC = pc;
    document.getElementById('pc_number_input').value = pc;
    document.querySelectorAll('.pc-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
}

document.getElementById('resForm').addEventListener('submit', function(e) {
    if (!document.getElementById('lab_input').value) { alert('Please select a laboratory.'); e.preventDefault(); return; }
    if (!document.getElementById('time_input').value) { alert('Please select a time slot.'); e.preventDefault(); return; }
    if (!document.getElementById('pc_number_input').value) { alert('Please select a PC.'); e.preventDefault(); return; }
    if (!document.getElementById('day_input').value) { alert('Please select a day.'); e.preventDefault(); return; }
});
</script>
</body>
</html>