<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php");
    exit();
}
require_once 'config.php';

$student_id = $_SESSION['student_id'];
$error = '';
$success = '';

// Get student details
$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Get available labs
$labs = ['524', '526', 'S28', '530', 'S44'];

// Programming languages available
$programming_languages = [
    'PHP', 'ASP.NET', 'C', 'C++', 'C#', 'Java', 'Python', 
    'JavaScript', 'SQL', 'HTML/CSS', 'Others'
];

// Handle reservation submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reserve'])) {
    $purpose = trim($_POST['purpose']);
    $lab = trim($_POST['lab']);
    $reservation_date = $_POST['reservation_date'];
    $reservation_time = $_POST['reservation_time'];
    $duration = intval($_POST['duration']);
    
    // Validate remaining sessions
    if ($student['sessions'] <= 0) {
        $error = "You have no remaining sessions left. Please contact the administrator.";
    } else {
        // Check if student already has an active reservation
        $check_stmt = $conn->prepare("SELECT id FROM reservations WHERE student_id = ? AND status = 'Pending'");
        $check_stmt->bind_param("i", $student_id);
        $check_stmt->execute();
        if ($check_stmt->get_result()->num_rows > 0) {
            $error = "You already have a pending reservation. Please wait for confirmation or cancel your current reservation.";
        } else {
            // Insert reservation
            $insert_stmt = $conn->prepare("
                INSERT INTO reservations (student_id, purpose, lab, reservation_date, reservation_time, duration, status, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, 'Pending', NOW())
            ");
            $insert_stmt->bind_param("issssi", $student_id, $purpose, $lab, $reservation_date, $reservation_time, $duration);
            
            if ($insert_stmt->execute()) {
                $success = "Reservation submitted successfully! Please wait for admin confirmation.";
                // Refresh student data
                $stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
                $stmt->bind_param("i", $student_id);
                $stmt->execute();
                $student = $stmt->get_result()->fetch_assoc();
                $stmt->close();
            } else {
                $error = "Failed to submit reservation. Please try again.";
            }
            $insert_stmt->close();
        }
        $check_stmt->close();
    }
}

// Handle cancellation
if (isset($_GET['cancel'])) {
    $reserve_id = intval($_GET['cancel']);
    $cancel_stmt = $conn->prepare("UPDATE reservations SET status = 'Cancelled' WHERE id = ? AND student_id = ?");
    $cancel_stmt->bind_param("ii", $reserve_id, $student_id);
    $cancel_stmt->execute();
    $cancel_stmt->close();
    header("Location: student_reservation.php");
    exit();
}

// Get student's reservations
$reservations = $conn->query("
    SELECT * FROM reservations 
    WHERE student_id = $student_id 
    ORDER BY created_at DESC
")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation - CCS Sit-in Monitoring</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/dashboard.css">
    <style>
        .reservation-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        .reservation-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
        }
        
        .reservation-card {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1.5px solid var(--border);
            border-radius: 24px;
            padding: 2rem;
        }
        
        .student-info-card {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1.5px solid var(--border);
            border-radius: 24px;
            padding: 2rem;
            margin-bottom: 2rem;
        }
        
        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 0.75rem 0;
            border-bottom: 1px solid rgba(212,160,23,0.1);
        }
        
        .info-label {
            font-weight: 800;
            color: var(--gold);
            text-transform: uppercase;
            font-size: 0.8rem;
            letter-spacing: 0.05em;
        }
        
        .info-value {
            font-weight: 600;
            color: var(--text);
        }
        
        .session-badge {
            background: rgba(212,160,23,0.15);
            color: var(--gold-light);
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-weight: 800;
        }
        
        .session-low {
            background: rgba(255,80,80,0.15);
            color: #ff9090;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            font-size: 0.8rem;
            font-weight: 800;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.06em;
            margin-bottom: 0.5rem;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1.5px solid rgba(212,160,23,0.2);
            border-radius: 12px;
            font-size: 0.95rem;
            font-family: 'Nunito', sans-serif;
            background: rgba(255,255,255,0.05);
            color: var(--text);
            transition: all 0.2s;
            outline: none;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            border-color: var(--gold);
            box-shadow: 0 0 0 3px rgba(212,160,23,0.15);
        }
        
        .btn-reserve {
            width: 100%;
            padding: 0.85rem;
            background: linear-gradient(135deg, var(--gold) 0%, var(--gold-dim) 100%);
            color: #0d0018;
            border: none;
            border-radius: 12px;
            font-size: 1rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .btn-reserve:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 26px rgba(212,160,23,0.55);
        }
        
        .reservations-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .reservations-table th {
            text-align: left;
            padding: 0.75rem;
            color: var(--gold);
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            border-bottom: 1px solid rgba(212,160,23,0.2);
        }
        
        .reservations-table td {
            padding: 0.75rem;
            border-bottom: 1px solid rgba(212,160,23,0.1);
        }
        
        .status-pending {
            background: rgba(255,165,0,0.15);
            color: #ffa500;
            padding: 0.25rem 0.5rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 800;
        }
        
        .status-approved {
            background: rgba(46,213,115,0.15);
            color: #5de898;
            padding: 0.25rem 0.5rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 800;
        }
        
        .status-cancelled {
            background: rgba(255,80,80,0.15);
            color: #ff9090;
            padding: 0.25rem 0.5rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 800;
        }
        
        .btn-cancel {
            background: rgba(224,82,82,0.15);
            color: #ff9090;
            border: 1px solid rgba(224,82,82,0.3);
            padding: 0.3rem 0.8rem;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
        }
        
        .alert {
            padding: 1rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
        }
        
        .alert-success {
            background: rgba(46,213,115,0.1);
            border: 1px solid rgba(46,213,115,0.3);
            color: #5de898;
        }
        
        .alert-error {
            background: rgba(255,60,60,0.1);
            border: 1px solid rgba(255,60,60,0.3);
            color: #ff9090;
        }
        
        @media (max-width: 768px) {
            .reservation-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <nav>
        <span class="nav-brand">College of Computer Studies Sit-in Monitoring System</span>
        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="student_sitin.php">Sit-in</a>
            <a href="student_reservation.php" class="active">Reservation</a>
            <a href="student_history.php">History</a>
            <a href="index.php?logout=1">Logout</a>
        </div>
    </nav>

    <main>
        <div class="reservation-container">
            <!-- Student Info Card -->
            <div class="student-info-card">
                <h2 style="color: var(--gold-light); margin-bottom: 1.5rem;">Student Information</h2>
                <div class="info-row">
                    <span class="info-label">ID Number:</span>
                    <span class="info-value"><?= htmlspecialchars($student['id_number']) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Student Name:</span>
                    <span class="info-value"><?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Course & Year:</span>
                    <span class="info-value"><?= htmlspecialchars($student['course']) ?> - Year <?= $student['course_level'] ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Remaining Sessions:</span>
                    <span class="info-value">
                        <span class="session-badge <?= ($student['sessions'] ?? 30) <= 5 ? 'session-low' : '' ?>">
                            <?= $student['sessions'] ?? 30 ?> / 30
                        </span>
                    </span>
                </div>
            </div>

            <!-- Reservation Form and List Grid -->
            <div class="reservation-grid">
                <!-- Reservation Form -->
                <div class="reservation-card">
                    <h2 style="color: var(--gold-light); margin-bottom: 1.5rem;">Make a Reservation</h2>
                    
                    <?php if ($error): ?>
                        <div class="alert alert-error">⚠ <?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success">✓ <?= htmlspecialchars($success) ?></div>
                    <?php endif; ?>
                    
                    <form method="POST">
                        <div class="form-group">
                            <label>Purpose (Programming Language)</label>
                            <select name="purpose" required>
                                <option value="">Select Programming Language</option>
                                <?php foreach ($programming_languages as $lang): ?>
                                    <option value="<?= htmlspecialchars($lang) ?>"><?= htmlspecialchars($lang) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Laboratory</label>
                            <select name="lab" required>
                                <option value="">Select Lab</option>
                                <?php foreach ($labs as $lab): ?>
                                    <option value="<?= htmlspecialchars($lab) ?>"><?= htmlspecialchars($lab) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Reservation Date</label>
                            <input type="date" name="reservation_date" min="<?= date('Y-m-d') ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Reservation Time</label>
                            <select name="reservation_time" required>
                                <option value="">Select Time</option>
                                <option value="08:00:00">8:00 AM - 10:00 AM</option>
                                <option value="10:00:00">10:00 AM - 12:00 PM</option>
                                <option value="13:00:00">1:00 PM - 3:00 PM</option>
                                <option value="15:00:00">3:00 PM - 5:00 PM</option>
                                <option value="17:00:00">5:00 PM - 7:00 PM</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Duration (hours)</label>
                            <select name="duration" required>
                                <option value="1">1 hour</option>
                                <option value="2">2 hours</option>
                                <option value="3">3 hours</option>
                            </select>
                        </div>
                        
                        <button type="submit" name="reserve" class="btn-reserve">Reserve</button>
                    </form>
                </div>
                
                <!-- My Reservations List -->
                <div class="reservation-card">
                    <h2 style="color: var(--gold-light); margin-bottom: 1.5rem;">My Reservations</h2>
                    
                    <?php if (empty($reservations)): ?>
                        <p style="text-align: center; color: var(--text-muted); padding: 2rem;">No reservations found.</p>
                    <?php else: ?>
                        <div style="overflow-x: auto;">
                            <table class="reservations-table">
                                <thead>
                                    <tr>
                                        <th>Purpose</th>
                                        <th>Lab</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($reservations as $res): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($res['purpose']) ?></td>
                                        <td><?= htmlspecialchars($res['lab']) ?></td>
                                        <td><?= date('M d, Y', strtotime($res['reservation_date'])) ?></td>
                                        <td><?= date('h:i A', strtotime($res['reservation_time'])) ?></td>
                                        <td>
                                            <span class="status-<?= strtolower($res['status']) ?>">
                                                <?= $res['status'] ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($res['status'] == 'Pending'): ?>
                                                <a href="?cancel=<?= $res['id'] ?>" class="btn-cancel" onclick="return confirm('Cancel this reservation?')">Cancel</a>
                                            <?php else: ?>
                                                —
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
    
    <footer>
        &copy; 2026 College of Computer Studies. All rights reserved.
    </footer>
</body>
</html>