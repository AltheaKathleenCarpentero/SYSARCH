<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php"); exit();
}
require_once 'config.php';

// --- Handle Downloads ---
$export = $_GET['export'] ?? '';
if (in_array($export, ['csv', 'pdf', 'doc'])) {
    $records = $conn->query("
        SELECT st.id_number, CONCAT(st.first_name,' ',st.last_name) as name,
               st.course, s.purpose, s.lab, s.login_time, s.logout_time, s.status
        FROM sit_in_sessions s
        JOIN students st ON s.student_id = st.id
        ORDER BY s.login_time DESC
    ")->fetch_all(MYSQLI_ASSOC);

    if ($export === 'csv') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="sitin_report_' . date('Y-m-d') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['ID Number','Name','Course','Purpose','Lab','Login','Logout','Status']);
        foreach ($records as $r) {
            fputcsv($out, [
                $r['id_number'], $r['name'], $r['course'], $r['purpose'],
                $r['lab'], $r['login_time'], $r['logout_time'] ?? '—', $r['status']
            ]);
        }
        fclose($out); exit();
    }

    if ($export === 'doc') {
        header('Content-Type: application/msword');
        header('Content-Disposition: attachment; filename="sitin_report_' . date('Y-m-d') . '.doc"');
        echo "<html><head><meta charset='UTF-8'></head><body>";
        echo "<h2>CCS Sit-in Report — " . date('F d, Y') . "</h2>";
        echo "<table border='1' cellpadding='6' cellspacing='0' style='border-collapse:collapse;width:100%'>";
        echo "<tr style='background:#4a0080;color:#fff'><th>ID Number</th><th>Name</th><th>Course</th><th>Purpose</th><th>Lab</th><th>Login</th><th>Logout</th><th>Status</th></tr>";
        foreach ($records as $r) {
            echo "<tr>
                <td>{$r['id_number']}</td>
                <td>{$r['name']}</td>
                <td>{$r['course']}</td>
                <td>{$r['purpose']}</td>
                <td>{$r['lab']}</td>
                <td>{$r['login_time']}</td>
                <td>" . ($r['logout_time'] ?? '—') . "</td>
                <td>{$r['status']}</td>
            </tr>";
        }
        echo "</table></body></html>";
        exit();
    }

    if ($export === 'pdf') {
        header('Content-Type: text/html');
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Sit-in Report</title>
            <style>
                body { font-family: Arial, sans-serif; font-size: 12px; margin: 20px; }
                h2 { color: #4a0080; }
                table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
                th { background: #4a0080; color: white; padding: 6px 8px; text-align: left; }
                td { padding: 5px 8px; border-bottom: 1px solid #ddd; }
                tr:nth-child(even) { background: #f5f0ff; }
                .footer { margin-top: 2rem; font-size: 11px; color: #999; }
                @media print { button { display: none; } }
            </style>
        </head>
        <body>
            <button onclick="window.print()" style="margin-bottom:1rem;padding:8px 16px;background:#4a0080;color:white;border:none;border-radius:6px;cursor:pointer;">🖨️ Print / Save as PDF</button>
            <h2>CCS Sit-in Report</h2>
            <p>Generated: <?= date('F d, Y h:i A') ?></p>
            <table>
                <thead>
                    <tr><th>ID Number</th><th>Name</th><th>Course</th><th>Purpose</th><th>Lab</th><th>Login</th><th>Logout</th><th>Status</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($records as $r): ?>
                    <tr>
                        <td><?= htmlspecialchars($r['id_number']) ?></td>
                        <td><?= htmlspecialchars($r['name']) ?></td>
                        <td><?= htmlspecialchars($r['course']) ?></td>
                        <td><?= htmlspecialchars($r['purpose']) ?></td>
                        <td><?= htmlspecialchars($r['lab']) ?></td>
                        <td><?= htmlspecialchars($r['login_time']) ?></td>
                        <td><?= htmlspecialchars($r['logout_time'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($r['status']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="footer">College of Computer Studies — CCS Sit-in Monitoring System</div>
            <script>window.onload = () => window.print();</script>
        </body>
        </html>
        <?php
        exit();
    }
}

$total_records = $conn->query("SELECT COUNT(*) FROM sit_in_sessions")->fetch_row()[0];
$total_students = $conn->query("SELECT COUNT(*) FROM students")->fetch_row()[0];
$total_active = $conn->query("SELECT COUNT(*) FROM sit_in_sessions WHERE status='Active'")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Generate Reports – CCS Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
<nav>
    <span class="nav-brand">🖥️ CCS Admin Panel</span>
    <div class="nav-links">
        <a href="admin.php">Dashboard</a>
        <a href="#" onclick="openModal('searchModal')">Search</a>
        <a href="admin_students.php">Students</a>
        <div class="nav-dropdown">
            <div class="nav-drop-toggle active">Sit-in</div>
            <div class="nav-drop-menu">
                <a href="admin_sitin.php">📋 Sit-in</a>
                <a href="admin_sitin_records.php">📊 View Sit-in Records</a>
                <a href="admin_generate_reports.php" class="active">📥 Generate Reports</a>
            </div>
        </div>
        
        <a href="admin_feedback.php">Feedback Reports</a>
        <a href="admin_reservation.php">Reservation</a>
        <a href="admin.php?logout=1" class="logout-btn">Log out</a>
    </div>
</nav>

<div class="modal-overlay" id="searchModal" style="display:none">
    <div class="modal-box">
        <div class="modal-header"><span>🔍 Search Student</span><button class="modal-close" onclick="closeModal('searchModal')">✕</button></div>
        <div class="modal-body">
            <input type="text" id="searchInput" class="modal-input" placeholder="Name or ID number...">
            <div id="searchResults" class="search-results"></div>
        </div>
        <div class="modal-footer"><button class="btn-primary" onclick="searchStudent()">Search</button></div>
    </div>
</div>

<main>
    <div class="page-title">Generate Reports</div>

    <div class="stats-row">
        <div class="stat-card">
            <div class="stat-icon">👥</div>
            <div class="stat-num"><?= $total_students ?></div>
            <div class="stat-label">Total Students</div>
        </div>
        <div class="stat-card stat-active">
            <div class="stat-icon">🟢</div>
            <div class="stat-num"><?= $total_active ?></div>
            <div class="stat-label">Currently Active</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">📊</div>
            <div class="stat-num"><?= $total_records ?></div>
            <div class="stat-label">Total Sit-in Records</div>
        </div>
    </div>

    <div class="card" style="max-width: 600px; margin: 0 auto;">
        <div class="card-header">📥 Download Sit-in Report</div>
        <div class="card-body">
            <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1.5rem;">
                Export all sit-in session records. Choose your preferred format below.
            </p>
            <div style="display: flex; flex-direction: column; gap: 1rem;">

                <a href="?export=csv" class="report-download-btn" style="display:flex; align-items:center; gap:1rem; padding:1rem 1.25rem; background: rgba(39,175,96,0.12); border: 1px solid rgba(39,175,96,0.3); border-radius: 10px; text-decoration:none; transition: background 0.2s;">
                    <span style="font-size:2rem;">📄</span>
                    <div>
                        <div style="font-weight:800; color:#27ae60; font-size:1rem;">Download CSV</div>
                        <div style="color:var(--text-muted); font-size:0.78rem;">Comma-separated values — open in Excel or Google Sheets</div>
                    </div>
                </a>

                <a href="?export=doc" class="report-download-btn" style="display:flex; align-items:center; gap:1rem; padding:1rem 1.25rem; background: rgba(41,128,185,0.12); border: 1px solid rgba(41,128,185,0.3); border-radius: 10px; text-decoration:none; transition: background 0.2s;">
                    <span style="font-size:2rem;">📝</span>
                    <div>
                        <div style="font-weight:800; color:#2980b9; font-size:1rem;">Download DOC</div>
                        <div style="color:var(--text-muted); font-size:0.78rem;">Word document — open in Microsoft Word or LibreOffice</div>
                    </div>
                </a>

                <a href="?export=pdf" target="_blank" class="report-download-btn" style="display:flex; align-items:center; gap:1rem; padding:1rem 1.25rem; background: rgba(192,57,43,0.12); border: 1px solid rgba(192,57,43,0.3); border-radius: 10px; text-decoration:none; transition: background 0.2s;">
                    <span style="font-size:2rem;">🖨️</span>
                    <div>
                        <div style="font-weight:800; color:#c0392b; font-size:1rem;">Download PDF</div>
                        <div style="color:var(--text-muted); font-size:0.78rem;">Opens print dialog — save as PDF from your browser</div>
                    </div>
                </a>

            </div>
        </div>
    </div>
</main>

<footer>&copy; 2026 College of Computer Studies</footer>
<script>
function openModal(id)  { document.getElementById(id).style.display = 'flex'; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }
function searchStudent() {
    const q = document.getElementById('searchInput').value.trim(); if (!q) return;
    fetch('admin_search.php?q=' + encodeURIComponent(q)).then(r => r.text()).then(html => { document.getElementById('searchResults').innerHTML = html; });
}
document.getElementById('searchInput')?.addEventListener('keydown', e => { if (e.key === 'Enter') searchStudent(); });
</script>
</body>
</html>